using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

/// <summary>
/// Ставит Portrait по центру buds под заголовком (один раз).
/// </summary>
public static class BudPortraitFixTool
{
    [MenuItem("Tools/MonkeyBar/Центрировать Portrait (официант)")]
    public static void CenterPortrait()
    {
        if (Application.isPlaying)
        {
            Debug.LogError("[BudPortrait] Останови Play.");
            return;
        }

        var buds = GameObject.Find("buds");
        if (buds == null)
        {
            Debug.LogError("[BudPortrait] Нет объекта «buds».");
            return;
        }

        var portraitT = buds.transform.Find("Portrait") as RectTransform;
        var nameBgT = buds.transform.Find("NameBg") as RectTransform;
        if (portraitT == null)
        {
            Debug.LogError("[BudPortrait] Нет Portrait в buds.");
            return;
        }

        Undo.RecordObject(portraitT, "Center Portrait");

        portraitT.anchorMin = new Vector2(0.5f, 1f);
        portraitT.anchorMax = new Vector2(0.5f, 1f);
        portraitT.pivot = new Vector2(0.5f, 0f);
        portraitT.localScale = Vector3.one;

        float feetY = -315f;
        if (nameBgT != null)
        {
            float halfH = nameBgT.rect.height > 1f ? nameBgT.rect.height * 0.5f : nameBgT.sizeDelta.y * 0.5f;
            feetY = nameBgT.anchoredPosition.y + halfH;
        }

        portraitT.anchoredPosition = new Vector2(0f, feetY);
        if (portraitT.sizeDelta.y < 50f)
            portraitT.sizeDelta = new Vector2(94f, 254f);

        EditorUtility.SetDirty(portraitT);
        EditorSceneManager.MarkSceneDirty(buds.scene);
        Debug.Log($"[BudPortrait] Portrait по центру: pos (0, {feetY}). Сохрани сцену Ctrl+S.");
    }
}
