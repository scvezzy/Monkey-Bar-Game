using System.IO;
using UnityEditor;
using UnityEngine;

/// <summary>
/// Чинит импорт spr_char0-3_idle — один спрайт на всю текстуру, без битого _0.
/// </summary>
public static class FixWaiterPortraitSpritesTool
{
    [MenuItem("Tools/MonkeyBar/Починить спрайты официантов (первый кадр)")]
    public static void FixAll()
    {
        FixAllSilent();
        AssetDatabase.Refresh();
        Debug.Log("[WaiterSprites] Готово. Используй спрайт spr_charN_idle (без _0). Ctrl+S.");
    }

    public static void FixAllSilent()
    {
        for (int i = 0; i < 4; i++)
        {
            FixOne($"Assets/UI/Menu/waiters/spr_char{i}_idle.png");
            FixOne($"Assets/Resources/Menu/waiters/spr_char{i}_idle.png");
        }
    }

    static void FixOne(string assetPath)
    {
        string full = Path.GetFullPath(assetPath);
        if (!File.Exists(full)) return;

        var imp = AssetImporter.GetAtPath(assetPath) as TextureImporter;
        if (imp == null) return;

        imp.textureType = TextureImporterType.Sprite;
        imp.spriteImportMode = SpriteImportMode.Single;
        imp.filterMode = FilterMode.Point;
        imp.textureCompression = TextureImporterCompression.Uncompressed;
        imp.alphaIsTransparency = true;
        imp.mipmapEnabled = false;
        imp.spritePixelsToUnits = 100f;
        imp.SaveAndReimport();
    }
}
