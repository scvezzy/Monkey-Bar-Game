using System.IO;
using UnityEditor;
using UnityEngine;

public static class FixMenuSpriteTool
{
    const int Border = 3;

    static readonly string[] SliceSprites =
    {
        "Assets/UI/Menu/esc/spr_upgrade_sub.png",
        "Assets/UI/Menu/esc/spr_button.png",
        "Assets/UI/Menu/esc/spr_upgrade_desc.png",
        "Assets/UI/Menu/esc/spr_upgrade_name.png",
        "Assets/UI/Menu/esc/spr_upgrade_bg.png"
    };

    static readonly string[] SimpleSprites =
    {
        "Assets/UI/Menu/pint/spr_coin.png",
        "Assets/UI/Menu/esc/spr_icon_table.png",
        "Assets/UI/Menu/esc/spr_icon_banana.png",
        "Assets/UI/Menu/esc/spr_icon_monkey.png",
        "Assets/UI/Menu/esc/spr_icon_feather.png",
        "Assets/UI/Menu/esc/spr_circle_8.png",
        "Assets/UI/Menu/esc/spr_visitor.png",
        "Assets/UI/Menu/esc/spr_char.png",
        "Assets/UI/Menu/waiters/spr_char0_idle.png",
        "Assets/UI/Menu/waiters/spr_char1_idle.png",
        "Assets/UI/Menu/waiters/spr_char2_idle.png",
        "Assets/UI/Menu/waiters/spr_char3_idle.png",
        "Assets/UI/Menu/pals/spr_visitor.png"
    };

    [MenuItem("Tools/MonkeyBar/Fix spr_upgrade_sub (обрезка + 9-slice)")]
    public static void Fix()
    {
        FixAllMenuSpritesSilent();
        AssetDatabase.Refresh();
        Debug.Log("[FixMenuSprite] Все спрайты меню обрезаны. Дальше: Собрать блок Upgrades.");
    }

    public static void FixSpritesSilent() => FixAllMenuSpritesSilent();

    public static void FixAllMenuSpritesSilent()
    {
        foreach (string path in SliceSprites)
        {
            CropTransparentPadding(path);
            ApplyImport(path, slice: true);
        }
        foreach (string path in SimpleSprites)
        {
            CropTransparentPadding(path);
            ApplyImport(path, slice: false);
        }
    }

    static void CropTransparentPadding(string assetPath)
    {
        string full = Path.GetFullPath(assetPath);
        if (!File.Exists(full)) return;

        var src = new Texture2D(2, 2, TextureFormat.RGBA32, false);
        src.LoadImage(File.ReadAllBytes(full));

        int minX = src.width, minY = src.height, maxX = 0, maxY = 0;
        var px = src.GetPixels32();
        for (int y = 0; y < src.height; y++)
        for (int x = 0; x < src.width; x++)
        {
            if (px[y * src.width + x].a == 0) continue;
            if (x < minX) minX = x;
            if (y < minY) minY = y;
            if (x > maxX) maxX = x;
            if (y > maxY) maxY = y;
        }

        if (maxX < minX)
        {
            Object.DestroyImmediate(src);
            return;
        }

        int w = maxX - minX + 1;
        int h = maxY - minY + 1;
        if (w == src.width && h == src.height)
        {
            Object.DestroyImmediate(src);
            return;
        }

        var cropped = new Texture2D(w, h, TextureFormat.RGBA32, false);
        cropped.SetPixels(src.GetPixels(minX, minY, w, h));
        cropped.Apply();
        File.WriteAllBytes(full, cropped.EncodeToPNG());
        Object.DestroyImmediate(src);
        Object.DestroyImmediate(cropped);
    }

    static void ApplyImport(string assetPath, bool slice)
    {
        var imp = AssetImporter.GetAtPath(assetPath) as TextureImporter;
        if (imp == null) return;

        imp.textureType         = TextureImporterType.Sprite;
        imp.spriteImportMode    = SpriteImportMode.Single;
        imp.filterMode          = FilterMode.Point;
        imp.textureCompression  = TextureImporterCompression.Uncompressed;
        imp.alphaIsTransparency = true;
        imp.mipmapEnabled       = false;
        imp.spritePixelsToUnits = 100f;
        if (slice)
            imp.spriteBorder = new Vector4(Border, Border, Border, Border);
        imp.SaveAndReimport();
    }
}
