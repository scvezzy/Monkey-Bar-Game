using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Заполняет «pal list» и «buds» внутри существующих рамок. Позиции рамок не меняет.
/// </summary>
public static class MenuPalBudsSetupTool
{
    const string NameBgPath   = "Assets/UI/Menu/esc/spr_upgrade_name.png";
    const string DescBgPath   = "Assets/UI/Menu/esc/spr_upgrade_desc.png";
    const string CirclePath   = "Assets/UI/Menu/esc/spr_circle_8.png";
    const string FontPath     = "Assets/UI/Fonts/PlainPixel-Regular.ttf";

    [MenuItem("Tools/MonkeyBar/Заполнить Pal list и Buds (без сдвига рамок)")]
    public static void SetupPalAndBuds()
    {
        if (Application.isPlaying)
        {
            Debug.LogError("[PalBuds] Останови Play перед настройкой.");
            return;
        }

        CopySpritesFromDesktop();
        FixMenuSpriteTool.FixSpritesSilent();
        ImportCharacterSprites();

        var canvasGo = GameObject.Find("DayMenuUI");
        if (canvasGo == null)
        {
            Debug.LogError("[PalBuds] Нет DayMenuUI на сцене.");
            return;
        }

        var panel = canvasGo.transform.Find("Panel");
        if (panel == null)
        {
            Debug.LogError("[PalBuds] Нет Panel внутри DayMenuUI.");
            return;
        }

        EnsureMenuUIAssets(canvasGo);

        var menu = panel.GetComponent<DayMenuUI>();
        if (menu == null)
        {
            Debug.LogError("[PalBuds] На Panel нет DayMenuUI.");
            return;
        }
        menu.buildUIAtRuntime = false;

        var palTf = panel.Find("pal list");
        var budsTf = panel.Find("buds");
        if (palTf == null || budsTf == null)
        {
            Debug.LogError("[PalBuds] Нужны объекты «pal list» и «buds» на Panel.");
            return;
        }

        var palList = palTf.GetComponent<PalListUI>();
        if (palList == null) palList = Undo.AddComponent<PalListUI>(palTf.gameObject);
        palList.WireManualSlots();

        var budsPanel = budsTf.GetComponent<BudsPanelUI>();
        if (budsPanel == null) budsPanel = Undo.AddComponent<BudsPanelUI>(budsTf.gameObject);
        budsPanel.BuildIfEmpty();
        budsPanel.Init(menu);

        menu.palList = palList;
        menu.budsPanel = budsPanel;
        menu.budButtons = budsPanel.budButtons;

        EnsureStartDayButton(panel, menu);
        EnsureStatCounters(panel, menu);

        EditorUtility.SetDirty(canvasGo);
        EditorUtility.SetDirty(menu);
        EditorSceneManager.MarkSceneDirty(panel.gameObject.scene);
        Debug.Log("[PalBuds] Buds заполнены. Pal list — вручную. Сохрани сцену (Ctrl+S).");
    }

    /// <summary>Для Unity batchmode: -executeMethod MenuPalBudsSetupTool.SetupFromBatch</summary>
    public static void SetupFromBatch()
    {
        SetupPalAndBuds();
        EditorSceneManager.SaveOpenScenes();
    }

    static void CopySpritesFromDesktop()
    {
        string desk = @"C:\Users\dv125\Desktop\sprite";
        if (!System.IO.Directory.Exists(desk))
        {
            Debug.LogWarning("[PalBuds] Папка Desktop\\sprite не найдена — используем уже импортированные ассеты.");
            return;
        }

        CopyFile($"{desk}\\witer\\spr_char0_idle.png", "Assets/UI/Menu/waiters/spr_char0_idle.png");
        CopyFile($"{desk}\\witer\\spr_char1_idle.png", "Assets/UI/Menu/waiters/spr_char1_idle.png");
        CopyFile($"{desk}\\witer\\spr_char2_idle.png", "Assets/UI/Menu/waiters/spr_char2_idle.png");
        CopyFile($"{desk}\\witer\\spr_char3_idle.png", "Assets/UI/Menu/waiters/spr_char3_idle.png");
        CopyFile($"{desk}\\esc\\spr_visitor.png", "Assets/UI/Menu/pals/spr_visitor.png");
        CopyFile($"{desk}\\esc\\spr_circle_8.png", "Assets/UI/Menu/esc/spr_circle_8.png");
        CopyFile($"{desk}\\esc\\spr_upgrade_desc.png", "Assets/UI/Menu/esc/spr_upgrade_desc.png");
        CopyFile($"{desk}\\esc\\spr_upgrade_name.png", "Assets/UI/Menu/esc/spr_upgrade_name.png");

        CopyFile($"{desk}\\witer\\spr_char0_idle.png", "Assets/Resources/Menu/waiters/spr_char0_idle.png");
        CopyFile($"{desk}\\witer\\spr_char1_idle.png", "Assets/Resources/Menu/waiters/spr_char1_idle.png");
        CopyFile($"{desk}\\witer\\spr_char2_idle.png", "Assets/Resources/Menu/waiters/spr_char2_idle.png");
        CopyFile($"{desk}\\witer\\spr_char3_idle.png", "Assets/Resources/Menu/waiters/spr_char3_idle.png");
        CopyFile($"{desk}\\esc\\spr_visitor.png", "Assets/Resources/Menu/pals/spr_visitor.png");
        CopyFile($"{desk}\\esc\\spr_upgrade_desc.png", "Assets/Resources/Menu/esc/spr_upgrade_desc.png");
        CopyFile($"{desk}\\esc\\spr_circle_8.png", "Assets/Resources/Menu/esc/spr_circle_8.png");
        CopyFile($"{desk}\\pint\\spr_coin.png", "Assets/Resources/Menu/pint/spr_coin.png");
        CopyFile($"{desk}\\pint\\spr_icon_monkey.png", "Assets/Resources/Menu/pint/spr_icon_monkey.png");

        AssetDatabase.Refresh();
    }

    static void CopyFile(string src, string dst)
    {
        if (!System.IO.File.Exists(src)) return;
        System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dst));
        System.IO.File.Copy(src, dst, true);
    }

    static void ImportCharacterSprites()
    {
        string[] paths =
        {
            "Assets/UI/Menu/waiters/spr_char0_idle.png",
            "Assets/UI/Menu/waiters/spr_char1_idle.png",
            "Assets/UI/Menu/waiters/spr_char2_idle.png",
            "Assets/UI/Menu/waiters/spr_char3_idle.png",
            "Assets/UI/Menu/pals/spr_visitor.png",
            "Assets/Resources/Menu/waiters/spr_char0_idle.png",
            "Assets/Resources/Menu/waiters/spr_char1_idle.png",
            "Assets/Resources/Menu/waiters/spr_char2_idle.png",
            "Assets/Resources/Menu/waiters/spr_char3_idle.png",
            "Assets/Resources/Menu/pals/spr_visitor.png",
            "Assets/Resources/Menu/esc/spr_upgrade_desc.png",
            "Assets/Resources/Menu/esc/spr_circle_8.png",
            "Assets/Resources/Menu/pint/spr_coin.png",
            "Assets/Resources/Menu/pint/spr_icon_monkey.png"
        };

        foreach (string path in paths)
        {
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp == null) continue;
            imp.textureType = TextureImporterType.Sprite;
            imp.spriteImportMode = SpriteImportMode.Single;
            imp.filterMode = FilterMode.Point;
            imp.textureCompression = TextureImporterCompression.Uncompressed;
            imp.alphaIsTransparency = true;
            imp.mipmapEnabled = false;
            imp.spritePixelsToUnits = 100f;
            imp.SaveAndReimport();
        }
    }

    static void EnsureMenuUIAssets(GameObject canvasGo)
    {
        var assets = canvasGo.GetComponent<MenuUIAssets>();
        if (assets == null) assets = Undo.AddComponent<MenuUIAssets>(canvasGo);

        if (assets.buttonSprite == null)
            assets.buttonSprite = AssetDatabase.LoadAssetAtPath<Sprite>(NameBgPath);
        if (assets.tooltipSprite == null)
            assets.tooltipSprite = assets.buttonSprite;
        if (assets.coinSprite == null)
            assets.coinSprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/UI/Menu/pint/spr_coin.png");
        if (assets.menuFont == null)
            assets.menuFont = AssetDatabase.LoadAssetAtPath<Font>(FontPath);
    }

    static void EnsureStartDayButton(Transform panel, DayMenuUI menu)
    {
        var existing = panel.Find("BtnStartDay");
        if (existing != null)
        {
            menu.startDayButton = existing.GetComponent<Button>();
            return;
        }

        Sprite btnBg = AssetDatabase.LoadAssetAtPath<Sprite>(NameBgPath);
        Font font = AssetDatabase.LoadAssetAtPath<Font>(FontPath);

        var go = new GameObject("BtnStartDay");
        Undo.RegisterCreatedObjectUndo(go, "Start Day");
        go.transform.SetParent(panel, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.5f, 0f);
        rt.anchorMax = new Vector2(0.5f, 0f);
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = new Vector2(0f, 42f);
        rt.sizeDelta = new Vector2(420f, 72f);

        var img = go.AddComponent<Image>();
        img.sprite = btnBg;
        img.type = Image.Type.Sliced;
        img.color = new Color(0.24f, 0.15f, 0.06f, 1f);

        var btn = go.AddComponent<Button>();
        btn.targetGraphic = img;

        var tgo = new GameObject("Text");
        tgo.transform.SetParent(go.transform, false);
        var trt = tgo.AddComponent<RectTransform>();
        trt.anchorMin = Vector2.zero;
        trt.anchorMax = Vector2.one;
        trt.offsetMin = new Vector2(12f, 8f);
        trt.offsetMax = new Vector2(-12f, -8f);
        var t = tgo.AddComponent<Text>();
        t.text = "Начать день";
        t.font = font;
        t.fontSize = 32;
        t.color = Color.white;
        t.alignment = TextAnchor.MiddleCenter;

        go.AddComponent<MenuStartDayButton>();
        menu.startDayButton = btn;
    }

    static void EnsureStatCounters(Transform panel, DayMenuUI menu)
    {
        if (menu.coinsText != null && menu.servedText != null) return;

        Font font = AssetDatabase.LoadAssetAtPath<Font>(FontPath);
        Sprite monkey = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/UI/Menu/pint/spr_icon_monkey.png");
        Sprite coin = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/UI/Menu/pint/spr_coin.png");

        var root = panel.Find("StatCounters");
        if (root == null)
        {
            var go = new GameObject("StatCounters");
            Undo.RegisterCreatedObjectUndo(go, "Stat Counters");
            go.transform.SetParent(panel, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(0f, 0f);
            rt.pivot = new Vector2(0f, 0f);
            rt.anchoredPosition = new Vector2(80f, 120f);
            rt.sizeDelta = new Vector2(200f, 48f);
            root = go.transform;
        }

        if (menu.servedText == null)
            menu.servedText = BuildCounter(root, "Served", new Vector2(0f, 0f), monkey, font);
        if (menu.coinsText == null)
            menu.coinsText = BuildCounter(root, "Coins", new Vector2(100f, 0f), coin, font);
    }

    static Text BuildCounter(Transform parent, string name, Vector2 pos, Sprite icon, Font font)
    {
        var go = new GameObject(name);
        Undo.RegisterCreatedObjectUndo(go, name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0f, 0.5f);
        rt.pivot = new Vector2(0f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(96f, 40f);

        var numGo = new GameObject("Num");
        numGo.transform.SetParent(go.transform, false);
        var numRt = numGo.AddComponent<RectTransform>();
        numRt.anchorMin = numRt.anchorMax = new Vector2(0f, 0.5f);
        numRt.pivot = new Vector2(0f, 0.5f);
        numRt.anchoredPosition = Vector2.zero;
        numRt.sizeDelta = new Vector2(44f, 40f);
        var num = numGo.AddComponent<Text>();
        num.text = "0";
        num.font = font;
        num.fontSize = 20;
        num.color = Color.white;
        num.alignment = TextAnchor.MiddleCenter;

        if (icon != null)
        {
            var iGo = new GameObject("Icon");
            iGo.transform.SetParent(go.transform, false);
            var iRt = iGo.AddComponent<RectTransform>();
            iRt.anchorMin = iRt.anchorMax = new Vector2(0f, 0.5f);
            iRt.pivot = new Vector2(0f, 0.5f);
            iRt.anchoredPosition = new Vector2(52f, 0f);
            iRt.sizeDelta = new Vector2(36f, 36f);
            var img = iGo.AddComponent<Image>();
            img.sprite = icon;
            img.preserveAspect = true;
        }

        return num;
    }
}
