using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

public static class MenuUpgradesSetupTool
{
    const string BtnPath  = "Assets/UI/Menu/esc/spr_button.png";
    const string CoinPath = "Assets/UI/Menu/pint/spr_coin.png";
    const string SubPath  = "Assets/UI/Menu/esc/spr_upgrade_sub.png";
    const string FontPath = "Assets/UI/Fonts/PlainPixel-Regular.ttf";

    static readonly string[] IconPaths =
    {
        "Assets/UI/Menu/esc/spr_icon_table.png",
        "Assets/UI/Menu/esc/spr_icon_banana.png",
        "Assets/UI/Menu/esc/spr_icon_monkey.png",
        "Assets/UI/Menu/esc/spr_icon_feather.png"
    };

    static readonly UpgradeType[] Types =
    {
        UpgradeType.Table, UpgradeType.Speed, UpgradeType.ServingTime, UpgradeType.DayTime
    };

    static readonly string[] Tips =
    {
        "Добавляет дополнительный\nстолик для мартышек",
        "Увеличивает скорость\nофицианта",
        "Взаимодействие с мартышками\n(посетителями) происходит быстрее",
        "Продолжительность дня"
    };

    [MenuItem("Tools/MonkeyBar/Собрать блок Upgrades")]
    public static void Build()
    {
        if (Application.isPlaying)
        {
            Debug.LogError("[UpgradesSetup] Останови Play (■) перед сборкой!");
            return;
        }

        FixMenuSpriteTool.FixAllMenuSpritesSilent();
        AssetDatabase.Refresh();

        Transform panel = GameObject.Find("DayMenuUI")?.transform.Find("Panel");
        Transform upgrades = panel?.Find("upgrades");
        if (upgrades == null)
        {
            Debug.LogError("[UpgradesSetup] Нет upgrades на Panel.");
            return;
        }

        Sprite btnSpr  = LoadSprite(BtnPath);
        Sprite coinSpr = LoadSprite(CoinPath);
        Sprite subSpr  = LoadSprite(SubPath);
        Font font      = AssetDatabase.LoadAssetAtPath<Font>(FontPath);
        if (btnSpr == null || font == null)
        {
            Debug.LogError("[UpgradesSetup] spr_button не загрузился.");
            return;
        }

        EnsureMenuAssets(panel, btnSpr, coinSpr);

        var upgRt = upgrades.GetComponent<RectTransform>();
        float winW = upgRt != null && upgRt.rect.width > 10f ? upgRt.rect.width : 480f;
        float winH = upgRt != null && upgRt.rect.height > 10f ? upgRt.rect.height : 280f;

        for (int i = upgrades.childCount - 1; i >= 0; i--)
            Object.DestroyImmediate(upgrades.GetChild(i).gameObject);

        MakeTitle(upgrades, font, winW);

        var rows = new UpgradeRowUI[4];
        float titleH = 38f;
        float padY   = 6f;
        float rowH   = (winH - titleH - padY * 2f) / 4f;
        float rowTop = -titleH - padY;

        for (int i = 0; i < 4; i++)
        {
            float y = rowTop - rowH * 0.5f - i * rowH;
            Sprite icon = LoadSprite(IconPaths[i]);
            rows[i] = MakeRow(upgrades, i, y, rowH, winW, btnSpr, coinSpr, subSpr, font, icon);
        }

        var menu = panel.GetComponent<DayMenuUI>();
        if (menu != null)
        {
            menu.buildUIAtRuntime = false;
            menu.upgradeRows = rows;
            EditorUtility.SetDirty(menu);
        }

        EditorUtility.SetDirty(upgrades.gameObject);
        EditorSceneManager.MarkSceneDirty(upgrades.gameObject.scene);
        Debug.Log("[UpgradesSetup] Upgrades на всю ширину окна. Ctrl+S.");
    }

    static Sprite LoadSprite(string path)
    {
        foreach (var o in AssetDatabase.LoadAllAssetsAtPath(path))
            if (o is Sprite s) return s;
        return AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    static void EnsureMenuAssets(Transform panel, Sprite btn, Sprite coin)
    {
        var canvas = panel.GetComponentInParent<Canvas>();
        var assets = canvas != null ? canvas.GetComponent<MenuUIAssets>() : null;
        if (assets == null && canvas != null)
            assets = canvas.gameObject.AddComponent<MenuUIAssets>();
        if (assets == null) return;
        assets.buttonSprite = btn;
        assets.coinSprite   = coin;
        EditorUtility.SetDirty(assets);
    }

    static void MakeTitle(Transform parent, Font font, float winW)
    {
        var go = new GameObject("Title", typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        go.layer = 5;
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0, 1);
        rt.anchorMax = new Vector2(1, 1);
        rt.pivot = new Vector2(0.5f, 1f);
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = new Vector2(0, 38);
        var t = go.GetComponent<Text>();
        t.font = font; t.fontSize = 26; t.fontStyle = FontStyle.Bold;
        t.alignment = TextAnchor.MiddleCenter;
        t.color = MenuConfig.TitleRed;
        t.text = "Upgrades";
        t.raycastTarget = false;
    }

    static UpgradeRowUI MakeRow(Transform parent, int index, float y, float h, float winW,
        Sprite btnSpr, Sprite coinSpr, Sprite subSpr, Font font, Sprite iconSpr)
    {
        const float sidePad = 10f;
        const float iconW   = 52f;
        const float btnW    = 0.36f; // 36% ширины окна — как в оригинале

        float buttonW = winW * btnW;
        float slotsLeft = sidePad + iconW + 8f;
        float slotsRight = sidePad + buttonW + 8f;

        var rowGo = new GameObject($"Row{index}", typeof(RectTransform), typeof(UpgradeRowUI));
        rowGo.layer = 5;
        rowGo.transform.SetParent(parent, false);
        var rowRt = rowGo.GetComponent<RectTransform>();
        rowRt.anchorMin = new Vector2(0, 1);
        rowRt.anchorMax = new Vector2(1, 1);
        rowRt.pivot = new Vector2(0.5f, 0.5f);
        rowRt.anchoredPosition = new Vector2(0, y);
        rowRt.sizeDelta = new Vector2(-sidePad * 2f, h - 4f);

        var row = rowGo.GetComponent<UpgradeRowUI>();
        row.upgradeType = Types[index];
        row.tooltipText = Tips[index];

        // Icon — слева, прижат к краю
        var iconGo = new GameObject("Icon", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        iconGo.layer = 5;
        iconGo.transform.SetParent(rowGo.transform, false);
        var iconRt = iconGo.GetComponent<RectTransform>();
        iconRt.anchorMin = iconRt.anchorMax = new Vector2(0, 0.5f);
        iconRt.pivot = new Vector2(0, 0.5f);
        iconRt.anchoredPosition = Vector2.zero;
        iconRt.sizeDelta = new Vector2(iconW, iconW);
        var iconImg = iconGo.GetComponent<Image>();
        iconImg.sprite = iconSpr;
        iconImg.preserveAspect = true;
        iconImg.raycastTarget = true;
        row.iconImage = iconImg;

        // Кнопка — справа, spr_button растянут
        var btnGo = new GameObject("BtnUpgrade", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
        btnGo.layer = 5;
        btnGo.transform.SetParent(rowGo.transform, false);
        var btnRt = btnGo.GetComponent<RectTransform>();
        btnRt.anchorMin = btnRt.anchorMax = new Vector2(1, 0.5f);
        btnRt.pivot = new Vector2(1, 0.5f);
        btnRt.anchoredPosition = Vector2.zero;
        btnRt.sizeDelta = new Vector2(buttonW, Mathf.Min(h - 8f, 40f));
        var btnImg = btnGo.GetComponent<Image>();
        SetupSliced(btnImg, btnSpr);
        var btn = btnGo.GetComponent<Button>();
        btn.targetGraphic = btnImg;
        var cb = btn.colors;
        cb.normalColor      = Color.white;
        cb.highlightedColor = new Color(0.92f, 0.92f, 0.92f, 1f);
        cb.pressedColor     = new Color(0.78f, 0.78f, 0.78f, 1f);
        cb.disabledColor    = new Color(0.55f, 0.55f, 0.55f, 0.7f);
        btn.colors = cb;
        row.buyButton = btn;

        var txtGo = new GameObject("CostText", typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        txtGo.layer = 5;
        txtGo.transform.SetParent(btnGo.transform, false);
        var txtRt = txtGo.GetComponent<RectTransform>();
        txtRt.anchorMin = Vector2.zero;
        txtRt.anchorMax = Vector2.one;
        txtRt.offsetMin = new Vector2(14, 0);
        txtRt.offsetMax = new Vector2(-38, 0);
        var txt = txtGo.GetComponent<Text>();
        txt.font = font; txt.fontSize = 15; txt.fontStyle = FontStyle.Bold;
        txt.alignment = TextAnchor.MiddleLeft;
        txt.color = new Color(0.78f, 0.75f, 0.70f, 1f);
        txt.text = "upgrade: 80";
        row.costLabel = txt;

        if (coinSpr != null)
        {
            var coinGo = new GameObject("CoinIcon", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            coinGo.layer = 5;
            coinGo.transform.SetParent(btnGo.transform, false);
            var coinRt = coinGo.GetComponent<RectTransform>();
            coinRt.anchorMin = coinRt.anchorMax = new Vector2(1, 0.5f);
            coinRt.pivot = new Vector2(1, 0.5f);
            coinRt.anchoredPosition = new Vector2(-12, 0);
            coinRt.sizeDelta = new Vector2(26, 26);
            var coinImg = coinGo.GetComponent<Image>();
            coinImg.sprite = coinSpr;
            coinImg.preserveAspect = true;
            coinImg.raycastTarget = false;
        }

        // Шкала — растягивается между иконкой и кнопкой на ВСЮ ширину
        var barGo = new GameObject("SlotsBar", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        barGo.layer = 5;
        barGo.transform.SetParent(rowGo.transform, false);
        var barRt = barGo.GetComponent<RectTransform>();
        barRt.anchorMin = new Vector2(0, 0.5f);
        barRt.anchorMax = new Vector2(1, 0.5f);
        barRt.pivot = new Vector2(0.5f, 0.5f);
        barRt.offsetMin = new Vector2(slotsLeft - sidePad, -12f);
        barRt.offsetMax = new Vector2(-(slotsRight - sidePad), 12f);
        var barImg = barGo.GetComponent<Image>();
        if (subSpr != null)
        {
            SetupSliced(barImg, subSpr);
            barImg.color = new Color(0.82f, 0.14f, 0.10f, 1f);
        }
        else barImg.color = new Color(0.82f, 0.14f, 0.10f, 1f);
        barImg.raycastTarget = false;

        row.slots = new Image[5];
        float innerPad = 5f;
        for (int s = 0; s < 5; s++)
        {
            var slotGo = new GameObject($"Slot{s}", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            slotGo.layer = 5;
            slotGo.transform.SetParent(barGo.transform, false);
            var slotRt = slotGo.GetComponent<RectTransform>();
            float frac = 0.2f;
            slotRt.anchorMin = new Vector2(s * frac, 0);
            slotRt.anchorMax = new Vector2((s + 1) * frac, 1);
            slotRt.offsetMin = new Vector2(innerPad, innerPad);
            slotRt.offsetMax = new Vector2(-innerPad, -innerPad);
            var slotImg = slotGo.GetComponent<Image>();
            slotImg.color = MenuConfig.SlotEmpty;
            slotImg.raycastTarget = false;
            row.slots[s] = slotImg;
        }

        return row;
    }

    static void SetupSliced(Image img, Sprite spr)
    {
        img.sprite = spr;
        img.type = Image.Type.Sliced;
        img.fillCenter = true;
        img.color = Color.white;
        img.pixelsPerUnitMultiplier = 1f;
        img.useSpriteMesh = false;
    }
}
