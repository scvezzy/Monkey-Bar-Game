using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Только визуал кнопок upgrade — НЕ двигает и НЕ пересобирает UI.
/// </summary>
public static class UpgradeVisualOnlyTool
{
    const string BtnPath = "Assets/UI/Menu/esc/spr_upgrade_name.png";

    [MenuItem("Tools/MonkeyBar/Применить стиль кнопок (без перемещения)")]
    public static void Apply()
    {
        if (Application.isPlaying)
        {
            Debug.LogError("Останови Play перед применением.");
            return;
        }

        FixMenuSpriteTool.FixAllMenuSpritesSilent();
        AssetDatabase.Refresh();

        Sprite btnSpr = null;
        foreach (var o in AssetDatabase.LoadAllAssetsAtPath(BtnPath))
            if (o is Sprite s) { btnSpr = s; break; }

        if (btnSpr == null)
        {
            Debug.LogError("spr_button не найден.");
            return;
        }

        int count = 0;
        foreach (var img in Object.FindObjectsByType<Image>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (img.gameObject.name != "BtnUpgrade") continue;
            img.sprite = btnSpr;
            img.type = Image.Type.Sliced;
            img.fillCenter = true;
            img.preserveAspect = false;
            img.color = Color.white;
            EditorUtility.SetDirty(img);

            var btn = img.GetComponent<Button>();
            if (btn != null)
            {
                var cb = btn.colors;
                cb.normalColor = Color.white;
                btn.colors = cb;
                EditorUtility.SetDirty(btn);
            }
            count++;
        }

        foreach (var row in Object.FindObjectsByType<UpgradeRowUI>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (row.costLabel != null)
            {
                row.costLabel.fontStyle = FontStyle.Bold;
                row.costLabel.alignment = TextAnchor.MiddleLeft;
                EditorUtility.SetDirty(row.costLabel);
            }
        }

        var assets = Object.FindAnyObjectByType<MenuUIAssets>();
        if (assets != null)
        {
            assets.buttonSprite  = btnSpr;
            assets.tooltipSprite = btnSpr;
            EditorUtility.SetDirty(assets);
        }

        Debug.Log($"[UpgradeVisual] spr_upgrade_name на {count} кнопках + tooltip. Ctrl+S.");
    }
}
