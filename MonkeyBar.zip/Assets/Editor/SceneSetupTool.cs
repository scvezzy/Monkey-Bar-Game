using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;

/// <summary>
/// Editor-утилита: настраивает сцену MonkeyBar одной кнопкой.
/// Menu: Tools → MonkeyBar → Setup Scene
/// </summary>
public static class SceneSetupTool
{
    // Floor scale 17.6 x 10.5 → видимая область примерно X: -8.8..+8.8, Y: -5.2..+5.2
    // Официант: правый верхний угол  → X: +5,   Y: +2
    // Столы:    левая сторона        → X: -4..-1, Y: -0.5..-2
    // Дверь:    правый нижний угол   → X: +7,   Y: -3.5

    [MenuItem("Tools/MonkeyBar/Setup Scene")]
    public static void SetupScene()
    {
        if (Application.isPlaying)
        {
            Debug.LogError("[SceneSetupTool] Останови Play (■) перед Setup Scene!");
            return;
        }

        CleanMissingScripts();
        ConfigureResourcesAssets();
        SetupBackground();   // фон, стена, пол с полосами, зона официанта
        SetupGameManager();
        SetupDoor();
        SetupWaiter();
        SetupTables();
        CreateMonkeyPrefab();
        SetupDayMenu();

        // GameHUD — шкала таймера + иконка песочных часов
        // Пересоздаём каждый раз чтобы UI был актуальным
        GameObject oldFrame = GameObject.Find("GameFrameCanvas");
        if (oldFrame != null) Object.DestroyImmediate(oldFrame);

        GameObject oldHUD = GameObject.Find("GameHUD");
        if (oldHUD != null) Object.DestroyImmediate(oldHUD);

        {
            GameObject hud = new GameObject("GameHUD");
            hud.AddComponent<GameHUD>();
            hud.AddComponent<WaiterCursor>();
            MarkDirty(hud);
            Debug.Log("[Setup] GameHUD создан (шкала + иконка)");
        }

        EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
        Debug.Log("[SceneSetupTool] Готово! Нажми Play.");
    }

    // ── Фон сцены: пол, стена, зона официанта ────────────────────────────
    static void SetupBackground()
    {
        Sprite sq = GetSquareSprite();

        // ── Зелёный игровой пол (основная зона) ──────────────────────────
        MakeBgSprite("BgFloor", sq, new Color(0.35f, 0.48f, 0.25f),
                     new Vector3(-1f, -1.5f, 1f), new Vector3(14f, 8f, 1f), -5);

        // ── Полосы-дощечки (3D перспектива пола) — горизонтальные полосы ─
        Color stripeDark  = new Color(0.30f, 0.42f, 0.20f);
        Color stripeLight = new Color(0.38f, 0.52f, 0.28f);
        float stripeH = 0.55f;
        // 7 полос от Y=-5.5 до Y=1.5
        for (int i = 0; i < 9; i++)
        {
            float y = -5.2f + i * stripeH * 2f;
            Color c = (i % 2 == 0) ? stripeDark : stripeLight;
            MakeBgSprite($"FloorStripe{i}", sq, c,
                         new Vector3(-1f, y, 0.9f), new Vector3(14f, stripeH, 1f), -4);
        }

        // ── Стена сверху (кирпичная полоса) ──────────────────────────────
        MakeBgSprite("WallBack", sq, new Color(0.55f, 0.32f, 0.22f),
                     new Vector3(-1f, 3.2f, 1f), new Vector3(14f, 1.8f, 1f), -3);

        // Верхняя тёмная полоска стены
        MakeBgSprite("WallTop", sq, new Color(0.72f, 0.52f, 0.35f),
                     new Vector3(-1f, 4.0f, 1f), new Vector3(14f, 0.6f, 1f), -3);

        // ── Зона официанта — бежевый фон (барная стойка) ─────────────────
        // Ищем ZoneWaiter чтобы совпасть с его позицией
        GameObject zone = null;
        foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsInactive.Include))
            if (t.name == "ZoneWaiter" || t.name == "ZoneWaiter1") { zone = t.gameObject; break; }

        if (zone != null)
        {
            Renderer zr = zone.GetComponent<Renderer>();
            Vector3 zpos  = zone.transform.position;
            Vector3 zsize = zr != null
                ? new Vector3(zr.bounds.size.x, zr.bounds.size.y, 1f)
                : new Vector3(4f, 3f, 1f);

            // Фон зоны — бежевый
            MakeBgSprite("ZoneBg", sq, new Color(0.72f, 0.58f, 0.38f),
                         new Vector3(zpos.x, zpos.y, 0.8f), zsize, -2);

            // Тёмная рамка зоны
            MakeBgSprite("ZoneBorder", sq, new Color(0.40f, 0.25f, 0.10f, 0.6f),
                         new Vector3(zpos.x, zpos.y, 0.8f),
                         new Vector3(zsize.x + 0.15f, zsize.y + 0.15f, 1f), -3);

            // Скрываем SpriteRenderer самой зоны чтобы не двоилось
            SpriteRenderer zoneSR = zone.GetComponent<SpriteRenderer>();
            if (zoneSR != null) zoneSR.enabled = false;
        }

        // ── Небо / задник сверху ──────────────────────────────────────────
        MakeBgSprite("BgSky", sq, new Color(0.85f, 0.72f, 0.52f),
                     new Vector3(-1f, 5.5f, 1f), new Vector3(14f, 3f, 1f), -6);

        Debug.Log("[Setup] Фон настроен");
    }

    static void MakeBgSprite(string name, Sprite sp, Color color,
                              Vector3 pos, Vector3 scale, int sortOrder)
    {
        // Ищем существующий
        GameObject go = null;
        foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsInactive.Include))
            if (t.name == name) { go = t.gameObject; break; }

        if (go == null) go = new GameObject(name);
        go.transform.position   = pos;
        go.transform.localScale = scale;

        SpriteRenderer sr = go.GetComponent<SpriteRenderer>();
        if (sr == null) sr = go.AddComponent<SpriteRenderer>();
        sr.sprite       = sp;
        sr.color        = color;
        sr.sortingOrder = sortOrder;

        MarkDirty(go);
    }

    static Sprite GetSquareSprite()
    {
        // Берём встроенный спрайт Square из любого объекта на сцене
        foreach (var sr in Object.FindObjectsByType<SpriteRenderer>(FindObjectsInactive.Include))
            if (sr.sprite != null && sr.sprite.name == "Square") return sr.sprite;
        return null;
    }

    // ── Удаление битых компонентов ────────────────────────────────────────
    static void CleanMissingScripts()
    {
        int removed = 0;
        foreach (GameObject go in Object.FindObjectsByType<GameObject>())
        {
            int n = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(go);
            if (n > 0) { removed += n; MarkDirty(go); }
        }
        if (removed > 0) Debug.Log($"[Setup] Удалено битых компонентов: {removed}");
    }

    // ── GameManager ───────────────────────────────────────────────────────
    static void SetupGameManager()
    {
        GameObject gm = GameObject.Find("GameManager") ?? new GameObject("GameManager");

        if (gm.GetComponent<WaiterSelector>() == null)
            gm.AddComponent<WaiterSelector>();

        CustomerSpawner spawner = gm.GetComponent<CustomerSpawner>();
        if (spawner == null) spawner = gm.AddComponent<CustomerSpawner>();
        spawner.minGuestsPerDay = 3;
        spawner.maxGuestsPerDay = 5;
        spawner.entryStandOffset = new Vector2(-1.5f, 0f);
        spawner.enabled = false; // выключен до нажатия Start Day

        if (gm.GetComponent<DayTimer>() == null)
            gm.AddComponent<DayTimer>();

        // GameData — DontDestroyOnLoad синглтон
        if (GameData.Instance == null && GameObject.Find("GameData") == null)
        {
            GameObject gdObj = new GameObject("GameData");
            gdObj.AddComponent<GameData>();
        }

        GameObject door = GameObject.Find("Door");
        if (door != null) spawner.doorPoint = door.transform;

        MarkDirty(gm);
        Debug.Log("[Setup] GameManager настроен");
    }

    static void SetupDoor()
    {
        GameObject door = GameObject.Find("Door");
        if (door == null) door = new GameObject("Door");
        // Позицию Door НЕ трогаем — пользователь ставит сам

        GameObject gm = GameObject.Find("GameManager");
        if (gm != null)
        {
            CustomerSpawner spawner = gm.GetComponent<CustomerSpawner>();
            if (spawner != null) spawner.doorPoint = door.transform;
        }

        MarkDirty(door);
    }

    // ── Waiter — правый верхний угол ──────────────────────────────────────
    static void SetupWaiter()
    {
        // Создаём/настраиваем всех 4 официантов
        SetupOneWaiter("Waiter",  WaiterType.Normie,  new Vector3( 5f,  2f, 0f), true);
        SetupOneWaiter("Waiter2", WaiterType.Weeb,    new Vector3( 3f,  2f, 0f), false);
        SetupOneWaiter("Waiter3", WaiterType.Gamer,   new Vector3( 5f,  0f, 0f), false);
        SetupOneWaiter("Waiter4", WaiterType.Tourist, new Vector3( 3f,  0f, 0f), false);
    }

    static void SetupOneWaiter(string objName, WaiterType type, Vector3 pos, bool startActive)
    {
        GameObject w = null;
        foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsInactive.Include))
            if (t.name == objName) { w = t.gameObject; break; }

        if (w == null)
        {
            w = new GameObject(objName);
            w.AddComponent<SpriteRenderer>();
            w.transform.position = pos; // позиция только при первом создании
        }
        // Существующий объект — позицию НЕ трогаем

        w.SetActive(startActive);

        GameObjectUtility.RemoveMonoBehavioursWithMissingScript(w);

#pragma warning disable CS0618
        WaiterData old = w.GetComponent<WaiterData>();
#pragma warning restore CS0618
        if (old != null) Object.DestroyImmediate(old);

        SpriteRenderer sr = w.GetComponent<SpriteRenderer>();
        if (sr == null) sr = w.AddComponent<SpriteRenderer>();
        switch (type)
        {
            case WaiterType.Normie:  sr.color = new Color(0.2f, 0.5f, 1.0f); break;
            case WaiterType.Weeb:    sr.color = new Color(0.8f, 0.2f, 0.8f); break;
            case WaiterType.Gamer:   sr.color = new Color(0.2f, 0.9f, 0.3f); break;
            case WaiterType.Tourist: sr.color = new Color(1.0f, 0.6f, 0.1f); break;
        }
        sr.sortingOrder = 2;

        WaiterController wc = w.GetComponent<WaiterController>();
        if (wc == null) wc = w.AddComponent<WaiterController>();
        wc.waiterType  = type;
        wc.moveSpeed   = 3f;
        wc.idleWaitMin = 1.5f;
        wc.idleWaitMax = 3.5f;

        if (w.GetComponent<Collider2D>() == null) w.AddComponent<BoxCollider2D>();
        w.transform.localScale = new Vector3(0.6f, 0.6f, 1f);

        MarkDirty(w);
        Debug.Log($"[Setup] {objName} ({type}) → {pos}, active={startActive}");
    }

    // ── Tables — только добавляем TableData, позиции не трогаем ──────────
    static void SetupTables()
    {
        string[] tableNames = { "Table1", "Table2", "Table3" };

        foreach (string name in tableNames)
        {
            GameObject t = GameObject.Find(name);
            if (t == null) continue;

            if (t.GetComponent<TableData>() == null)
            {
                t.AddComponent<TableData>();
                Debug.Log($"[Setup] Добавлен TableData на {name}");
            }

            MarkDirty(t);
        }
    }

    // ── Monkey Prefab ─────────────────────────────────────────────────────
    static void CreateMonkeyPrefab()
    {
        const string prefabPath = "Assets/Prefabs/Monkey.prefab";
        AssetDatabase.DeleteAsset(prefabPath);

        GameObject monkey = new GameObject("Monkey");

        SpriteRenderer sr = monkey.AddComponent<SpriteRenderer>();

        // Берём спрайт "Square" — он точно есть в любом Unity проекте
        // это тот самый спрайт который используется на столах-заглушках
        Sprite sq = null;

        // Способ 1: с одного из столов
        foreach (string tName in new[]{"Table1","Table2","Table3"})
        {
            GameObject t = GameObject.Find(tName);
            if (t == null) continue;
            SpriteRenderer tsr = t.GetComponent<SpriteRenderer>();
            if (tsr != null && tsr.sprite != null) { sq = tsr.sprite; break; }
        }

        // Способ 2: с официанта
        if (sq == null)
        {
            GameObject w = GameObject.Find("Waiter");
            if (w != null)
            {
                SpriteRenderer wsr = w.GetComponent<SpriteRenderer>();
                if (wsr != null && wsr.sprite != null) sq = wsr.sprite;
            }
        }

        sr.sprite = sq;
        sr.color  = new Color(0.15f, 0.8f, 0.15f); // зелёный

        // Сортировка — мартышка поверх стола
        sr.sortingOrder = 2;

        monkey.transform.localScale = new Vector3(0.45f, 0.45f, 1f);

        monkey.AddComponent<MonkeyCustomer>();
        BoxCollider2D col = monkey.AddComponent<BoxCollider2D>();
        col.size = Vector2.one;

        // ── Облачко заказа (child object) ──────────────────────────────
        GameObject bubble = new GameObject("OrderBubble");
        bubble.transform.SetParent(monkey.transform);
        bubble.transform.localPosition = new Vector3(0.5f, 0.7f, 0f);
        bubble.transform.localScale    = new Vector3(0.7f, 0.7f, 1f);

        SpriteRenderer bubbleSR = bubble.AddComponent<SpriteRenderer>();
        bubbleSR.sprite       = sq;   // тот же спрайт-квадрат
        bubbleSR.color        = Color.white;
        bubbleSR.sortingOrder = 3;    // поверх всего
        bubbleSR.enabled      = false; // скрыто по умолчанию

        bubble.AddComponent<OrderBubble>();

        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(monkey, prefabPath);
        Object.DestroyImmediate(monkey);

        GameObject gm = GameObject.Find("GameManager");
        if (gm != null)
        {
            CustomerSpawner sp = gm.GetComponent<CustomerSpawner>();
            if (sp != null) { sp.monkeyPrefab = prefab; MarkDirty(gm); }
        }

        AssetDatabase.SaveAssets();
        Debug.Log("[Setup] Monkey prefab создан. Sprite: " + (sq != null ? sq.name : "NULL — назначь вручную!"));
    }

    // ── GameFrame — рамка + шкала таймера ────────────────────────────────
    static void SetupGameFrame()
    {
        // Удаляем старый если есть
        GameObject old = GameObject.Find("GameFrameCanvas");
        if (old != null) Object.DestroyImmediate(old);

        // Canvas — sortingOrder ниже меню (5), выше игры
        GameObject frameCanvas = new GameObject("GameFrameCanvas");
        Canvas canvas = frameCanvas.AddComponent<Canvas>();
        canvas.renderMode   = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 5;
        UnityEngine.UI.CanvasScaler scaler = frameCanvas.AddComponent<UnityEngine.UI.CanvasScaler>();
        scaler.uiScaleMode         = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1024, 600);
        frameCanvas.AddComponent<UnityEngine.UI.GraphicRaycaster>();

        GameFrame gf = frameCanvas.AddComponent<GameFrame>();

        // ── Тёмная рамка по периметру (4 полосы) ─────────────────────────
        Color frameColor = new Color(0.1f, 0.12f, 0.18f, 1f); // тёмно-синяя

        // Верхняя полоса
        MakeFrameBar("FrameTop",    frameCanvas.transform, new Vector2(0, 1), new Vector2(1, 1),
                     new Vector2(0, -40), new Vector2(0, 0), frameColor);
        // Левая
        MakeFrameBar("FrameLeft",   frameCanvas.transform, new Vector2(0, 0), new Vector2(0, 1),
                     new Vector2(0, 0), new Vector2(12, 0), frameColor);
        // Правая
        MakeFrameBar("FrameRight",  frameCanvas.transform, new Vector2(1, 0), new Vector2(1, 1),
                     new Vector2(-12, 0), new Vector2(0, 0), frameColor);
        // Нижняя полоса — толще, там шкала
        MakeFrameBar("FrameBottom", frameCanvas.transform, new Vector2(0, 0), new Vector2(1, 0),
                     new Vector2(0, 0), new Vector2(0, 75), frameColor);

        // ── Панель шкалы (поверх нижней рамки) ───────────────────────────
        GameObject timerPanel = new GameObject("TimerPanel");
        timerPanel.transform.SetParent(frameCanvas.transform, false);
        timerPanel.SetActive(true); // всегда видна в игре

        // Иконка песочных часов (просто тёмный квадрат-заглушка)
        GameObject hourglassBox = new GameObject("Hourglass");
        hourglassBox.transform.SetParent(timerPanel.transform, false);
        UnityEngine.UI.Image hgImg = hourglassBox.AddComponent<UnityEngine.UI.Image>();
        hgImg.color = new Color(0.35f, 0.22f, 0.08f);
        RectTransform hgRT = hourglassBox.GetComponent<RectTransform>();
        hgRT.anchorMin = new Vector2(0f, 0f);
        hgRT.anchorMax = new Vector2(0f, 0f);
        hgRT.pivot     = new Vector2(0f, 0f);
        hgRT.anchoredPosition = new Vector2(8f, 8f);
        hgRT.sizeDelta = new Vector2(55f, 55f);

        // Фон шкалы
        GameObject barBg = new GameObject("TimerBarBg");
        barBg.transform.SetParent(timerPanel.transform, false);
        UnityEngine.UI.Image barBgImg = barBg.AddComponent<UnityEngine.UI.Image>();
        barBgImg.color = new Color(0.2f, 0.2f, 0.25f, 1f);
        RectTransform barBgRT = barBg.GetComponent<RectTransform>();
        barBgRT.anchorMin = new Vector2(0f, 0f);
        barBgRT.anchorMax = new Vector2(1f, 0f);
        barBgRT.pivot     = new Vector2(0f, 0f);
        barBgRT.anchoredPosition = new Vector2(72f, 18f);
        barBgRT.sizeDelta = new Vector2(-90f, 36f);

        // Fill шкалы
        GameObject fill = new GameObject("TimerBarFill");
        fill.transform.SetParent(barBg.transform, false);
        UnityEngine.UI.Image fillImg = fill.AddComponent<UnityEngine.UI.Image>();
        fillImg.color      = new Color(0.25f, 1f, 0.78f);
        fillImg.type       = UnityEngine.UI.Image.Type.Filled;
        fillImg.fillMethod = UnityEngine.UI.Image.FillMethod.Horizontal;
        fillImg.fillOrigin = 0;
        fillImg.fillAmount = 1f;
        RectTransform fillRT = fill.GetComponent<RectTransform>();
        fillRT.anchorMin = Vector2.zero;
        fillRT.anchorMax = Vector2.one;
        fillRT.offsetMin = new Vector2(4, 4);
        fillRT.offsetMax = new Vector2(-4, -4);

        // Привязываем к GameFrame
        gf.timerFill  = fillImg;
        gf.timerPanel = timerPanel;

        // Привязываем к DayTimer
        GameObject gm = GameObject.Find("GameManager");
        if (gm != null)
        {
            DayTimer dt = gm.GetComponent<DayTimer>();
            if (dt == null) dt = gm.AddComponent<DayTimer>();
            // Старые ссылки очищаем — теперь всё через GameFrame
            dt.timerBar          = null;
            dt.timerBarContainer = null;
            MarkDirty(gm);
        }

        MarkDirty(frameCanvas);
        Debug.Log("[Setup] GameFrame создан (рамка + шкала таймера)");
    }

    static void MakeFrameBar(string name, Transform parent,
                              Vector2 anchorMin, Vector2 anchorMax,
                              Vector2 offsetMin, Vector2 offsetMax,
                              Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        UnityEngine.UI.Image img = go.AddComponent<UnityEngine.UI.Image>();
        img.color = color;
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.offsetMin = offsetMin;
        rt.offsetMax = offsetMax;
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    static void MarkDirty(GameObject go)
    {
        if (Application.isPlaying) return;
        EditorUtility.SetDirty(go);
        if (go.scene.IsValid())
            EditorSceneManager.MarkSceneDirty(go.scene);
    }

    // ── Day Menu UI ───────────────────────────────────────────────────────
    static void SetupDayMenu()
    {
        GameObject existing = GameObject.Find("DayMenuUI");
        if (existing != null)
        {
            Transform panelT = existing.transform.Find("Panel");
            var menu = panelT != null ? panelT.GetComponent<DayMenuUI>() : null;
            if (menu != null && !menu.buildUIAtRuntime && panelT.childCount > 0)
            {
                EnsureEventSystem();
                EnsureAnnouncer(existing);
                WireSpawner(menu);
                MarkDirty(existing);
                Debug.Log("[Setup] DayMenuUI с ручным UI сохранён — дочерние объекты не удалены.");
                return;
            }
            Object.DestroyImmediate(existing);
        }

        EnsureEventSystem();
        GameObject canvasObj = new GameObject("DayMenuUI");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode   = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10;
        UnityEngine.UI.CanvasScaler scaler = canvasObj.AddComponent<UnityEngine.UI.CanvasScaler>();
        scaler.uiScaleMode         = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        canvasObj.AddComponent<UnityEngine.UI.GraphicRaycaster>();

        // Panel — растягивается на 92% высоты и 85% ширины экрана
        GameObject panel = new GameObject("Panel");
        panel.transform.SetParent(canvasObj.transform, false);
        UnityEngine.UI.Image panelImg = panel.AddComponent<UnityEngine.UI.Image>();
        panelImg.color = new Color(0.72f, 0.52f, 0.30f, 1f);
        RectTransform panelRT = panel.GetComponent<RectTransform>();
        // Stretch anchors: занимает 85% ширины и 92% высоты Canvas
        panelRT.anchorMin        = new Vector2(0.075f, 0.04f);
        panelRT.anchorMax        = new Vector2(0.925f, 0.96f);
        panelRT.offsetMin        = Vector2.zero;
        panelRT.offsetMax        = Vector2.zero;

        DayMenuUI menuScript = panel.AddComponent<DayMenuUI>();
        menuScript.buildUIAtRuntime = false;
        WireSpawner(menuScript);
        EnsureAnnouncer(canvasObj);

        SetupDayTimerBar(canvasObj);

        MarkDirty(canvasObj);
        Debug.Log("[Setup] DayMenuUI создан (ручной UI — buildUIAtRuntime = false)");
    }

    static void EnsureEventSystem()
    {
        if (Object.FindAnyObjectByType<UnityEngine.EventSystems.EventSystem>() != null) return;
        GameObject es = new GameObject("EventSystem");
        es.AddComponent<UnityEngine.EventSystems.EventSystem>();
        es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
    }

    static void EnsureAnnouncer(GameObject canvasObj)
    {
        if (canvasObj.GetComponentInChildren<DayAnnouncer>() != null) return;
        GameObject ann = new GameObject("DayAnnouncer");
        ann.transform.SetParent(canvasObj.transform, false);
        ann.AddComponent<DayAnnouncer>();
    }

    static void WireSpawner(DayMenuUI menuScript)
    {
        GameObject gm = GameObject.Find("GameManager");
        if (gm == null) return;
        CustomerSpawner sp = gm.GetComponent<CustomerSpawner>();
        if (sp != null) menuScript.customerSpawner = sp;
    }

    static void SetupDayTimerBar(GameObject canvasObj)
    {
        // Убираем старый контейнер если есть
        Transform old = canvasObj.transform.Find("TimerBarContainer");
        if (old != null) Object.DestroyImmediate(old.gameObject);

        // Контейнер — скрыт по умолчанию, показывается только в игре
        GameObject container = new GameObject("TimerBarContainer");
        container.transform.SetParent(canvasObj.transform, false);
        container.SetActive(false);

        // Фон полоски — внизу экрана
        GameObject barBg = new GameObject("TimerBarBackground");
        barBg.transform.SetParent(container.transform, false);
        UnityEngine.UI.Image bgImg = barBg.AddComponent<UnityEngine.UI.Image>();
        bgImg.color = new Color(0.12f, 0.12f, 0.18f, 0.9f);
        RectTransform bgRT = barBg.GetComponent<RectTransform>();
        // Привязка к низу экрана
        bgRT.anchorMin = new Vector2(0.08f, 0f);
        bgRT.anchorMax = new Vector2(0.95f, 0f);
        bgRT.pivot     = new Vector2(0.5f, 0f);
        bgRT.anchoredPosition = new Vector2(0f, 15f);
        bgRT.sizeDelta = new Vector2(0f, 32f);

        // Fill
        GameObject fill = new GameObject("TimerBarFill");
        fill.transform.SetParent(barBg.transform, false);
        UnityEngine.UI.Image fillImg = fill.AddComponent<UnityEngine.UI.Image>();
        fillImg.color      = new Color(0.25f, 1f, 0.75f);
        fillImg.type       = UnityEngine.UI.Image.Type.Filled;
        fillImg.fillMethod = UnityEngine.UI.Image.FillMethod.Horizontal;
        fillImg.fillOrigin = 0;
        fillImg.fillAmount = 1f;
        RectTransform fillRT = fill.GetComponent<RectTransform>();
        fillRT.anchorMin = Vector2.zero; fillRT.anchorMax = Vector2.one;
        fillRT.offsetMin = fillRT.offsetMax = Vector2.zero;

        // DayTimer
        GameObject gm = GameObject.Find("GameManager");
        if (gm != null)
        {
            DayTimer dt = gm.GetComponent<DayTimer>();
            if (dt == null) dt = gm.AddComponent<DayTimer>();
            dt.timerBar          = fillImg;
            dt.timerBarContainer = container;
            MarkDirty(gm);
        }
    }

    static void ConfigureResourcesAssets()
    {
        ConfigureSpriteFolder("Assets/Resources/Menu/pint");

        var fontImp = AssetImporter.GetAtPath("Assets/Resources/Fonts/PlainPixel-Regular.ttf") as TrueTypeFontImporter;
        if (fontImp != null)
        {
            fontImp.fontRenderingMode = FontRenderingMode.Smooth;
            fontImp.SaveAndReimport();
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    static void ConfigureSpriteFolder(string folder)
    {
        foreach (string guid in AssetDatabase.FindAssets("t:Texture2D", new[] { folder }))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp == null) continue;

            imp.textureType         = TextureImporterType.Sprite;
            imp.spriteImportMode    = SpriteImportMode.Single;
            imp.filterMode          = FilterMode.Point;
            imp.textureCompression  = TextureImporterCompression.Uncompressed;
            imp.alphaIsTransparency = true;
            imp.mipmapEnabled       = false;
            imp.spritePixelsToUnits = 100f;
            imp.SaveAndReimport();
        }
    }
}
