using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Одна кнопка — ставит окна меню на Panel и чинит спрайты.
/// </summary>
public static class MenuWindowSetupTool
{
    const string FrameSpritePath = "Assets/UI/Menu/esc/spr_upgrade_sub.png";
    const string PanelSpritePath = "Assets/UI/Menu/esc/spr_upgrade_bg.png";

    [MenuItem("Tools/MonkeyBar/Поставить окна меню (ИСПРАВИТЬ)")]
    public static void SetupMenuWindows()
    {
        if (Application.isPlaying)
        {
            Debug.LogError("[MenuSetup] Останови Play (■) перед настройкой!");
            return;
        }

        FixMenuSpriteTool.FixSpritesSilent();

        GameObject canvasGo = GameObject.Find("DayMenuUI");
        if (canvasGo == null)
        {
            Debug.LogError("[MenuSetup] Нет DayMenuUI на сцене. Запусти Tools → MonkeyBar → Setup Scene.");
            return;
        }

        canvasGo.transform.localScale = Vector3.one;

        Transform panel = canvasGo.transform.Find("Panel");
        if (panel == null)
        {
            Debug.LogError("[MenuSetup] Нет Panel внутри DayMenuUI.");
            return;
        }

        RemoveOrphanFrames(panel);

        Sprite frameSprite = AssetDatabase.LoadAssetAtPath<Sprite>(FrameSpritePath);
        Sprite panelSprite = AssetDatabase.LoadAssetAtPath<Sprite>(PanelSpritePath);
        if (frameSprite == null)
        {
            Debug.LogError("[MenuSetup] Не найден спрайт: " + FrameSpritePath);
            return;
        }

        var panelImg = panel.GetComponent<Image>();
        if (panelImg != null && panelSprite != null)
        {
            panelImg.sprite = panelSprite;
            panelImg.type = Image.Type.Sliced;
            panelImg.color = Color.white;
            panelImg.raycastTarget = true;
        }

        var menu = panel.GetComponent<DayMenuUI>();
        if (menu != null)
            menu.buildUIAtRuntime = false;

        CreateWindow(panel, "upgrades", frameSprite, new Vector2(260, -160), new Vector2(480, 280));
        CreateWindow(panel, "pal list", frameSprite, new Vector2(780, -160), new Vector2(480, 280));
        CreateWindow(panel, "buds", frameSprite, new Vector2(260, -470), new Vector2(480, 200));

        EditorUtility.SetDirty(canvasGo);
        EditorSceneManager.MarkSceneDirty(panel.gameObject.scene);
        Debug.Log("[MenuSetup] Готово! 3 окна на Panel. Сохрани сцену (Ctrl+S).");
    }

    static void RemoveOrphanFrames(Transform panel)
    {
        foreach (var t in Object.FindObjectsByType<RectTransform>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (t.name != "WindowFrame" && t.name != "upgrades" && t.name != "pal list" && t.name != "buds")
                continue;
            if (t.parent == panel) continue;
            Object.DestroyImmediate(t.gameObject);
        }

        Transform lone = panel.Find("WindowFrame");
        if (lone != null && panel.Find("upgrades") == null)
            lone.name = "upgrades";
    }

    static void CreateWindow(Transform panel, string name, Sprite sprite, Vector2 pos, Vector2 size)
    {
        Transform existing = panel.Find(name);
        GameObject go = existing != null ? existing.gameObject : new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        go.transform.SetParent(panel, false);
        go.layer = 5;

        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0, 1);
        rt.anchorMax = new Vector2(0, 1);
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        rt.localScale = Vector3.one;

        var img = go.GetComponent<Image>();
        img.sprite = sprite;
        img.type = Image.Type.Sliced;
        img.color = Color.white;
        img.raycastTarget = false;
        img.fillCenter = true;

        EditorUtility.SetDirty(go);
    }
}
