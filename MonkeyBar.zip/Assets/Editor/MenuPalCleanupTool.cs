using UnityEditor;

using UnityEditor.SceneManagement;

using UnityEngine;

using UnityEngine.UI;



/// <summary>

/// Удаляет авто-слои (View/Base/Overlay) из Pal list и включает Icon обратно.

/// </summary>

[InitializeOnLoad]

public static class MenuPalCleanupTool

{

    static readonly string[] AutoLayerNames = { "View", "CanvasRoot", "Base", "Overlay", "Overlay2" };



    static MenuPalCleanupTool()

    {

        EditorApplication.delayCall += TryAutoCleanup;

    }



    static void TryAutoCleanup()

    {

        if (Application.isPlaying || BuildPipeline.isBuildingPlayer)

            return;



        if (CountAutoLayers() == 0)

            return;



        CleanupPalListLayersInternal(saveScene: true, log: true);

    }



    [MenuItem("Tools/MonkeyBar/Убрать авто-слои Pal list (откат)")]

    public static void CleanupPalListLayers()

    {

        if (Application.isPlaying)

        {

            Debug.LogError("[PalCleanup] Останови Play.");

            return;

        }



        CleanupPalListLayersInternal(saveScene: true, log: true);

    }



    /// <summary>Batchmode: Unity.exe -executeMethod MenuPalCleanupTool.BatchCleanup</summary>

    public static void BatchCleanup()

    {

        EditorSceneManager.OpenScene("Assets/monkeyBar.unity");

        CleanupPalListLayersInternal(saveScene: true, log: true);

        EditorApplication.Exit(0);

    }



    static int CountAutoLayers()

    {

        var palList = GameObject.Find("pal list");

        if (palList == null)

            return 0;



        int count = 0;

        foreach (var slot in palList.GetComponentsInChildren<PalSlotUI>(true))

        {

            foreach (string name in AutoLayerNames)

            {

                if (slot.transform.Find(name) != null)

                    count++;

            }

        }



        return count;

    }



    static void CleanupPalListLayersInternal(bool saveScene, bool log)

    {

        var palList = GameObject.Find("pal list");

        if (palList == null)

        {

            if (log)

                Debug.LogWarning("[PalCleanup] Нет объекта «pal list» на сцене.");

            return;

        }



        int removed = 0;

        foreach (var slot in palList.GetComponentsInChildren<PalSlotUI>(true))

        {

            foreach (string name in AutoLayerNames)

            {

                var t = slot.transform.Find(name);

                if (t == null) continue;

                Undo.DestroyObjectImmediate(t.gameObject);

                removed++;

            }



            var iconT = slot.transform.Find("Icon");

            if (iconT != null)

            {

                var img = iconT.GetComponent<Image>();

                if (img != null && !img.enabled)

                {

                    img.enabled = true;

                    EditorUtility.SetDirty(img);

                }

            }

        }



        if (removed > 0)

        {

            EditorUtility.SetDirty(palList);

            EditorSceneManager.MarkSceneDirty(palList.scene);

        }



        if (saveScene && removed > 0)

            EditorSceneManager.SaveOpenScenes();



        if (log)

        {

            if (removed > 0)

                Debug.Log($"[PalCleanup] Готово. Удалено объектов: {removed}. Icon включён. Сцена сохранена.");

            else

                Debug.Log("[PalCleanup] Лишних слоёв нет — Pal list уже чистый (Icon + Label).");

        }

    }

}


