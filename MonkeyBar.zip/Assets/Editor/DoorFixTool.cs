using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

/// <summary>
/// Чинит объект Door и ссылку doorPoint в CustomerSpawner. Столы не трогает.
/// </summary>
[InitializeOnLoad]
public static class DoorFixTool
{
    static readonly Vector3 DefaultDoorPos = new Vector3(9f, -3.6f, 0f);

    static DoorFixTool()
    {
        EditorApplication.delayCall += TryAutoFix;
    }

    static void TryAutoFix()
    {
        if (Application.isPlaying || BuildPipeline.isBuildingPlayer)
            return;
        if (!NeedsFix())
            return;
        FixDoorInternal(saveScene: true, log: true);
    }

    static bool NeedsFix()
    {
        var door = GameObject.Find("Door");
        if (door == null)
            return false;

        if (door.transform.parent != null)
            return true;

        if (door.transform.position.sqrMagnitude < 4f)
            return true;

        var spawner = Object.FindFirstObjectByType<CustomerSpawner>();
        if (spawner != null && spawner.doorPoint == null)
            return true;

        if (spawner != null && spawner.doorPoint != door.transform)
            return true;

        return false;
    }

    [MenuItem("Tools/MonkeyBar/Починить Door (спавн гостей)")]
    public static void FixDoor()
    {
        if (Application.isPlaying)
        {
            Debug.LogError("[DoorFix] Останови Play.");
            return;
        }

        FixDoorInternal(saveScene: true, log: true);
    }

    public static void BatchFix()
    {
        EditorSceneManager.OpenScene("Assets/monkeyBar.unity");
        FixDoorInternal(saveScene: true, log: true);
        EditorApplication.Exit(0);
    }

    static void FixDoorInternal(bool saveScene, bool log)
    {
        var door = GameObject.Find("Door");
        if (door == null)
        {
            door = new GameObject("Door");
            Undo.RegisterCreatedObjectUndo(door, "Create Door");
        }

        if (door.transform.parent != null)
        {
            Undo.SetTransformParent(door.transform, null, "Unparent Door");
        }

        if (door.transform.position.sqrMagnitude < 4f)
        {
            Undo.RecordObject(door.transform, "Move Door");
            door.transform.position = DefaultDoorPos;
        }

        var spawner = Object.FindFirstObjectByType<CustomerSpawner>();
        if (spawner != null && spawner.doorPoint != door.transform)
        {
            Undo.RecordObject(spawner, "Wire doorPoint");
            spawner.doorPoint = door.transform;
            EditorUtility.SetDirty(spawner);
        }

        EditorUtility.SetDirty(door);
        EditorSceneManager.MarkSceneDirty(door.scene);

        if (saveScene)
            EditorSceneManager.SaveOpenScenes();

        if (log)
            Debug.Log($"[DoorFix] Door = {door.transform.position}. doorPoint привязан. Сцена сохранена.");
    }
}
