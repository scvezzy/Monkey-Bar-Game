# PROJECT_MEMORY — MonkeyBar (Unity 6, 2D Pixel)
# Документ для восстановления контекста в новом чате

---

## 1. КОНЦЕПЦИЯ ИГРЫ

2D пиксельная игра в жанре кафе-менеджера, вдохновлённая MonkeyPalsCafe.
- Игрок управляет кафе с мартышками-клиентами и официантами
- Управление: клавиши 1-4 выбирают официанта → клик на мартышку → официант идёт обслуживать
- Игра идёт по дням. Каждый день — таймер. Когда таймер истекает — меню с апгрейдами
- Цель: накопить 1000 монет (WinCoins)
- Движок: Unity 6, 2D, URP
- Визуал: **цветные квадраты-заглушки** (меню и геймплей — пользователь подключает спрайты сам)
- Ассеты из оригинала Monkey Pals Cafe — автор дал разрешение (itch.io/innocent-soul)

---

## 2. ЭТАП РАЗРАБОТКИ

**Playable Prototype** — все основные механики работают.
**Сейчас:** замена заглушек на спрайты из рипа (`Desktop/sprite/`) — **вручную пользователем**.

---

## 3. ЧТО РЕАЛИЗОВАНО И РАБОТАЕТ

- Спаун мартышек с интервалом из точки Door
- L-образное движение мартышек: пауза на входе → вниз по Y → влево по X к столу
- При уходе: вправо по X → вверх по Y к двери
- Случайный тип/цвет мартышки при спауне (зелёный/фиолетовый/синий/оранжевый)
- Состояния мартышки: WalkingToTable → WaitingOrder → BeingServed → Eating → Leaving
- Мартышка злится (краснеет) если долго ждёт, затем уходит
- Облачко заказа над мартышкой (OrderBubble, покачивается)
- Выбор официанта клавишами 1-4, иконка с номером следует за курсором
- Клик на мартышку отправляет выбранного официанта
- Официант движется L-образно (сначала по X, потом по Y)
- Официант останавливается СБОКУ от мартышки (serveOffset = 0.55, 0)
- Официант патрулирует свою зону (ZoneWaiter объект)
- Возврат официанта: к ближайшей точке границы зоны (не в центр)
- Начисление +10 монет и popup "+10" при обслуживании
- Таймер дня (45с базово, до 120с с прокачкой)
- Шкала таймера внизу экрана: убывает справа налево (fillOrigin=1), меняет цвет бирюзовый→жёлтый→красный
- Иконка песочных часов слева от шкалы
- Анимации "DAY X START" / "DAY END" по центру экрана
- Меню между днями (DayMenuUI): слайд снизу, Time.timeScale=0 пока открыто
- При старте дня: очищаются все мартышки, освобождаются столы, применяются официанты
- Система прокачки 4 типа × 5 уровней
- Тултип на кнопках upgrade (русский текст, следует за курсором)
- Разблокировка официантов по условию (Weeb:5, Gamer:15, Gaijin:25 обслуженных)
- Кнопка UNLOCK в меню активирует официанта на сцене
- GameData (DontDestroyOnLoad) — данные между днями

---

## 4. СИСТЕМА ПРОКАЧКИ

| Тип | Уровни 0→5 | Стоимость каждого | Эффект |
|-----|-----------|-------------------|--------|
| Table | 0→5 | 80 монет | Активных столов: 3+level (3..8) |
| Speed | 0→5 | 30 монет | Скорость официанта: 3+level*0.5 (3..5.5) |
| ServingTime | 0→5 | 40 монет | Время обслуживания: 5-level*0.8 (5..1 сек); Терпение клиентов: 6+level*2 (6..16 сек) |
| DayTime | 0→5 | 15 монет | Длительность дня: [45,72,96,108,120] сек |

---

## 5. СИСТЕМА ОФИЦИАНТОВ

| Объект | Тип | Условие разблокировки | Зона патруля |
|--------|-----|-----------------------|--------------|
| Waiter | Normie | активен с начала | ZoneWaiter или ZoneWaiter1 |
| Waiter2 | Weeb | 5 обслуженных | ZoneWaiter2 |
| Waiter3 | Gamer | 15 обслуженных | ZoneWaiter3 |
| Waiter4 | Tourist | 25 обслуженных | ZoneWaiter4 |

WaiterController.TryFindZone() ищет зону по имени автоматически.
Зона задаётся объектом с Renderer — официант патрулирует внутри его bounds.
Официанты Waiter2/3/4 на сцене существуют но SetActive(false) до разблокировки.

---

## 6. КЛЮЧЕВЫЕ СКРИПТЫ

| Скрипт | Назначение |
|--------|-----------|
| `GameData.cs` | DontDestroyOnLoad синглтон. Монеты, TotalServed, DayNumber, уровни прокачки, флаги разблокировки. UnlockWaiter(), BuyUpgrade(), ApplyWaiters(). |
| `MonkeyCustomer.cs` | Полный цикл мартышки. L-движение с паузами. Цвет хранится в _myColor (не перезаписывается при смене состояния кроме злости). ServeCustomer() / FinishServing(). OnMouseDown() вызывает официанта. |
| `CustomerSpawner.cs` | Интервальный спаун. AssignRandomMonkeyType() красит по типу. ApplyTableUpgrade() скрывает/показывает столы. |
| `WaiterController.cs` | L-образное движение (WalkingAxis1→WalkingAxis2). serveOffset отступ при обслуживании. ReturnToZone() к ближайшей точке зоны. Автопоиск зоны по имени. |
| `WaiterSelector.cs` | Клавиши 1-4. Static: selectedWaiter, selectedIndex. |
| `WaiterCursor.cs` | Иконка у курсора. Динамически строится в Awake. Позиция через localPos + canvasSize*0.5f. |
| `DayTimer.cs` | Отсчёт времени дня. StartDay() / EndDay(). Вызывает GameHUD.SetFill(t) каждый кадр. |
| `GameHUD.cs` | Canvas sortingOrder=5. Шкала таймера строится в BuildHUD(). fillOrigin=1 (убывает справа). SetFill(t) меняет fillAmount и цвет. StartTimer() показывает панель. |
| `DayMenuUI.cs` | Меню между днями. BuildUI() — цветные квадраты, Pixellari через UIFonts. |
| `MenuConfig.cs` | Размеры/цвета/шрифты меню. |
| `UIFonts.cs` | Pixellari.ttf из Resources/Fonts/ (опционально) |
| `TableData.cs` | occupied флаг + seatPoint (Transform, опционально). GetSeatPosition() возвращает seatPoint или transform.position. |
| `CustomerState.cs` | Enum: WalkingToTable, WaitingOrder, BeingServed, Eating, Leaving. |
| `WaiterType.cs` | Enum: Normie, Weeb, Gamer, Tourist. (Tourist = "Gaijin" в UI — расхождение!) |
| `OrderBubble.cs` | Покачивающийся спрайт над мартышкой. OrderType enum: Banana, Coffee, Juice, Food. |
| `DayAnnouncer.cs` | Анимация "DAY X START/END". unscaledDeltaTime. Singleton. |
| `CoinPopup.cs` | Статический Spawn(). Всплывающий "+10" зелёным текстом. |
| `UpgradeTooltip.cs` | IPointerEnter/Exit. Статический _tooltipGO. Позиция: localPos + canvasSize*0.5f + (14,14). Описания на русском. |
| `GameFrame.cs` | [RequireComponent(Canvas)]. ShowTimer/HideTimer через timerPanel. Legacy — не создаётся автоматически. |
| `WaiterData.cs` | [Obsolete]. Не используется. Оставлен для совместимости. |
| `SceneSetupTool.cs` (Editor) | Tools → MonkeyBar → Setup Scene |

---

## 7. ОБЪЕКТЫ НА СЦЕНЕ (актуально)

| Объект | Компоненты | Примечания |
|--------|-----------|-----------|
| `Floor` | SpriteRenderer | Жёлтый пол. Позицию/размер не трогать. |
| `Table1, Table2, Table3` | SpriteRenderer, TableData | Активные оранжевые столы. Позиции — пользовательские. |
| `Table4..Table8` | SpriteRenderer, TableData | Скрытые. Открываются прокачкой Tables. |
| `Waiter` | SpriteRenderer, WaiterController, BoxCollider2D | Normie. Активен. Позиция — пользовательская. |
| `Waiter2` | SpriteRenderer, WaiterController, BoxCollider2D | Weeb. SetActive(false). |
| `Waiter3` | SpriteRenderer, WaiterController, BoxCollider2D | Gamer. SetActive(false). |
| `Waiter4` | SpriteRenderer, WaiterController, BoxCollider2D | Tourist. SetActive(false). |
| `ZoneWaiter` | SpriteRenderer (видимый!) | Зона патруля Normie. Специально сделан видимым как намёк на зону барной стойки. Цвет/позицию не трогать. |
| `GameManager` | WaiterSelector, CustomerSpawner, DayTimer | CustomerSpawner.enabled=false до Start Day. |
| `GameData` | GameData | DontDestroyOnLoad. |
| `Door` | Transform | Точка спауна мартышек. Позицию НЕ трогать (пользователь ставит сам). |
| `EventSystem` | EventSystem, StandaloneInputModule | |
| `DayMenuUI` | Canvas (sortingOrder=10) → Panel → DayMenuUI | Меню. |
| `DayAnnouncer` | DayAnnouncer | Дочерний к DayMenuUI Canvas. |
| `GameHUD` | Canvas (sortingOrder=5), GameHUD, WaiterCursor | Шкала + иконка у курсора. |
| `Monkey` (Prefab) | SpriteRenderer, MonkeyCustomer, BoxCollider2D, OrderBubble | Assets/Prefabs/Monkey.prefab |

---

## 8. CANVAS НАСТРОЙКИ

- `DayMenuUI` Canvas: ScreenSpaceOverlay, sortingOrder=10, referenceResolution=1920×1080
- `GameHUD` Canvas: ScreenSpaceOverlay, sortingOrder=5, referenceResolution=1920×1080, matchWidthOrHeight=0.5
- Шкала таймера: fillOrigin=1 (убывает справа налево), цвета бирюзовый→жёлтый→красный

---

## 9. GAMEDATA — ДАННЫЕ

```
Coins = 0           // текущие монеты
TotalServed = 0     // всего обслужено за сессию
DayNumber = 1       // текущий день
TableLevel = 0..5
SpeedLevel = 0..5
ServingTimeLevel = 0..5
DayTimeLevel = 0..5
WeebUnlocked = false
GamerUnlocked = false
GaijinUnlocked = false
WinCoins = 1000     // условие победы
```

OnDataChanged — event, подписываются DayMenuUI и другие.

---

## 10. ДВИЖЕНИЕ ПЕРСОНАЖЕЙ

### Мартышка (MonkeyCustomer):
1. Spawn у Door
2. Пауза 0.3–0.8 сек (MovePhase.Pause)
3. Идёт по Y до Y стола (MovePhase.Axis1) — промежуток: Vector3(exitPos.x, seatPos.y, z)
4. Идёт по X к столу (MovePhase.Axis2)
5. Пауза 0.2–0.5 сек (MovePhase.Done)
6. SetState(WaitingOrder)
7. Уход: по X вправо до X двери → по Y вверх к двери

### Официант (WaiterController):
- К мартышке: WalkingAxis1 (по X) → WalkingAxis2 (по Y) → servePos (мартышка + serveOffset)
- Возврат: ReturnAxis1 (по X) → ReturnAxis2 (по Y) → ближайшая точка зоны
- Idle: случайные перемещения внутри bounds ZoneWaiter

---

## 11. ИЗВЕСТНЫЕ БАГИ И ОГРАНИЧЕНИЯ

- `WaiterType.Tourist` в коде, в UI называется "Gaijin" — расхождение не исправлено
- `GameFrame.cs` существует но не создаётся автоматически (SetupGameFrame() не вызывается из SetupScene())
- Дублирование шкалы: GameHUD (работает) + TimerBarContainer в DayMenuUI (legacy, не работает)
- Мартышки и официанты могут проходить сквозь друг друга (нет физического столкновения)
- Нет NavMesh — движение по осям, не обходят препятствия
- GameData не сбрасывается при новом запуске игры (только Coins/Served/Day, но НЕ прокачка и разблокировки — они сохраняются в течение Play-сессии)

---

## 12. ЧТО НЕ РЕАЛИЗОВАНО

- Спрайты **геймплея** (мартышки, официанты, столы, пол, стены) — пока квадраты
- Иконки **монет** в меню (синие — пользователь добавит позже)
- 4 разных спрайта гостей в «лист гостей» (пока spr_visitor)
- Спрайты официантов в блоке Buds (пока пустой placeholder)
- Звук и музыка
- Экран победы при 1000 монетах
- Сохранение прогресса между сессиями

---

## 13. ПРАВИЛА РАБОТЫ С ПРОЕКТОМ (ВАЖНО!)

1. **НЕ менять позиции объектов на сцене** — пользователь расставляет вручную
2. **НЕ менять цвета объектов** — пользователь красит вручную
3. **Setup Scene (Tools → MonkeyBar → Setup Scene)** — не трогает позиции существующих объектов, только создаёт новые или добавляет компоненты
4. **ZoneWaiter** — видимый объект намеренно, как визуальный ориентир зоны барной стойки
5. **Door** — позиция только пользовательская, код не трогает
6. **Waiter/Waiter2/3/4** — позиции только пользовательские

---

## 14. СЛЕДУЮЩАЯ ЗАДАЧА (приоритет)

1. **Меню UI** — спрайты из `sprite/esc/` и `icon_upgrade/` (пользователь сам)
2. **Мартышки** — папка `sprite/monkey/`
3. **Официанты** — папка `sprite/witer/`
4. **Стены/пол** — `sprite/wall/`, `sprite/game_sprite/`

---

## 17. СПРАЙТЫ И ПАПКИ (Desktop/sprite/)

| Папка | Содержимое |
|-------|-----------|
| `esc/` | UI меню: spr_upgrade_bg, spr_upgrade_sub, spr_upgrade_desc, spr_circle_8, spr_visitor |
| `icon_upgrade/` | Иконки: table, banana, monkey, feather |
| `monkey/` | Анимации мартышек + spr_sad + spr_monkey_angry |
| `witer/` | Официанты char0..3 |
| `wall/` | Стены |
| `game_sprite/` | Пол, стол, дверь, plate |
| `Pixellari.ttf` | Пиксельный шрифт |

**В Unity (опционально):** `Assets/Resources/Menu/` и `Fonts/Pixellari.ttf` — можно использовать при ручной подстановке.

**Editor:** Tools → MonkeyBar → **Setup Scene**

**Меню (русский текст):** Улучшения, лист гостей, гости: норми/аниме/геймер/качок гость.

**ВАЖНО:** Автоподключение спрайтов откатили — меню и мартышки снова цветные квадраты.

---

## 15. ПЛАН MVP

1. ✅ Спаун мартышек и поиск стола
2. ✅ Выбор официанта и отправка к клиенту
3. ✅ Обслуживание и начисление монет
4. ✅ Таймер дня и смена дней
5. ✅ Меню с прокачкой и тултипами
6. ✅ Разблокировка 4 официантов по условию
7. ✅ L-образное движение персонажей (естественные траектории)
8. ✅ Зоны патруля официантов (ZoneWaiter)
9. ✅ Меню (layout, русский текст, тултипы)
10. ⬜ Спрайты (меню, мартышки, официанты, сцена) — **ТЕКУЩИЙ ЭТАП, вручную**
11. ⬜ Экран победы
12. ⬜ Звуковые эффекты
13. ⬜ Балансировка
14. ⬜ Финальное тестирование MVP

---

## 16. ТЕХНИЧЕСКАЯ ИНФОРМАЦИЯ

- Unity 6, 2D, URP
- Сцена: Assets/monkeyBar.unity
- Префаб мартышки: Assets/Prefabs/Monkey.prefab
- Editor утилита: Assets/Editor/SceneSetupTool.cs
- Путь проекта: `C:\Users\dv125\Desktop\MonkeyBar\MonkeyBar\`
- Рип ассетов: `C:\Users\dv125\Desktop\sprite\`
- **PROJECT_MEMORY.md** — читать в начале каждого нового чата
- CanvasScaler reference resolution: 1920×1080
- Game View: 1024×600 (зафиксировано через Free Aspect → Custom)
