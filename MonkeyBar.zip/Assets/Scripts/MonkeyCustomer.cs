using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public partial class MonkeyCustomer : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 2f;

    [Header("Timing")]
    public float waitForOrderTimeout  = 15f;
    public float eatDuration          = 8f;

    [Header("Patience")]
    public float angerTime            = 6f;
    public float leaveAfterAngerTime  = 2f;

    [Header("Normie sprites (этап 1)")]
    public float normieScale = 5f;
    public float walkAnimFps = 10f;
    public float eatAnimFps  = 6f;
    [Header("Zлое лицо (накладка)")]
    [Tooltip("Масштаб индикатора недовольства")]
    public float angryFaceScale = 1.08f;
    [Tooltip("Смещение индикатора недовольства относительно автоматической позиции")]
    public Vector2 angryFaceOffset = Vector2.zero;

    private enum MovePhase { Pause, ToAisle, Aisle, PauseCorner, ToSeat, Done }
    private enum AxisLock  { X, Y }

    private CustomerState  _state;
    private TableData      _myTable;
    private Vector3        _seatPos;
    private Vector3        _aislePos;
    private Vector3        _aisleEntry;
    private Vector3        _entryStand;
    private Bounds         _tableBounds;
    private float          _aisleY;
    private MovePhase      _movePhase;
    private float          _pauseTimer;
    private float          _pauseDuration;
    private float          _lookSway;

    private Vector3 _exitPos;
    private int     _leavePhase;

    private float _waitTimer;
    private float _eatTimer;

    private OrderBubble    _orderBubble;
    private SpriteRenderer _sr;
    private int            _baseSortingOrder;

    private Color      _myColor;
    private WaiterType _monkeyType = WaiterType.Normie;

    private const string NormieAnimWalk = "NormieWalk";
    private const string NormieAnimIdle = "NormieIdle";

    private bool               _useNormieSprites;
    private bool               _useNormieAnimator;
    private Animator             _normieAnimator;
    private string             _normieAnimState;
    private SpriteSheetAnimator _anim;
    private Sprite[]           _moveFrames;
    private Sprite[]           _eatFrames;
    private Sprite             _idleSprite;
    private Sprite[]           _activeWalkFrames;
    private Sprite[]           _activeEatFrames;
    private Sprite             _angryOverlaySprite;
    private float              _baseScaleX = 1f;
    private float              _baseScaleY = 1f;
    private bool               _leaveAngry;
    private bool               _wasServed;
    private GameObject         _angryGo;
    private SpriteRenderer     _angrySr;
    private bool               _visualLayoutDirty;

    public CustomerState State          => _state;
    public bool IsWaitingForWaiter      => _state == CustomerState.WaitingOrder;
    public bool IsWalking               => _state == CustomerState.WalkingToTable || _state == CustomerState.Leaving;
    public bool IsAtDoor                => _state == CustomerState.WalkingToTable && _movePhase == MovePhase.Pause;
    public TableData AssignedTable      => _myTable;
    public WaiterType MonkeyType        => _monkeyType;

    public void SetMonkeyType(WaiterType type) => _monkeyType = WaiterType.Normie;

    void Awake()
    {
        if (_sr == null) _sr = GetComponent<SpriteRenderer>();
        LpcShadow.Ensure(gameObject, LpcShadow.Preset.Character);
    }

    public void Initialize(TableData table, Vector3 doorPos, Vector3 entryStand, float aisleY)
    {
        _myTable    = table;
        _exitPos    = doorPos;
        _aisleY     = aisleY;
        _wasServed  = false;
        _leaveAngry = false;

        int queue = MonkeyTraffic.CountAtDoor(doorPos);
        _entryStand = entryStand + new Vector3(0f, queue * 0.28f, 0f);

        _sr = GetComponent<SpriteRenderer>();
        if (!_useNormieSprites)
            _myColor = _sr != null ? _sr.color : Color.white;
        if (_sr != null) _baseSortingOrder = _sr.sortingOrder;

        if (_useNormieSprites)
        {
            if (_moveFrames == null || _moveFrames.Length == 0)
                ApplyAppearance();
            RefreshChildDrawOrder();
        }

        transform.position = doorPos;

        _tableBounds = table.GetBounds();
        _seatPos     = table.GetSeatPosition(doorPos);
        _aislePos    = table.GetAislePoint(aisleY, doorPos);
        _aisleEntry  = new Vector3(_entryStand.x, aisleY, doorPos.z);

        _orderBubble = GetComponentInChildren<OrderBubble>(true);
        if (_orderBubble == null)
            _orderBubble = CreateOrderBubble();

        RefreshAngryOverlayLayout();
        RefreshOrderBubbleLayout();
        MarkVisualLayoutDirty();

        _myTable.Occupy();

        if (GameData.Instance != null)
            angerTime = GameData.Instance.CustomerPatience;

        _pauseDuration = 1f;
        _pauseTimer    = 0f;
        _movePhase     = MovePhase.Pause;
        _leavePhase    = 0;

        SetFacingTowardTables();
        SetState(CustomerState.WalkingToTable);
    }

    void Update()
    {
        switch (_state)
        {
            case CustomerState.WalkingToTable:
                UpdateWalkToTable();
                break;

            case CustomerState.WaitingOrder:
                _waitTimer += Time.deltaTime;
                if (_useNormieSprites)
                    UpdateAngryOverlay();
                else if (_waitTimer >= angerTime)
                    SetFace(FaceState.Angry);
                if (_waitTimer >= angerTime + leaveAfterAngerTime)
                    StartLeaving();
                break;

            case CustomerState.BeingServed:
                break;

            case CustomerState.Eating:
                _eatTimer += Time.deltaTime;
                if (_eatTimer >= eatDuration)
                {
                    TableFood.OnMonkeyFinishedEating(_myTable);
                    StartLeaving();
                }
                break;

            case CustomerState.Leaving:
                if (_useNormieSprites)
                    UpdateAngryOverlay();
                UpdateLeaving();
                break;
        }

        if (_useNormieSprites && _angryGo != null && _angryGo.activeSelf && ShouldShowAngryOverlay())
            RefreshAngryOverlayLayout();
    }

    public void ServeCustomer()
    {
        if (_state != CustomerState.WaitingOrder) return;
        SetState(CustomerState.BeingServed);
        TableFood.SpawnBanana(_myTable);
    }

    public void FinishServing()
    {
        if (_state != CustomerState.BeingServed) return;
        if (GameData.Instance != null)
        {
            GameData.Instance.AddCoins(GameData.CoinsPerMonkey);
            GameData.Instance.AddServed(1);
        }
        Canvas cv = Object.FindAnyObjectByType<Canvas>();
        CoinPopup.Spawn(transform.position, GameData.CoinsPerMonkey, cv);
        _wasServed = true;
        _eatTimer = 0f;
        SetState(CustomerState.Eating);
    }

    private enum FaceState { Happy, Neutral, Angry }

    private void SetFace(FaceState face)
    {
        if (_useNormieSprites || _sr == null) return;
        switch (face)
        {
            case FaceState.Happy:   _sr.color = _myColor; break;
            case FaceState.Neutral: _sr.color = _myColor; break;
            case FaceState.Angry:   _sr.color = new Color(0.9f, 0.15f, 0.15f); break;
        }
    }

    private void SetState(CustomerState s)
    {
        _state = s;
        switch (s)
        {
            case CustomerState.WalkingToTable:
                SetFace(FaceState.Happy);
                break;

            case CustomerState.WaitingOrder:
                _waitTimer = 0f;
                SetFace(FaceState.Neutral);
                break;

            case CustomerState.BeingServed:
                _orderBubble?.Hide();
                SetFace(FaceState.Happy);
                HideAngryOverlay();
                break;

            case CustomerState.Eating:
                _eatTimer = 0f;
                SetFace(FaceState.Happy);
                HideAngryOverlay();
                break;

            case CustomerState.Leaving:
                _orderBubble?.Hide();
                break;
        }

        RefreshNormieVisuals();
        ApplyAngryOverlay();
        if (ShouldShowAngryOverlay())
            RefreshAngryOverlayLayout();

        if (s == CustomerState.WaitingOrder)
        {
            RefreshOrderBubbleLayout();
            MarkVisualLayoutDirty();
            if (_orderBubble != null)
            {
                var types = System.Enum.GetValues(typeof(OrderBubble.OrderType));
                _orderBubble.Show((OrderBubble.OrderType)types.GetValue(
                    Random.Range(0, types.Length)));
                GameAudio.PlayBubble();
            }
        }
    }

    private void StartLeaving()
    {
        _leaveAngry = !_wasServed;
        if (_leaveAngry)
            GameAudio.PlayAngryLeave();
        if (_sr != null)
        {
            _sr.sortingOrder = _baseSortingOrder + 2;
            RefreshChildDrawOrder();
        }
        _myTable?.Free();
        _myTable    = null;
        _leavePhase = 0;
        SetFacingTowardDoor();
        SetState(CustomerState.Leaving);
    }

    void OnMouseDown()
    {
        if (_state != CustomerState.WaitingOrder) return;
        var waiter = WaiterController.GetSelectedWaiter();
        if (waiter == null || waiter.IsBusy) return;
        waiter.SendToCustomer(this);
    }
}
