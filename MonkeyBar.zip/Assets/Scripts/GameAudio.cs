using UnityEngine;

[DisallowMultipleComponent]
public class GameAudio : MonoBehaviour
{
    public static GameAudio Instance { get; private set; }

    [Header("Громкость")]
    [Range(0f, 1f)] public float musicVolume = 0.45f;
    [Range(0f, 1f)] public float sfxVolume   = 0.7f;

    AudioSource _musicSource;
    AudioSource _sfxSource;
    bool        _bgmStarted;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Bootstrap()
    {
        if (Instance != null) return;
        var go = new GameObject("GameAudio");
        go.AddComponent<GameAudio>();
    }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        _musicSource = gameObject.AddComponent<AudioSource>();
        _musicSource.loop = true;
        _musicSource.playOnAwake = false;
        _musicSource.spatialBlend = 0f;

        _sfxSource = gameObject.AddComponent<AudioSource>();
        _sfxSource.loop = false;
        _sfxSource.playOnAwake = false;
        _sfxSource.spatialBlend = 0f;

        PlayBgm();
    }

    public static void PlayBgm() => Instance?.EnsureBgm();

    public static void PlayDoor() => Instance?.PlaySfx("door");

    public static void PlayBubble() => Instance?.PlaySfx("bubble");

    public static void PlayAngryLeave() => Instance?.PlaySfx("angry");

    void EnsureBgm()
    {
        if (_musicSource == null || _bgmStarted) return;

        AudioClip clip = LoadClip("bgm");
        if (clip == null)
        {
            Debug.LogWarning("[GameAudio] Нет фона: Resources/Audio/bgm");
            return;
        }

        _bgmStarted = true;
        _musicSource.clip = clip;
        _musicSource.volume = musicVolume;
        _musicSource.Play();
    }

    void PlaySfx(string key)
    {
        if (_sfxSource == null) return;

        AudioClip clip = LoadClip(key);
        if (clip == null)
        {
            Debug.LogWarning($"[GameAudio] Нет звука: Resources/Audio/{key}");
            return;
        }

        _sfxSource.volume = sfxVolume;
        _sfxSource.PlayOneShot(clip);
    }

    static AudioClip LoadClip(string fileName)
    {
        var clip = Resources.Load<AudioClip>($"Audio/{fileName}");
        if (clip != null) return clip;
        return Resources.Load<AudioClip>($"Audio/Music/{fileName}");
    }
}
