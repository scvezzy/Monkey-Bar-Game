using UnityEngine;

/// <summary>
/// Очередь у двери. Мартышки при уходе проходят сквозь друг друга (как в оригинале).
/// </summary>
public static class MonkeyTraffic
{
    public const float DoorRadius = 0.7f;

    public static bool CanSpawnAt(Vector3 doorPos)
    {
        foreach (var m in Object.FindObjectsByType<MonkeyCustomer>())
        {
            if (m == null) continue;
            if (!m.IsAtDoor) continue;
            if (Vector2.Distance(m.transform.position, doorPos) < DoorRadius)
                return false;
        }
        return true;
    }

    public static int CountAtDoor(Vector3 doorPos)
    {
        int n = 0;
        foreach (var m in Object.FindObjectsByType<MonkeyCustomer>())
        {
            if (m == null) continue;
            if (m.IsAtDoor && Vector2.Distance(m.transform.position, doorPos) < DoorRadius * 1.5f)
                n++;
        }
        return n;
    }
}
