using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class UpgradeTooltip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public string      description;
    public UpgradeType upgradeType;
    public bool        showLevelInfo = false;

    private static GameObject _tooltipGO;
    private static Text       _tooltipText;
    private static Canvas     _canvas;
    private static Sprite     _bgSprite;
    private static Font       _font;
    private static float      _uiScale = 1f;
    private static int        _fontSize = 24;

    static readonly Color TooltipTextColor = MenuConfig.TooltipTextColor;

    public static void Init(Transform canvasTransform, Font font, int fontSize = 24, float uiScale = 1f, Sprite panelBg = null)
    {
        _fontSize = fontSize;
        _uiScale  = Mathf.Max(1f, uiScale);
        _font     = font;

        if (panelBg != null) _bgSprite = panelBg;
        else if (MenuUIAssets.Instance != null) _bgSprite = MenuUIAssets.Instance.TooltipBg;

        if (_tooltipGO != null)
        {
            _tooltipText.font     = _font;
            _tooltipText.fontSize = _fontSize;
            _tooltipText.color    = TooltipTextColor;
            ApplyTooltipSprite();
            return;
        }

        _canvas = canvasTransform.GetComponentInParent<Canvas>();
        if (_canvas == null) _canvas = canvasTransform.GetComponent<Canvas>();

        _tooltipGO = new GameObject("Tooltip");
        _tooltipGO.transform.SetParent(canvasTransform, false);

        RectTransform rt = _tooltipGO.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.zero;
        rt.pivot     = Vector2.zero;
        rt.sizeDelta = ScaledSize(420f, 96f);

        Image bg = _tooltipGO.AddComponent<Image>();
        bg.color = new Color(1f, 1f, 1f, MenuConfig.TooltipBgAlpha);
        bg.type  = Image.Type.Sliced;
        ApplyTooltipSprite(bg);

        GameObject txtGO = new GameObject("Text");
        txtGO.transform.SetParent(_tooltipGO.transform, false);
        RectTransform trt = txtGO.AddComponent<RectTransform>();
        trt.anchorMin = Vector2.zero;
        trt.anchorMax = Vector2.one;
        trt.offsetMin = new Vector2(18, 14);
        trt.offsetMax = new Vector2(-18, -14);

        _tooltipText = txtGO.AddComponent<Text>();
        _tooltipText.font               = _font;
        _tooltipText.fontSize           = _fontSize;
        _tooltipText.fontStyle          = FontStyle.Normal;
        _tooltipText.color              = TooltipTextColor;
        _tooltipText.alignment          = TextAnchor.MiddleLeft;
        _tooltipText.horizontalOverflow = HorizontalWrapMode.Wrap;
        _tooltipText.verticalOverflow   = VerticalWrapMode.Overflow;
        _tooltipText.raycastTarget      = false;

        _tooltipGO.SetActive(false);
    }

    static void ApplyTooltipSprite(Image bg = null)
    {
        if (_bgSprite == null && MenuUIAssets.Instance != null)
            _bgSprite = MenuUIAssets.Instance.TooltipBg;
        if (bg == null && _tooltipGO != null) bg = _tooltipGO.GetComponent<Image>();
        if (bg == null) return;
        if (_bgSprite != null)
        {
            bg.sprite      = _bgSprite;
            bg.type        = Image.Type.Sliced;
            bg.fillCenter  = true;
            bg.preserveAspect = false;
        }
        bg.color = new Color(1f, 1f, 1f, MenuConfig.TooltipBgAlpha);
    }

    static void ApplyTooltipSprite() => ApplyTooltipSprite(null);

    static Vector2 ScaledSize(float w, float h) => new Vector2(w * _uiScale, h * _uiScale);

    public void OnPointerEnter(PointerEventData e)
    {
        if (_tooltipGO == null)
        {
            var cv = GetComponentInParent<Canvas>();
            if (cv != null)
            {
                var assets = cv.GetComponent<MenuUIAssets>();
                Init(cv.transform,
                    assets != null ? assets.MenuFont : UIFonts.Main,
                    MenuConfig.FntTooltip, 1f,
                    assets != null ? assets.TooltipBg : null);
            }
        }
        if (_tooltipGO == null) return;

        ApplyTooltipSprite();
        if (_font != null) _tooltipText.font = _font;
        _tooltipText.fontSize = _fontSize;
        _tooltipText.color    = TooltipTextColor;
        _tooltipText.text     = description;

        int lines = description.Split('\n').Length;
        RectTransform rt = _tooltipGO.GetComponent<RectTransform>();
        float lineH = _tooltipText.fontSize * 1.45f;
        float minH  = 76f * _uiScale;
        float pad   = 32f * _uiScale;
        rt.sizeDelta = new Vector2(440f * _uiScale, Mathf.Max(minH, lines * lineH + pad));

        _tooltipGO.SetActive(true);
        MoveToMouse();
    }

    public void OnPointerExit(PointerEventData e)
    {
        if (_tooltipGO != null) _tooltipGO.SetActive(false);
    }

    void Update()
    {
        if (_tooltipGO != null && _tooltipGO.activeSelf)
            MoveToMouse();
    }

    static void MoveToMouse()
    {
        if (_tooltipGO == null || _canvas == null) return;

        RectTransform tipRT    = _tooltipGO.GetComponent<RectTransform>();
        RectTransform canvasRT = _canvas.GetComponent<RectTransform>();

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            canvasRT,
            Input.mousePosition,
            null,
            out Vector2 localPos);

        Vector2 canvasSize = canvasRT.sizeDelta;
        Vector2 pos = localPos + canvasSize * 0.5f + new Vector2(16f, 18f);

        Vector2 sz = tipRT.sizeDelta;
        if (pos.x + sz.x > canvasSize.x - 6f) pos.x -= sz.x + 32f;
        if (pos.y + sz.y > canvasSize.y - 6f) pos.y -= sz.y + 32f;

        tipRT.anchoredPosition = pos;
    }
}
