using UnityEngine;

public class OrderBubble : MonoBehaviour
{
    public enum OrderType { Banana, Coffee, Juice, Food }

    [Header("Order")]
    public OrderType orderType = OrderType.Banana;

    [Header("Layout")]
    public float bubbleWidthRatio = 1.45f;
    public float bubbleBottomY = 0.88f;
    public float leadingEdgeInset = 0.10f;
    public Vector2 positionOffset = Vector2.zero;
    public float bananaHeightRatio = 0.42f;
    public Vector2 bananaCenterRatio = new Vector2(0.58f, 0.50f);

    [Header("Banana ship sway")]
    public float bananaSwaySpeed = 2.6f;
    public float bananaSwayAngle = 14f;
    public float bananaSwayOffsetY = 0.004f;
    public float bananaAnimFps = 10f;

    Transform _bubbleRoot;
    SpriteRenderer _bubbleSr;
    Transform _bananaPivot;
    SpriteRenderer _bananaSr;
    SpriteSheetAnimator _bananaAnim;
    Vector3 _startLocalPos;
    Vector3 _bananaBaseLocalPos;
    bool _visible;
    int _sortingOrder;
    float _monkeyFacingSign = 1f;

    void Awake()
    {
        EnsureHierarchy();
    }

    void EnsureHierarchy()
    {
        transform.localScale = Vector3.one;

        var legacySr = GetComponent<SpriteRenderer>();
        if (legacySr != null)
            legacySr.enabled = false;

        if (_bubbleRoot == null)
        {
            var existing = transform.Find("BubbleRoot");
            if (existing != null)
                _bubbleRoot = existing;
            else
            {
                var go = new GameObject("BubbleRoot");
                go.transform.SetParent(transform, false);
                _bubbleRoot = go.transform;
            }
        }

        if (_bubbleSr == null)
        {
            _bubbleSr = _bubbleRoot.GetComponent<SpriteRenderer>();
            if (_bubbleSr == null)
                _bubbleSr = _bubbleRoot.gameObject.AddComponent<SpriteRenderer>();
        }

        var strayBanana = transform.Find("Banana");
        if (strayBanana != null && strayBanana.parent != _bubbleRoot)
            Destroy(strayBanana.gameObject);

        foreach (var t in GetComponentsInChildren<Transform>(true))
        {
            if (t != null && t.name == "Banana" && t.parent != _bubbleRoot)
                Destroy(t.gameObject);
        }
    }

    public void Setup(int sortingOrder, Bounds monkeyBounds, float monkeyFacingSign)
    {
        EnsureHierarchy();
        _sortingOrder = sortingOrder;
        _monkeyFacingSign = monkeyFacingSign >= 0f ? 1f : -1f;

        var bubbleSprite = GameplaySprites.OrderBubble();
        if (bubbleSprite != null && bubbleSprite.name != "spr_bubble_0")
            Debug.LogWarning($"[OrderBubble] Ожидался spr_bubble_0, получен: {bubbleSprite.name}");
        if (bubbleSprite != null)
            _bubbleSr.sprite = bubbleSprite;
        _bubbleSr.color = Color.white;
        _bubbleSr.sortingOrder = sortingOrder + 6;
        _bubbleRoot.localPosition = Vector3.zero;
        _bubbleRoot.localRotation = Quaternion.identity;

        float monkeyW = Mathf.Max(0.01f, monkeyBounds.size.x);
        float targetW = monkeyW * bubbleWidthRatio;

        if (bubbleSprite != null)
        {
            float bubbleW = Mathf.Max(0.001f, bubbleSprite.bounds.size.x);
            _bubbleRoot.localScale = Vector3.one * (targetW / bubbleW);
        }
        else
        {
            _bubbleRoot.localScale = Vector3.one;
        }

        transform.localScale = Vector3.one;

        float parentSign = 1f;
        if (transform.parent != null)
        {
            parentSign = Mathf.Sign(transform.parent.localScale.x);
            if (parentSign == 0f) parentSign = 1f;
        }

        _bubbleSr.flipX = parentSign < 0f;
        float headX = parentSign * monkeyBounds.max.x * 1.02f;
        float headY = monkeyBounds.max.y * 0.97f;
        Vector3 headAnchor = new Vector3(headX, headY, 0f);

        if (bubbleSprite != null)
        {
            var bb = bubbleSprite.bounds;
            float s = _bubbleRoot.localScale.x;
            Vector3 pivot = _bubbleSr.flipX
                ? new Vector3(bb.max.x * s, bb.min.y * s, 0f)
                : new Vector3(bb.min.x * s, bb.min.y * s, 0f);
            _startLocalPos = headAnchor - pivot;
        }
        else
        {
            _startLocalPos = headAnchor;
        }

        _startLocalPos += (Vector3)positionOffset;
        transform.localPosition = _startLocalPos;
        EnsureBanana(bubbleSprite);

        if (_bubbleSr != null) _bubbleSr.enabled = _visible;
        if (_bananaSr != null) _bananaSr.enabled = _visible;
    }

    void EnsureBanana(Sprite bubbleSprite)
    {
        if (_bananaPivot != null && _bananaPivot.parent != _bubbleRoot)
        {
            Destroy(_bananaPivot.gameObject);
            _bananaPivot = null;
            _bananaSr = null;
            _bananaAnim = null;
        }

        if (_bananaPivot == null)
        {
            var existing = _bubbleRoot.Find("Banana");
            if (existing != null)
                _bananaPivot = existing;
            else
            {
                var go = new GameObject("Banana");
                go.transform.SetParent(_bubbleRoot, false);
                _bananaPivot = go.transform;
            }
        }

        _bananaPivot.SetParent(_bubbleRoot, false);

        if (_bananaSr == null)
            _bananaSr = _bananaPivot.GetComponent<SpriteRenderer>();
        if (_bananaSr == null)
            _bananaSr = _bananaPivot.gameObject.AddComponent<SpriteRenderer>();

        if (_bananaAnim == null)
            _bananaAnim = _bananaPivot.GetComponent<SpriteSheetAnimator>();
        if (_bananaAnim == null)
            _bananaAnim = _bananaPivot.gameObject.AddComponent<SpriteSheetAnimator>();

        _bananaSr.sortingOrder = _sortingOrder + 7;
        _bananaAnim.fps = bananaAnimFps;

        var frames = GameplaySprites.OrderBananaFrames();
        Sprite bananaSprite = frames != null && frames.Length > 0 ? frames[0] : GameplaySprites.OrderBananaIcon();
        if (frames != null && frames.Length > 0)
            _bananaAnim.Play(frames);
        else if (bananaSprite != null)
            _bananaSr.sprite = bananaSprite;

        if (bubbleSprite == null || bananaSprite == null)
        {
            _bananaPivot.localScale = Vector3.one;
            _bananaBaseLocalPos = Vector3.zero;
            _bananaPivot.localPosition = _bananaBaseLocalPos;
            return;
        }

        var bb = bubbleSprite.bounds;
        float cx = Mathf.Lerp(bb.min.x, bb.max.x, bananaCenterRatio.x);
        if (_bubbleSr.flipX)
            cx = Mathf.Lerp(bb.min.x, bb.max.x, 1f - bananaCenterRatio.x);
        float cy = Mathf.Lerp(bb.min.y, bb.max.y, bananaCenterRatio.y);
        Vector3 bubbleCenter = new Vector3(cx, cy, 0f);

        float targetH = bb.size.y * bananaHeightRatio;
        float targetW = bb.size.x * 0.58f;
        var bananaBounds = bananaSprite.bounds;
        float bScale = Mathf.Min(
            targetH / Mathf.Max(0.001f, bananaBounds.size.y),
            targetW / Mathf.Max(0.001f, bananaBounds.size.x));
        _bananaPivot.localScale = Vector3.one * bScale;

        Vector3 bananaCenterOffset = bananaBounds.center * bScale;
        _bananaBaseLocalPos = bubbleCenter - bananaCenterOffset;
        _bananaPivot.localPosition = _bananaBaseLocalPos;
        _bananaPivot.localRotation = Quaternion.identity;
    }

    void Update()
    {
        if (!_visible || _bananaPivot == null) return;

        float t = Time.time * bananaSwaySpeed;
        float roll = Mathf.Sin(t) * bananaSwayAngle;
        float heave = Mathf.Sin(t * 0.85f + 0.4f) * bananaSwayOffsetY;
        _bananaPivot.localPosition = _bananaBaseLocalPos + new Vector3(0f, heave, 0f);
        _bananaPivot.localRotation = Quaternion.Euler(0f, 0f, roll);
    }

    public void Show(OrderType type)
    {
        orderType = type;
        SetVisible(true);
    }

    public void Hide() => SetVisible(false);

    void SetVisible(bool visible)
    {
        _visible = visible;
        if (_bubbleSr != null) _bubbleSr.enabled = visible;
        if (_bananaSr != null) _bananaSr.enabled = visible;
        if (!visible)
        {
            transform.localPosition = _startLocalPos;
            if (_bananaPivot != null)
            {
                _bananaPivot.localPosition = _bananaBaseLocalPos;
                _bananaPivot.localRotation = Quaternion.identity;
            }
        }
    }
}
