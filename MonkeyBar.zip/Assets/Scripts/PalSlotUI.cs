using UnityEngine;
using UnityEngine.UI;

public class PalSlotUI : MonoBehaviour
{
    public int palIndex;
    public Image icon;
    public Text label;
}
