using UnityEngine;

public class WaiterSelector : MonoBehaviour
{
    public static WaiterType selectedWaiter = WaiterType.Normie;
    public static int        selectedIndex  = 0;

    void Start() => EnsureValidSelection();

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) TrySelect(WaiterType.Normie,  0);
        if (Input.GetKeyDown(KeyCode.Alpha2)) TrySelect(WaiterType.Weeb,    1);
        if (Input.GetKeyDown(KeyCode.Alpha3)) TrySelect(WaiterType.Gamer,   2);
        if (Input.GetKeyDown(KeyCode.Alpha4)) TrySelect(WaiterType.Tourist, 3);
    }

    public static void EnsureValidSelection()
    {
        if (GameData.Instance != null && !GameData.Instance.IsWaiterUnlocked(selectedIndex))
            Select(WaiterType.Normie, 0, force: true);
    }

    static void TrySelect(WaiterType type, int index)
    {
        if (GameData.Instance != null && !GameData.Instance.IsWaiterUnlocked(index))
            return;
        Select(type, index);
    }

    static void Select(WaiterType type, int index, bool force = false)
    {
        if (!force && GameData.Instance != null && !GameData.Instance.IsWaiterUnlocked(index))
            return;

        selectedWaiter = type;
        selectedIndex  = index;

        if (WaiterCursor.Instance != null)
            WaiterCursor.Instance.Show(index);
    }
}
