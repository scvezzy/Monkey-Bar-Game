using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// Портрет официанта — спрайт с именем spr_char{N}_idle (первый, без _0).
/// </summary>
public static class MenuCharacters
{
    public static Sprite WaiterPortrait(int index)
    {
        index = Mathf.Clamp(index, 0, 3);
        string baseName = $"spr_char{index}_idle";

#if UNITY_EDITOR
        string assetPath = $"Assets/UI/Menu/waiters/{baseName}.png";
        var fromAssets = LoadNamedSprite(assetPath, baseName);
        if (fromAssets != null) return fromAssets;
#endif

        var fromResources = Resources.LoadAll<Sprite>($"Menu/waiters/{baseName}");
        return PickPortraitSprite(fromResources, baseName);
    }

    /// <summary>Голова официанта у курсора — gead_waiter1…4.</summary>
    public static Sprite WaiterHeadIcon(int index)
    {
        index = Mathf.Clamp(index, 0, 3);
        string fileBase = $"gead_waiter{index + 1}";

#if UNITY_EDITOR
        string assetPath = $"Assets/Resources/Menu/waiters/{fileBase}.png";
        var fromAssets = LoadFirstSprite(assetPath);
        if (fromAssets != null) return fromAssets;
#endif

        var fromResources = Resources.LoadAll<Sprite>($"Menu/waiters/{fileBase}");
        return PickPortraitSprite(fromResources, fileBase) ?? PickFirstSprite(fromResources);
    }

    static Sprite PickFirstSprite(Sprite[] all)
    {
        if (all == null || all.Length == 0) return null;
        foreach (var s in all)
            if (s != null) return s;
        return null;
    }

    static Sprite PickPortraitSprite(Sprite[] all, string baseName)
    {
        if (all == null || all.Length == 0) return null;

        foreach (var s in all)
        {
            if (s != null && s.name == baseName)
                return s;
        }

        Sprite tightest = null;
        float minArea = float.MaxValue;
        foreach (var s in all)
        {
            if (s == null) continue;
            float area = s.rect.width * s.rect.height;
            if (area < minArea)
            {
                minArea = area;
                tightest = s;
            }
        }
        return tightest ?? all[0];
    }

#if UNITY_EDITOR
    static Sprite LoadNamedSprite(string assetPath, string baseName)
    {
        var all = AssetDatabase.LoadAllAssetsAtPath(assetPath);
        if (all == null) return null;

        Sprite named = null;
        Sprite tightest = null;
        float minArea = float.MaxValue;

        foreach (var o in all)
        {
            if (o is not Sprite s) continue;
            if (s.name == baseName) named = s;
            float area = s.rect.width * s.rect.height;
            if (area < minArea)
            {
                minArea = area;
                tightest = s;
            }
        }

        return named ?? tightest;
    }

    static Sprite LoadFirstSprite(string assetPath)
    {
        var all = AssetDatabase.LoadAllAssetsAtPath(assetPath);
        if (all == null) return null;

        foreach (var o in all)
            if (o is Sprite s) return s;
        return null;
    }
#endif
}
