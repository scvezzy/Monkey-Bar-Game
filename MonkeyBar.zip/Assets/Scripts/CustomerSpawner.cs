using System.Collections.Generic;
using UnityEngine;

public class CustomerSpawner : MonoBehaviour
{
    [Header("Prefab")]
    public GameObject monkeyPrefab;

    [Header("Spawn Per Day")]
    public int minGuestsPerDay = 3;
    public int maxGuestsPerDay = 5;

    [Header("Spawn Timing")]
    [Tooltip("Задержка появления первого посетителя после начала дня")]
    public float firstSpawnDelay = 0.6f;
    [Tooltip("Минимальный интервал между появлениями посетителей")]
    public float minSpawnInterval = 5f;
    [Tooltip("Остановка спавна за указанное время до конца дня")]
    public float stopBeforeDayEnd = 4f;
    [Tooltip("Случайное отклонение времени спавна в секундах")]
    public float spawnJitter = 1.2f;

    [Header("Positions")]
    [Tooltip("Точка входа и выхода посетителей")]
    public Transform doorPoint;
    [Tooltip("Смещение точки ожидания относительно двери")]
    public Vector2 entryStandOffset = new Vector2(-1.5f, 0f);
    [Tooltip("Координата Y прохода между столами; 0 — автоматический расчёт")]
    public float aisleYOverride = 0f;

    private readonly List<float> _spawnSchedule = new();
    private int    _spawnIndex;
    private float  _dayTimer;
    private bool   _dayActive;

    void Awake() => ResolveDoorPoint();

    void Start()
    {
        ResolveDoorPoint();
        ApplyTableUpgrade();
    }

    void ResolveDoorPoint()
    {
        if (doorPoint != null) return;
        var door = GameObject.Find("Door");
        if (door != null)
            doorPoint = door.transform;
    }

    void Update()
    {
        if (!_dayActive) return;

        _dayTimer += Time.deltaTime;
        if (_spawnIndex < _spawnSchedule.Count && _dayTimer >= _spawnSchedule[_spawnIndex])
        {
            if (TrySpawnCustomer())
                _spawnIndex++;
            else
                _spawnSchedule[_spawnIndex] = _dayTimer + 0.8f;
        }
    }

    public void BeginDay()
    {
        _dayActive  = true;
        _dayTimer   = 0f;
        _spawnIndex = 0;
        _spawnSchedule.Clear();

        int count = Random.Range(minGuestsPerDay, maxGuestsPerDay + 1);
        float dayLen = GameData.Instance != null ? GameData.Instance.DayDuration : 45f;
        float windowStart = firstSpawnDelay;
        float windowEnd = Mathf.Max(windowStart + minSpawnInterval, dayLen - stopBeforeDayEnd);

        if (count <= 1)
        {
            _spawnSchedule.Add(windowStart);
        }
        else
        {
            float step = (windowEnd - windowStart) / (count - 1);
            step = Mathf.Max(step, minSpawnInterval);

            for (int i = 0; i < count; i++)
            {
                float t = windowStart + i * step + Random.Range(-spawnJitter, spawnJitter);
                t = Mathf.Clamp(t, windowStart, windowEnd);
                _spawnSchedule.Add(t);
            }
        }

        _spawnSchedule.Sort();

        for (int i = 1; i < _spawnSchedule.Count; i++)
        {
            if (_spawnSchedule[i] - _spawnSchedule[i - 1] < minSpawnInterval)
                _spawnSchedule[i] = _spawnSchedule[i - 1] + minSpawnInterval;
        }

        Debug.Log($"[Spawner] День: {count} мартышек, первый спавн {_spawnSchedule[0]:F1}с");
    }

    public void EndDay()
    {
        _dayActive = false;
    }

    public void StopSpawningForDay()
    {
        _dayActive = false;
    }

    public void ApplyTableUpgrade()
    {
        TableData[] all = Object.FindObjectsByType<TableData>(FindObjectsInactive.Include);
        System.Array.Sort(all, (a, b) => string.Compare(a.name, b.name));
        int maxTables = GameData.Instance != null ? GameData.Instance.ActiveTables : 3;
        for (int i = 0; i < all.Length; i++)
        {
            bool active = i < maxTables;
            all[i].gameObject.SetActive(active);
            if (active)
                LpcShadow.Ensure(all[i].gameObject, LpcShadow.Preset.Table);
        }
    }

    public static float GetAisleY(float overrideY = 0f)
    {
        if (overrideY != 0f) return overrideY;

        float min = float.MaxValue, max = float.MinValue;
        foreach (var t in Object.FindObjectsByType<TableData>())
        {
            if (!t.gameObject.activeInHierarchy) continue;
            float y = t.transform.position.y;
            min = Mathf.Min(min, y);
            max = Mathf.Max(max, y);
        }
        if (min == float.MaxValue) return -2.55f;
        return (min + max) * 0.5f;
    }

    private bool TrySpawnCustomer()
    {
        if (!MonkeyTraffic.CanSpawnAt(GetDoorPos())) return false;

        TableData freeTable = GetNearestFreeTable();
        if (freeTable == null) return false;
        if (monkeyPrefab == null)
        {
            Debug.LogWarning("CustomerSpawner: monkeyPrefab не назначен!");
            return false;
        }

        Vector3 doorPos  = GetDoorPos();
        Vector3 entryPos = GetEntryStand();
        float   aisleY   = GetAisleY(aisleYOverride);

        GameObject obj = Instantiate(monkeyPrefab, doorPos, Quaternion.identity);
        MonkeyCustomer customer = obj.GetComponent<MonkeyCustomer>();
        if (customer != null)
        {
            SetupNormieCustomer(customer);
            customer.Initialize(freeTable, doorPos, entryPos, aisleY);
            GameAudio.PlayDoor();
        }
        return true;
    }

    Vector3 GetDoorPos()
    {
        ResolveDoorPoint();
        return doorPoint != null ? doorPoint.position : Vector3.zero;
    }

    Vector3 GetEntryStand()
    {
        ResolveDoorPoint();
        return doorPoint != null ? doorPoint.position + (Vector3)entryStandOffset : Vector3.zero;
    }

    static void SetupNormieCustomer(MonkeyCustomer customer)
    {
        customer.SetMonkeyType(WaiterType.Normie);
        customer.ApplyAppearance();
    }

    private TableData GetNearestFreeTable()
    {
        TableData[] all = Object.FindObjectsByType<TableData>();
        System.Array.Sort(all, (a, b) => string.Compare(a.name, b.name));

        int maxTables = GameData.Instance != null ? GameData.Instance.ActiveTables : 3;
        maxTables = Mathf.Min(maxTables, all.Length);

        Vector3 door  = GetDoorPos();
        float   aisle = GetAisleY(aisleYOverride);

        TableData best   = null;
        float     bestDist = float.MaxValue;

        for (int i = 0; i < maxTables; i++)
        {
            TableData t = all[i];
            if (!t.gameObject.activeInHierarchy || t.occupied) continue;

            float dist = GetWalkDistance(door, aisle, t);
            if (dist < bestDist)
            {
                bestDist = dist;
                best     = t;
            }
        }

        return best;
    }

    float GetWalkDistance(Vector3 door, float aisleY, TableData table)
    {
        Vector3 seat = table.GetSeatPosition(door);
        float toAisle  = Mathf.Abs(door.y - aisleY);
        float alongAisle = Mathf.Abs(door.x - seat.x);
        float toSeat   = Mathf.Abs(aisleY - seat.y);
        return toAisle + alongAisle + toSeat;
    }
}
