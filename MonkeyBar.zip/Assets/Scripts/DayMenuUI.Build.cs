using UnityEngine;
using UnityEngine.UI;

public partial class DayMenuUI
{
    void BuildUI()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
            Destroy(transform.GetChild(i).gameObject);

        Canvas cv = GetComponentInParent<Canvas>();

        var bg = GetComponent<Image>();
        if (bg != null) bg.color = MenuConfig.PanelColor;

        float pw = GetPanelWidth();
        float ph = GetPanelHeight();
        MenuConfig.PanelSize = new Vector2(pw, ph);
        _uiScale = Mathf.Clamp(pw / 1050f, 1.15f, 2.4f);
        if (cv != null) UpgradeTooltip.Init(cv.transform, _font, FS(MenuConfig.FntTooltip), _uiScale);

        float pad = MenuConfig.Pad;
        float gap = MenuConfig.Gap;
        float sdH = S(MenuConfig.StartDayH);
        float dayBand = S(54f);
        float titleBand = S(44f);

        _dayText = MakePixelText("DayLbl", transform,
            new Vector2(0f, ph * 0.5f - pad - dayBand * 0.5f),
            new Vector2(S(300f), dayBand),
            "День 1", FS(MenuConfig.FntDay), MenuConfig.TitleRed, TextAnchor.MiddleCenter);

        float contentH = ph - pad * 2f - dayBand - gap - sdH - gap;

        float leftW  = pw * 0.50f - pad - gap * 0.5f;
        float leftX0 = -pw * 0.5f + pad;
        float leftCX = leftX0 + leftW * 0.5f;

        float rightW  = pw * 0.46f - pad - gap * 0.5f;
        float rightX0 = pw * 0.5f - pad - rightW;
        float rightCX = rightX0 + rightW * 0.5f;

        float upgradesH = contentH * 0.52f;
        float palH      = contentH * 0.40f;
        float counterH  = contentH - upgradesH - palH - gap * 2f;

        float topY      = ph * 0.5f - pad - dayBand - gap;
        float upgradesY = topY - upgradesH * 0.5f;
        float palY      = upgradesY - upgradesH * 0.5f - gap - palH * 0.5f;
        float counterY  = palY - palH * 0.5f - gap - counterH * 0.5f;

        float budsH     = contentH;
        float budsY     = topY - budsH * 0.5f;

        BuildBlock("UpgBg", transform, leftCX, upgradesY, leftW, upgradesH, MenuConfig.BlockBg,
            "Улучшения", FS(MenuConfig.FntTitle), MenuConfig.TitleRed);

        float rowH     = (upgradesH - titleBand - S(8f)) / 4f;
        float rowTop_u = upgradesY + upgradesH * 0.5f - titleBand - rowH * 0.5f;

        for (int i = 0; i < 4; i++)
        {
            float ry  = rowTop_u - i * rowH;
            float rx0 = leftCX - leftW * 0.5f + S(8f);
            int   id  = i;

            float iconW = S(42f);
            MakeBox($"Ic{i}", transform,
                new Vector2(rx0 + iconW * 0.5f, ry), new Vector2(iconW, S(32f)), UpgIconColors[i]);

            float btnW      = leftW * 0.34f;
            float btnCenter = leftCX + leftW * 0.5f - btnW * 0.5f - S(6f);
            float btnLeft   = btnCenter - btnW * 0.5f;
            float slotsLeft = rx0 + iconW + S(10f);
            float slotsW    = btnLeft - slotsLeft - S(8f);
            int   nSlots    = GameData.MaxLevel;
            float slotGap   = S(6f);
            float slotW     = (slotsW - slotGap * (nSlots - 1)) / nSlots;
            float slotH     = S(24f);

            _slots[i] = new Image[GameData.MaxLevel];
            for (int s = 0; s < nSlots; s++)
            {
                float sx = slotsLeft + s * (slotW + slotGap) + slotW * 0.5f;
                _slots[i][s] = MakeBox($"Sl{i}{s}", transform,
                    new Vector2(sx, ry), new Vector2(slotW, slotH), MenuConfig.SlotEmpty);
            }

            var btn = MakeButton($"Ub{i}", transform, new Vector2(btnCenter, ry),
                                  new Vector2(btnW, S(MenuConfig.UpgBtnH)),
                                  $"улучшить: {UpgCosts[i]}", MenuConfig.BtnDark, FS(MenuConfig.FntUpgRow));
            _upgradeCostText[i] = btn.GetComponentInChildren<Text>();
            btn.onClick.AddListener(() => GameData.Instance?.BuyUpgrade(UpgTypes[id]));

            var btnTip = btn.gameObject.AddComponent<UpgradeTooltip>();
            btnTip.description = UpgTips[i];
        }

        BuildBlock("PlBg", transform, leftCX, palY, leftW, palH, MenuConfig.BlockBg,
            "лист гостей", FS(MenuConfig.FntTitle), MenuConfig.TitleRed);

        float palStep = leftW / MenuConfig.PalCount;
        float palX0_  = leftCX - leftW * 0.5f + palStep * 0.5f;

        float blockTop   = palY + palH * 0.5f;
        float contentTop = blockTop - titleBand;
        float contentBot = palY - palH * 0.5f + S(8f);
        float availH     = contentTop - contentBot;
        float palLabelH  = S(50f);
        float palIconH   = availH - palLabelH - S(6f);
        float palNameY   = contentBot + palLabelH * 0.5f;
        float palIconY   = contentBot + palLabelH + palIconH * 0.5f + S(2f);
        int   palFs      = FS(MenuConfig.FntPal);

        for (int i = 0; i < MenuConfig.PalCount; i++)
        {
            float px = palX0_ + i * palStep;
            float iW = palStep - S(6f);
            float iH = Mathf.Min(palIconH, iW * 0.95f);
            MakeBox($"Pl{i}", transform, new Vector2(px, palIconY), new Vector2(iW, iH), PalColors[i]);
            var palLbl = MakeMultilineText($"PlN{i}", transform,
                new Vector2(px, palNameY), new Vector2(iW, palLabelH),
                PalNames[i], palFs, MenuConfig.TitleRed, TextAnchor.MiddleCenter);
            palLbl.lineSpacing = 1f;
        }

        float cY2 = counterY;
        float cX0 = leftCX - leftW * 0.5f + S(56f);

        BuildStatCounter("SerCnt", transform, new Vector2(cX0, cY2),
                         MenuIcons.ServedMonkey, ref _servedText, FS(MenuConfig.FntCounter));

        BuildStatCounter("CoinCnt", transform, new Vector2(cX0 + S(88f), cY2),
                         MenuIcons.Coin, ref _coinsText, FS(MenuConfig.FntCounter));

        float bsBtnS = S(38f);
        float budsTextW = rightW - bsBtnS - S(44f);
        float budsTextCX = rightX0 + budsTextW * 0.5f + S(8f);

        BuildBlock("BdBg", transform, rightCX, budsY, rightW, budsH, MenuConfig.BlockBg,
            "официанты", FS(MenuConfig.FntTitle), MenuConfig.TitleRed);

        float budsInnerW = budsTextW;
        float budsTop    = budsY + budsH * 0.5f - titleBand - S(8f);

        float sprH    = budsH * 0.36f;
        float sprY    = budsTop - sprH * 0.5f - S(6f);
        float charHalfW = budsInnerW * 0.38f;
        MakeBox("BdImg", transform, new Vector2(budsTextCX, sprY),
                new Vector2(charHalfW * 2f, sprH), new Color(0.1f,0.08f,0.05f,0.9f));

        float belowSprY = sprY - sprH * 0.5f;

        _budsName = MakePixelText("BdNm", transform,
            new Vector2(budsTextCX, belowSprY - S(18f)), new Vector2(budsInnerW - S(8f), S(34f)),
            "норми", FS(MenuConfig.FntBudsName), new Color(1f,0.85f,0.3f), TextAnchor.MiddleCenter);

        _budsDesc = MakePixelText("BdDs", transform,
            new Vector2(budsTextCX, belowSprY - S(62f)), new Vector2(budsInnerW - S(8f), S(72f)),
            "Доступен!", FS(MenuConfig.FntBudsDesc), Color.white, TextAnchor.MiddleCenter);
        _budsDesc.lineSpacing = 0.85f;

        _unlockBtn = MakeButton("UlBtn", transform,
            new Vector2(budsTextCX, belowSprY - S(112f)), new Vector2(budsInnerW * 0.72f, S(36f)),
            "ОТКРЫТЬ", MenuConfig.BtnUnlock, FS(15));
        _unlockBtnText = _unlockBtn.GetComponentInChildren<Text>();
        _unlockBtn.onClick.AddListener(() =>
        {
            WaiterType[] types = { WaiterType.Normie, WaiterType.Weeb, WaiterType.Gamer, WaiterType.Tourist };
            if (_selectedBud > 0 && GameData.Instance != null)
                GameData.Instance.UnlockWaiter(types[_selectedBud]);
            RefreshBuds();
        });
        _unlockBtn.gameObject.SetActive(false);

        float winY = budsY - budsH * 0.5f + 26f;
        MakeBox("WnBg", transform, new Vector2(budsTextCX, winY), new Vector2(budsInnerW * 0.92f, 34f), new Color(0.07f,0.07f,0.07f,0.92f));
        MakePixelText("WnTx", transform, new Vector2(budsTextCX, winY), new Vector2(budsInnerW * 0.85f, S(32f)),
                 "Победа: 1000", FS(MenuConfig.FntWin), Color.white, TextAnchor.MiddleCenter);

        float bsX    = rightCX + rightW * 0.5f - S(14f) - bsBtnS * 0.5f;
        float bsTop  = budsTop - bsBtnS * 0.5f - S(4f);

        for (int i = 0; i < MenuConfig.BudCount; i++)
        {
            int id = i;
            float bsY = bsTop - i * (bsBtnS + S(10f));
            MakeButton($"Bs{i}", transform, new Vector2(bsX, bsY), new Vector2(bsBtnS, bsBtnS), "", BudColors[i], FS(13))
                .onClick.AddListener(() => { _selectedBud = id; RefreshBuds(); });
        }

        float sdY_ = -(ph * 0.5f - pad - sdH * 0.5f);
        int startFs = Mathf.Min(FS(MenuConfig.FntStartDay), Mathf.RoundToInt(sdH * 0.42f));
        MakeButton("SdBtn", transform, new Vector2(0f, sdY_),
                   new Vector2(pw * 0.42f, sdH),
                   "Начать день", new Color(0.24f,0.15f,0.06f), startFs)
            .onClick.AddListener(OnStartDay);
    }


    Image BuildBlock(string name, Transform parent, float cx, float cy, float w, float h,
                     Color bgColor, string title, int titleFs, Color titleColor)
    {
        Image bg = MakeBox(name, parent, new Vector2(cx, cy), new Vector2(w, h), bgColor);
        float titleY = cy + h * 0.5f - S(26f);
        MakePixelText(name + "T", parent,
            new Vector2(cx, titleY), new Vector2(w - S(16f), S(36f)),
            title, titleFs, titleColor, TextAnchor.MiddleCenter);
        return bg;
    }

    Image MakeBox(string n, Transform p, Vector2 pos, Vector2 sz, Color c)
    {
        var go = new GameObject(n); go.transform.SetParent(p, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos; rt.sizeDelta = sz;
        var img = go.AddComponent<Image>(); img.color = c;
        var ol  = go.AddComponent<Outline>();
        ol.effectColor    = MenuConfig.BlockBorder;
        ol.effectDistance = new Vector2(2f, -2f);
        return img;
    }

    Text MakeText(string n, Transform p, Vector2 pos, Vector2 sz, string s, int fs, Color c, TextAnchor a)
    {
        var go = new GameObject(n); go.transform.SetParent(p, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos; rt.sizeDelta = sz;
        var t = go.AddComponent<Text>();
        t.text = s; t.font = _font; t.fontSize = fs; t.color = c; t.alignment = a;
        return t;
    }

    Text MakeMultilineText(string n, Transform p, Vector2 pos, Vector2 sz, string s, int fs, Color c, TextAnchor a)
    {
        var t = MakeText(n, p, pos, sz, s, fs, c, a);
        t.fontStyle = FontStyle.Normal;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow   = VerticalWrapMode.Overflow;
        t.lineSpacing = 1f;
        var ol = t.gameObject.AddComponent<Outline>();
        ol.effectColor    = new Color(0.18f, 0.08f, 0.04f, 0.55f);
        ol.effectDistance = new Vector2(1, -1);
        return t;
    }

    Text MakePixelText(string n, Transform p, Vector2 pos, Vector2 sz, string s, int fs, Color c, TextAnchor a)
    {
        var t = MakeText(n, p, pos, sz, s, fs, c, a);
        t.fontStyle = FontStyle.Normal;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow   = VerticalWrapMode.Truncate;
        t.resizeTextForBestFit = false;
        var ol = t.gameObject.AddComponent<Outline>();
        ol.effectColor    = new Color(0.18f, 0.08f, 0.04f, 0.55f);
        ol.effectDistance = new Vector2(1, -1);
        return t;
    }

    Button MakeButton(string n, Transform p, Vector2 pos, Vector2 sz, string lbl, Color c, int fs)
    {
        var img = MakeBox(n, p, pos, sz, c);
        var btn = img.gameObject.AddComponent<Button>();
        btn.targetGraphic = img;
        var cb = btn.colors;
        cb.highlightedColor = c * 1.3f; cb.pressedColor = c * 0.7f; btn.colors = cb;
        if (!string.IsNullOrEmpty(lbl))
        {
            var tgo = new GameObject("T"); tgo.transform.SetParent(img.transform, false);
            var trt = tgo.AddComponent<RectTransform>();
            trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one;
            trt.offsetMin = new Vector2(10f, 4f);
            trt.offsetMax = new Vector2(-10f, -4f);
            var t = tgo.AddComponent<Text>();
            t.text = lbl; t.font = _font; t.fontSize = fs;
            t.color = Color.white; t.fontStyle = FontStyle.Normal;
            t.alignment = TextAnchor.MiddleCenter;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow   = VerticalWrapMode.Overflow;
            t.resizeTextForBestFit = true;
            t.resizeTextMinSize = 10;
            t.resizeTextMaxSize = fs;
            var ol = tgo.AddComponent<Outline>();
            ol.effectColor    = new Color(0.15f, 0.08f, 0.04f, 0.85f);
            ol.effectDistance = new Vector2(1, -1);
        }
        return btn;
    }

    void BuildStatCounter(string n, Transform p, Vector2 center, Sprite icon, ref Text numRef, int fs)
    {
        float iconSz = S(40f);
        float gap    = S(8f);
        float numW   = S(44f);
        float totalW = numW + gap + iconSz;
        float leftX  = center.x - totalW * 0.5f + numW * 0.5f;

        numRef = MakePixelText(n + "N", p, new Vector2(leftX, center.y),
            new Vector2(numW, iconSz), "0", fs, Color.white, TextAnchor.MiddleCenter);

        if (icon != null)
            MakeIcon(n + "I", p, new Vector2(leftX + numW * 0.5f + gap + iconSz * 0.5f, center.y),
                     new Vector2(iconSz, iconSz), icon);
    }

    Image MakeIcon(string n, Transform p, Vector2 pos, Vector2 sz, Sprite sp)
    {
        var go = new GameObject(n); go.transform.SetParent(p, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos; rt.sizeDelta = sz;
        var img = go.AddComponent<Image>();
        img.sprite = sp;
        img.color  = Color.white;
        img.preserveAspect = true;
        return img;
    }

    void BuildCounter(string n, Transform p, Vector2 pos, Color bg, ref Text numRef, int fs, Font font)
    {
        Image box = MakeBox(n, p, pos, new Vector2(S(40f), S(40f)), bg);
        var tgo = new GameObject("Num"); tgo.transform.SetParent(box.transform, false);
        var trt = tgo.AddComponent<RectTransform>();
        trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one;
        trt.offsetMin = trt.offsetMax = Vector2.zero;
        var t = tgo.AddComponent<Text>();
        t.text = "0"; t.font = font; t.fontSize = fs;
        t.color = Color.white; t.fontStyle = FontStyle.Bold;
        t.alignment = TextAnchor.MiddleCenter;
        numRef = t;
    }

    void SetAnchored(string n, Transform p,
                     Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot,
                     Vector2 aPos, Vector2 sz, Text txt)
    {
        var go = txt.gameObject; go.name = n; go.transform.SetParent(p, false);
        var rt = go.GetComponent<RectTransform>();
        if (rt == null) rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchorMin; rt.anchorMax = anchorMax; rt.pivot = pivot;
        rt.anchoredPosition = aPos; rt.sizeDelta = sz;
    }

    Text MakeTxt(string s, int fs, Color c)
    {
        var go = new GameObject("tmp"); go.transform.SetParent(transform, false);
        go.AddComponent<RectTransform>();
        var t = go.AddComponent<Text>();
        t.text = s; t.font = _font; t.fontSize = fs; t.color = c;
        t.alignment = TextAnchor.MiddleCenter; t.fontStyle = FontStyle.Bold;
        return t;
    }
}
