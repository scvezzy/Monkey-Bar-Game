using UnityEngine;
using UnityEngine.UI;

public class GameHUD : MonoBehaviour
{
    public static GameHUD Instance { get; private set; }

    private static Sprite s_whiteSprite;

    private const float BAR_PANEL_WIDTH = 856f;
    private const float BAR_HEIGHT      = 64f;
    private const float PANEL_BOTTOM    = 8f;
    private const float ICON_SIZE       = 152f;
    private const float ICON_MARGIN     = 12f;

    private Image      _fill;
    private GameObject _barPanel;

    private const float HOURGLASS_FPS = 8f;

    private static readonly Color COLOR_FULL = new Color(0.20f, 1.00f, 0.75f);
    private static readonly Color COLOR_HALF = new Color(1.00f, 0.85f, 0.10f);
    private static readonly Color COLOR_LOW  = new Color(1.00f, 0.25f, 0.15f);

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        BuildHUD();
    }

    public void SetFill(float t)
    {
        if (_fill == null) return;
        _fill.fillAmount = Mathf.Clamp01(t);
        _fill.color = t > 0.5f
            ? Color.Lerp(COLOR_HALF, COLOR_FULL, (t - 0.5f) * 2f)
            : Color.Lerp(COLOR_LOW,  COLOR_HALF, Mathf.Clamp01(t * 2f));
    }

    public void StartTimer(float duration)
    {
        if (_fill != null) { _fill.fillAmount = 1f; _fill.color = COLOR_FULL; }
        if (_barPanel != null) _barPanel.SetActive(true);
    }

    public void StopTimer()
    {
        if (_barPanel != null) _barPanel.SetActive(false);
    }

    void BuildHUD()
    {
        Canvas canvas = GetComponent<Canvas>();
        if (canvas == null) canvas = gameObject.AddComponent<Canvas>();
        canvas.renderMode   = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 5;

        if (GetComponent<CanvasScaler>() == null)
        {
            CanvasScaler cs = gameObject.AddComponent<CanvasScaler>();
            cs.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            cs.referenceResolution = new Vector2(1920, 1080);
            cs.matchWidthOrHeight  = 0.5f;
        }

        if (GetComponent<GraphicRaycaster>() == null)
            gameObject.AddComponent<GraphicRaycaster>();

        _barPanel = new GameObject("TimerBarPanel");
        _barPanel.transform.SetParent(transform, false);
        _barPanel.SetActive(false);

        RectTransform panelRT = _barPanel.AddComponent<RectTransform>();
        panelRT.anchorMin        = new Vector2(0.5f, 0f);
        panelRT.anchorMax        = new Vector2(0.5f, 0f);
        panelRT.pivot            = new Vector2(0.5f, 0f);
        panelRT.anchoredPosition = new Vector2(0f, PANEL_BOTTOM);
        panelRT.sizeDelta        = new Vector2(BAR_PANEL_WIDTH, BAR_HEIGHT);

        Image panelBg = _barPanel.AddComponent<Image>();
        panelBg.color = new Color(0.10f, 0.10f, 0.14f, 0.95f);
        ApplySprite(panelBg);

        GameObject iconGO = new GameObject("HourglassIcon");
        iconGO.transform.SetParent(_barPanel.transform, false);
        Image iconImg = iconGO.AddComponent<Image>();
        iconImg.preserveAspect = true;
        iconImg.color = Color.white;
        RectTransform iconRT = iconGO.GetComponent<RectTransform>();
        iconRT.anchorMin        = new Vector2(0f, 0f);
        iconRT.anchorMax        = new Vector2(0f, 0f);
        iconRT.pivot            = new Vector2(0f, 0f);
        iconRT.anchoredPosition = new Vector2(ICON_MARGIN, 8f);
        iconRT.sizeDelta        = new Vector2(ICON_SIZE, ICON_SIZE);

        var clockFrames = GameplaySprites.ClockFrames();
        if (clockFrames != null && clockFrames.Length > 0)
        {
            iconImg.sprite = clockFrames[0];
            var hourglassAnim = iconGO.AddComponent<UIImageFrameAnimator>();
            hourglassAnim.fps = HOURGLASS_FPS;
            hourglassAnim.Play(clockFrames);
        }
        else
        {
            iconImg.color = new Color(0.38f, 0.24f, 0.09f, 1f);
            ApplySprite(iconImg);
        }

        float iconEnd = ICON_MARGIN + ICON_SIZE + ICON_MARGIN;

        GameObject barBgGO = new GameObject("BarBackground");
        barBgGO.transform.SetParent(_barPanel.transform, false);
        Image barBgImg = barBgGO.AddComponent<Image>();
        barBgImg.color = new Color(0.18f, 0.18f, 0.22f, 1f);
        ApplySprite(barBgImg);
        RectTransform barBgRT = barBgGO.GetComponent<RectTransform>();
        barBgRT.anchorMin = new Vector2(0f, 0f);
        barBgRT.anchorMax = new Vector2(1f, 1f);
        barBgRT.offsetMin = new Vector2(iconEnd, 8f);
        barBgRT.offsetMax = new Vector2(-10f, -8f);

        GameObject fillGO = new GameObject("BarFill");
        fillGO.transform.SetParent(barBgGO.transform, false);
        Image fillImg = fillGO.AddComponent<Image>();
        fillImg.sprite     = GetWhiteSprite();
        fillImg.color      = COLOR_FULL;
        fillImg.type       = Image.Type.Filled;
        fillImg.fillMethod = Image.FillMethod.Horizontal;
        fillImg.fillOrigin = 0;
        fillImg.fillAmount = 1f;
        RectTransform fillRT = fillGO.GetComponent<RectTransform>();
        fillRT.anchorMin = Vector2.zero;
        fillRT.anchorMax = Vector2.one;
        fillRT.offsetMin = new Vector2(3f, 3f);
        fillRT.offsetMax = new Vector2(-3f, -3f);
        _fill = fillImg;

        GameObject gloss = new GameObject("BarGloss");
        gloss.transform.SetParent(barBgGO.transform, false);
        Image glossImg = gloss.AddComponent<Image>();
        glossImg.color = new Color(1f, 1f, 1f, 0.12f);
        ApplySprite(glossImg);
        RectTransform glossRT = gloss.GetComponent<RectTransform>();
        glossRT.anchorMin = new Vector2(0f, 0.55f);
        glossRT.anchorMax = new Vector2(1f, 1f);
        glossRT.offsetMin = new Vector2(3f, 0f);
        glossRT.offsetMax = new Vector2(-3f, -3f);
    }

    static Sprite GetWhiteSprite()
    {
        if (s_whiteSprite != null) return s_whiteSprite;

        var tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        s_whiteSprite = Sprite.Create(tex, new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 100f);
        s_whiteSprite.name = "GameHUD_White";
        return s_whiteSprite;
    }

    static void ApplySprite(Image img)
    {
        if (img != null) img.sprite = GetWhiteSprite();
    }
}
