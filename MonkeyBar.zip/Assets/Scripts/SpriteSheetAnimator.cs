using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class SpriteSheetAnimator : MonoBehaviour
{
    public float fps = 8f;

    SpriteRenderer _sr;
    Sprite[] _frames;
    int _index;
    float _timer;
    bool _playing;

    void Awake() => _sr = GetComponent<SpriteRenderer>();

    public void Play(Sprite[] frames)
    {
        if (frames == null || frames.Length == 0) return;
        _frames = frames;
        _playing = frames.Length > 1;
        _index = 0;
        _timer = 0f;
        if (_sr != null)
            _sr.sprite = frames[0];
    }

    public void Stop(Sprite holdFrame = null)
    {
        _playing = false;
        if (holdFrame != null && _sr != null)
            _sr.sprite = holdFrame;
        else if (_frames != null && _frames.Length > 0 && _sr != null)
            _sr.sprite = _frames[0];
    }

    void Update()
    {
        if (!_playing || _frames == null || _frames.Length <= 1 || _sr == null)
            return;

        _timer += Time.deltaTime;
        float frameTime = 1f / Mathf.Max(1f, fps);
        while (_timer >= frameTime)
        {
            _timer -= frameTime;
            _index = (_index + 1) % _frames.Length;
            _sr.sprite = _frames[_index];
        }
    }
}
