using UnityEngine;

public partial class MonkeyCustomer
{
    void UpdateWalkToTable()
    {
        MovePhase prev = _movePhase;

        switch (_movePhase)
        {
            case MovePhase.Pause:
                _pauseTimer += Time.deltaTime;
                _lookSway += Time.deltaTime * 5f;
                transform.position = _entryStand + new Vector3(Mathf.Sin(_lookSway) * 0.04f, 0f, 0f);
                if (_pauseTimer >= _pauseDuration)
                {
                    _pauseTimer = 0f;
                    _movePhase  = MovePhase.ToAisle;
                    SetFacingTowardTables();
                }
                break;

            case MovePhase.ToAisle:
                StepAxis(_aisleEntry, AxisLock.Y);
                if (ReachedY(_aisleEntry.y))
                {
                    _pauseDuration = Random.Range(0.06f, 0.14f);
                    _pauseTimer    = 0f;
                    _movePhase     = MovePhase.Aisle;
                }
                break;

            case MovePhase.Aisle:
                StepAxis(_aislePos, AxisLock.X);
                if (ReachedX(_aislePos.x))
                {
                    _pauseDuration = Random.Range(0.1f, 0.22f);
                    _pauseTimer    = 0f;
                    _movePhase     = MovePhase.PauseCorner;
                }
                break;

            case MovePhase.PauseCorner:
                _pauseTimer += Time.deltaTime;
                if (_pauseTimer >= _pauseDuration)
                {
                    _pauseTimer = 0f;
                    _movePhase  = MovePhase.ToSeat;
                }
                break;

            case MovePhase.ToSeat:
                StepAxis(_seatPos, AxisLock.Y);
                if (ReachedY(_seatPos.y) || HasTouchedTable())
                {
                    SnapToSeat();
                    _pauseDuration = Random.Range(0.1f, 0.28f);
                    _pauseTimer    = 0f;
                    _movePhase     = MovePhase.Done;
                }
                break;

            case MovePhase.Done:
                _pauseTimer += Time.deltaTime;
                if (_pauseTimer >= _pauseDuration)
                    SetState(CustomerState.WaitingOrder);
                break;
        }

        if (_useNormieSprites && prev != _movePhase)
            RefreshNormieVisuals();
    }

    void UpdateLeaving()
    {
        if (_sr != null)
        {
            _sr.sortingOrder = _baseSortingOrder + 2;
            RefreshChildDrawOrder();
        }

        switch (_leavePhase)
        {
            case 0:
                StepAxis(new Vector3(transform.position.x, _aisleY, transform.position.z), AxisLock.Y);
                if (ReachedY(_aisleY)) _leavePhase = 1;
                break;

            case 1:
                StepAxis(new Vector3(_exitPos.x, _aisleY, transform.position.z), AxisLock.X);
                if (ReachedX(_exitPos.x)) _leavePhase = 2;
                break;

            case 2:
                StepAxis(_exitPos, AxisLock.Y);
                if (Reached(_exitPos)) Destroy(gameObject);
                break;
        }
    }

    void SnapToSeat()
    {
        transform.position = new Vector3(_seatPos.x, _seatPos.y, transform.position.z);
        SetFacingTowardDoor();
        ApplySeatedDrawOrder();
    }

    bool HasTouchedTable()
    {
        if (_seatPos.y > transform.position.y)
            return transform.position.y >= _tableBounds.min.y - _myTable.approachGap;
        return transform.position.y <= _tableBounds.max.y + _myTable.approachGap;
    }

    void StepAxis(Vector3 target, AxisLock axis)
    {
        Vector3 pos = transform.position;
        float spd = moveSpeed * Time.deltaTime;

        if (axis == AxisLock.X)
        {
            pos.x = Mathf.MoveTowards(pos.x, target.x, spd);
            ApplyHorizontalFacing(target.x - pos.x);
        }
        else
        {
            pos.y = Mathf.MoveTowards(pos.y, target.y, spd);
        }

        transform.position = pos;
    }

    bool Reached(Vector3 t) =>
        Vector2.Distance(transform.position, t) < 0.06f;

    bool ReachedX(float x) => Mathf.Abs(transform.position.x - x) < 0.06f;
    bool ReachedY(float y) => Mathf.Abs(transform.position.y - y) < 0.06f;

    void SetFacingTowardTables()
    {
        if (!_useNormieSprites) return;
        transform.localScale = new Vector3(_baseScaleX, _baseScaleY, 1f);
    }

    void SetFacingTowardDoor()
    {
        if (!_useNormieSprites)
        {
            Vector3 s = transform.localScale;
            s.x = -Mathf.Abs(s.x);
            transform.localScale = s;
            return;
        }
        transform.localScale = new Vector3(-_baseScaleX, _baseScaleY, 1f);
    }

    void ApplyHorizontalFacing(float dx)
    {
        if (Mathf.Abs(dx) <= 0.01f) return;

        if (_useNormieSprites)
        {
            float sign = dx < 0f ? 1f : -1f;
            transform.localScale = new Vector3(_baseScaleX * sign, _baseScaleY, 1f);
        }
        else
        {
            Vector3 s = transform.localScale;
            s.x = Mathf.Abs(s.x) * (dx < 0f ? -1f : 1f);
            transform.localScale = s;
        }

        if (_orderBubble != null && IsWaitingForWaiter)
            RefreshOrderBubbleLayout();
    }
}
