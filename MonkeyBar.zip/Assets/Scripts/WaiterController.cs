using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class WaiterController : MonoBehaviour
{
    [Header("Identity")]
    public WaiterType waiterType;

    [Header("Zone")]
    [Tooltip("Зона патрулирования официанта")]
    public GameObject zoneObject;

    [Header("Movement")]
    public float moveSpeed   = 3f;
    public float walkAnimFps = 10f;

    [Header("Serving")]
    public float servingDuration = 2f;
    [Tooltip("Дополнительное смещение при отсутствии компонента TableData")]
    public Vector2 serveOffset = new Vector2(0.55f, 0f);

    [Header("Idle")]
    public float idleWaitMin   = 1.5f;
    public float idleWaitMax   = 3.5f;
    public float idleMoveSpeed = 0.6f;

    private enum State { Idle, WalkingAxis1, WalkingAxis2, Serving, ReturnAxis1, ReturnAxis2 }
    private State _state = State.Idle;

    private Vector3        _home;
    private Bounds         _zoneBounds;
    private bool           _hasZone;
    private Vector3        _idleTarget;
    private MonkeyCustomer _target;
    private Vector3        _servePos;
    private Vector3        _axisWaypoint;
    private float          _servingTimer;
    private float          _idleWaitTimer;
    private float          _idleWaitDuration;
    private bool           _idleMoving;
    private bool           _carryingFood;

    private SpriteRenderer      _sr;
    private SpriteSheetAnimator _anim;
    private Sprite              _idleSprite;
    private Sprite[]            _walkFrames;
    private Sprite[]            _carryFrames;
    private bool                _visualsReady;
    private Sprite[]            _activeAnimFrames;
    private bool                _wasMoving;

    public bool IsBusy => _state != State.Idle;

    void Awake()  { Init(); }
    void OnEnable() { Init(); }

    void Init()
    {
        _home = transform.position;
        TryFindZone();
        _state         = State.Idle;
        _idleTarget    = _home;
        _idleMoving    = false;
        _carryingFood  = false;
        SetupVisuals();
        ScheduleNextIdleMove();
    }

    void SetupVisuals()
    {
        if (_sr == null) _sr = GetComponent<SpriteRenderer>();
        if (_anim == null) _anim = GetComponent<SpriteSheetAnimator>();
        if (_anim == null) _anim = gameObject.AddComponent<SpriteSheetAnimator>();

        int index = GameplaySprites.WaiterIndex(waiterType);
        _idleSprite  = GameplaySprites.WaiterIdle(index);
        _walkFrames  = GameplaySprites.WaiterWalkFrames(waiterType);
        _carryFrames = GameplaySprites.WaiterCarryFrames(waiterType);
        _anim.fps    = walkAnimFps;

        if (_sr != null)
        {
            _sr.color = Color.white;
            if (_idleSprite != null)
                _sr.sprite = _idleSprite;
        }

        _visualsReady = true;
        RefreshVisuals(false);
        LpcShadow.Ensure(gameObject, LpcShadow.Preset.Character);
    }

    void Start()
    {
        LpcShadow.Ensure(gameObject, LpcShadow.Preset.Character);
    }

    void TryFindZone()
    {
        if (zoneObject != null) { SetZoneFrom(zoneObject); return; }

        string[] names = waiterType switch
        {
            WaiterType.Normie  => new[] { "ZoneWaiter", "ZoneWaiter1" },
            WaiterType.Weeb    => new[] { "ZoneWaiter2" },
            WaiterType.Gamer   => new[] { "ZoneWaiter3" },
            WaiterType.Tourist => new[] { "ZoneWaiter4" },
            _                  => new string[0]
        };
        foreach (string n in names)
        {
            var z = GameObject.Find(n);
            if (z != null) { zoneObject = z; SetZoneFrom(z); return; }
        }
        _hasZone = false;
    }

    void SetZoneFrom(GameObject z)
    {
        var r = z.GetComponent<Renderer>();
        if (r != null) { _zoneBounds = r.bounds; _home = _zoneBounds.center; _hasZone = true; }
        else           { _home = z.transform.position; _hasZone = false; }
    }

    void Update()
    {
        if (GameData.Instance != null) moveSpeed = GameData.Instance.WaiterSpeed;

        switch (_state)
        {
            case State.Idle:
                UpdateIdle();
                break;

            case State.WalkingAxis1:
                if (TargetGone()) { ReturnToZone(); break; }
                StepTowards(_axisWaypoint, moveSpeed);
                if (ReachedFlat(_axisWaypoint)) _state = State.WalkingAxis2;
                break;

            case State.WalkingAxis2:
                if (TargetGone()) { ReturnToZone(); break; }
                StepTowards(_servePos, moveSpeed);
                if (ReachedFlat(_servePos)) BeginServing();
                break;

            case State.Serving:
                if (!IsTargetAlive(_target))
                {
                    _target = null;
                    ReturnToZone();
                    break;
                }
                _servingTimer += Time.deltaTime;
                if (_servingTimer >= servingDuration) FinishServing();
                break;

            case State.ReturnAxis1:
                StepTowards(_axisWaypoint, moveSpeed);
                if (ReachedFlat(_axisWaypoint)) _state = State.ReturnAxis2;
                break;

            case State.ReturnAxis2:
                StepTowards(_home, moveSpeed);
                if (ReachedFlat(_home) || IsInsideZone(transform.position))
                {
                    _state      = State.Idle;
                    _idleTarget = transform.position;
                    ScheduleNextIdleMove();
                }
                break;
        }

        RefreshVisuals(IsMoving());
    }

    void UpdateIdle()
    {
        if (_idleMoving)
        {
            StepTowards(_idleTarget, idleMoveSpeed);
            if (ReachedFlat(_idleTarget)) { _idleMoving = false; ScheduleNextIdleMove(); }
        }
        else
        {
            _idleWaitTimer += Time.deltaTime;
            if (_idleWaitTimer >= _idleWaitDuration)
            {
                _idleTarget = RandomPointInZone();
                _idleMoving = true;
            }
        }
    }

    void ScheduleNextIdleMove()
    {
        _idleWaitTimer    = 0f;
        _idleWaitDuration = Random.Range(idleWaitMin, idleWaitMax);
    }

    public void SendToCustomer(MonkeyCustomer customer)
    {
        if (IsBusy) return;
        _target       = customer;
        _idleMoving   = false;
        _carryingFood = true;
        _activeAnimFrames = null;

        TableData table = customer.AssignedTable;
        if (table != null)
            _servePos = table.GetServePosition(transform.position);
        else
        {
            Vector3 monkeyPos = customer.transform.position;
            _servePos = monkeyPos + new Vector3(serveOffset.x, serveOffset.y, 0f);
        }

        _axisWaypoint = new Vector3(_servePos.x, transform.position.y, transform.position.z);
        _state = State.WalkingAxis1;
    }

    void BeginServing()
    {
        if (!IsTargetAlive(_target)) { _target = null; ReturnToZone(); return; }
        _carryingFood = false;
        _activeAnimFrames = null;
        _servingTimer = 0f;
        _state        = State.Serving;
        servingDuration = GameData.Instance != null ? GameData.Instance.ServingDuration : 2f;
        _target.ServeCustomer();
        RefreshVisuals(false);
    }

    void FinishServing()
    {
        if (IsTargetAlive(_target))
            _target.FinishServing();
        _target = null;
        ReturnToZone();
    }

    void ReturnToZone()
    {
        _carryingFood = false;
        _activeAnimFrames = null;

        Vector3 returnTarget = _hasZone
            ? new Vector3(
                Mathf.Clamp(transform.position.x, _zoneBounds.min.x, _zoneBounds.max.x),
                Mathf.Clamp(transform.position.y, _zoneBounds.min.y, _zoneBounds.max.y),
                transform.position.z)
            : _home;

        _home = returnTarget;
        _axisWaypoint = new Vector3(returnTarget.x, transform.position.y, transform.position.z);
        _state = State.ReturnAxis1;
    }

    bool IsMoving()
    {
        switch (_state)
        {
            case State.WalkingAxis1:
            case State.WalkingAxis2:
            case State.ReturnAxis1:
            case State.ReturnAxis2:
                return true;
            case State.Idle:
                return _idleMoving;
            default:
                return false;
        }
    }

    void RefreshVisuals(bool moving)
    {
        if (!_visualsReady || _anim == null) return;

        if (!moving)
        {
            if (_wasMoving || _activeAnimFrames != null)
            {
                _activeAnimFrames = null;
                _wasMoving = false;
                if (_idleSprite != null)
                    _anim.Stop(_idleSprite);
                else if (_walkFrames != null && _walkFrames.Length > 0)
                    _anim.Stop(_walkFrames[0]);
            }
            return;
        }

        _wasMoving = true;
        Sprite[] frames = _carryingFood ? _carryFrames : _walkFrames;
        if (frames == null || frames.Length == 0)
        {
            if (_idleSprite != null)
                _anim.Stop(_idleSprite);
            return;
        }

        if (_activeAnimFrames == frames) return;

        _activeAnimFrames = frames;
        _anim.fps = walkAnimFps;
        _anim.Play(frames);
    }

    bool IsInsideZone(Vector3 p) =>
        _hasZone && _zoneBounds.Contains(new Vector3(p.x, p.y, _zoneBounds.center.z));

    bool IsTargetAlive(MonkeyCustomer customer) => customer != null;

    bool TargetGone()
    {
        if (!IsTargetAlive(_target))
        {
            _target = null;
            return true;
        }

        return _target.State == CustomerState.Leaving
            || _target.State == CustomerState.Eating;
    }

    void StepTowards(Vector3 target, float speed)
    {
        Vector3 flat = new Vector3(target.x, target.y, transform.position.z);
        transform.position = Vector3.MoveTowards(transform.position, flat, speed * Time.deltaTime);

        float dx = flat.x - transform.position.x;
        if (Mathf.Abs(dx) > 0.01f)
        {
            Vector3 s = transform.localScale;
            s.x = Mathf.Abs(s.x) * (dx < 0 ? -1f : 1f);
            transform.localScale = s;
        }
    }

    bool ReachedFlat(Vector3 target) =>
        Vector2.Distance(new Vector2(transform.position.x, transform.position.y),
                         new Vector2(target.x, target.y)) < 0.08f;

    Vector3 RandomPointInZone()
    {
        if (_hasZone)
            return new Vector3(
                Random.Range(_zoneBounds.min.x, _zoneBounds.max.x),
                Random.Range(_zoneBounds.min.y, _zoneBounds.max.y),
                transform.position.z);
        Vector2 o = Random.insideUnitCircle * 1.2f;
        return new Vector3(_home.x + o.x, _home.y + o.y, transform.position.z);
    }

    public static WaiterController GetSelectedWaiter()
    {
        int index = WaiterSelector.selectedIndex;
        if (GameData.Instance != null && !GameData.Instance.IsWaiterUnlocked(index))
            index = 0;

        WaiterType sel = (WaiterType)index;
        WaiterController fallback = null;

        foreach (var w in Object.FindObjectsByType<WaiterController>())
        {
            if (!w.gameObject.activeInHierarchy) continue;
            if (w.waiterType == sel && !w.IsBusy) return w;
            if (w.waiterType == WaiterType.Normie && !w.IsBusy)
                fallback = w;
        }

        return fallback;
    }
}
