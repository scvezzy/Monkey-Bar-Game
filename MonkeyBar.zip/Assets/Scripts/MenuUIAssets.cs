using UnityEngine;

public class MenuUIAssets : MonoBehaviour
{
    public static MenuUIAssets Instance { get; private set; }

    public Sprite buttonSprite;
    public Sprite tooltipSprite;
    public Sprite coinSprite;
    public Font   menuFont;

    public Sprite TooltipBg => tooltipSprite != null ? tooltipSprite : buttonSprite;
    public Font   MenuFont  => menuFont != null ? menuFont : UIFonts.Main;

    void Awake() => Instance = this;
}
