using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class MenuBudButton : MonoBehaviour
{
    public int budIndex;
    public DayMenuUI menu;

    void OnEnable() => WireClick();

    public void WireClick()
    {
        var btn = GetComponent<Button>();
        if (btn == null) return;

        btn.onClick.RemoveAllListeners();
        btn.onClick.AddListener(OnClick);
    }

    void OnClick()
    {
        if (menu == null) menu = GetComponentInParent<DayMenuUI>();

        if (menu != null)
            menu.SelectBud(budIndex);
        else
        {
            var buds = GetComponentInParent<BudsPanelUI>();
            buds?.SelectBud(budIndex);
        }
    }
}
