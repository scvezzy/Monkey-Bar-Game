using System.Collections;
using UnityEngine;

/// <summary>Еда на столе: банан после подачи, пустая тарелка с анимацией уборки.</summary>
public class TableFood : MonoBehaviour
{
    const float WorldFoodScale = 4f;

    SpriteRenderer _sr;
    bool           _disposing;

    public static void SpawnBanana(TableData table)
    {
        if (table == null) return;

        Clear(table);

        Sprite sprite = GameplaySprites.TableBananaIcon();
        if (sprite == null)
        {
            Debug.LogWarning("TableFood: spr_icon_banana не найден в UI/Menu/esc/");
            return;
        }

        var go = new GameObject("TableBanana");
        var food = go.AddComponent<TableFood>();
        food.Build(sprite, table);
    }

    public static void OnMonkeyFinishedEating(TableData table)
    {
        if (table == null) return;

        var food = table.GetComponentInChildren<TableFood>(true);
        if (food == null) return;
        food.SwitchToPlateAndDispose();
    }

    public static void Clear(TableData table)
    {
        if (table == null) return;

        foreach (var food in table.GetComponentsInChildren<TableFood>(true))
        {
            if (food != null && food.gameObject != null)
                Destroy(food.gameObject);
        }
    }

    void Build(Sprite sprite, TableData table)
    {
        _sr = gameObject.AddComponent<SpriteRenderer>();
        _sr.sprite = sprite;
        _sr.color = Color.white;

        var tableSr = table.GetComponent<SpriteRenderer>();
        if (tableSr != null)
        {
            _sr.sortingLayerID = tableSr.sortingLayerID;
            _sr.sortingOrder = tableSr.sortingOrder + 2;
        }

        transform.SetParent(table.transform, true);
        transform.position = GetTableTopWorldPos(tableSr, table);
        ApplyWorldScale(table.transform);
    }

    static Vector3 GetTableTopWorldPos(SpriteRenderer tableSr, TableData table)
    {
        if (tableSr != null)
        {
            Bounds wb = tableSr.bounds;
            return new Vector3(wb.center.x, wb.max.y - 0.03f, table.transform.position.z);
        }

        return table.transform.position + Vector3.up * 0.2f;
    }

    void ApplyWorldScale(Transform tableTf)
    {
        float tableScale = Mathf.Max(tableTf.lossyScale.x, 0.01f);
        float localUniform = WorldFoodScale / tableScale;
        transform.localScale = new Vector3(localUniform, localUniform, 1f);
    }

    void SwitchToPlateAndDispose()
    {
        if (_disposing) return;

        Sprite plate = GameplaySprites.TablePlateIcon();
        if (plate == null)
        {
            Debug.LogWarning("TableFood: spr_plate не найден в UI/Menu/esc/");
            Destroy(gameObject);
            return;
        }

        _sr.sprite = plate;
        if (transform.parent != null)
            ApplyWorldScale(transform.parent);
        else
            transform.localScale = Vector3.one * WorldFoodScale;

        StartCoroutine(PlateDisposeRoutine());
    }

    IEnumerator PlateDisposeRoutine()
    {
        _disposing = true;

        Vector3 worldStart = transform.position;
        transform.SetParent(null, true);

        Vector3 peak = worldStart + new Vector3(0.08f, 0.28f, 0f);
        Vector3 end  = worldStart + new Vector3(0.5f, -0.7f, 0f);

        float riseDur = 0.22f;
        float t = 0f;
        while (t < riseDur)
        {
            t += Time.deltaTime;
            transform.position = Vector3.Lerp(worldStart, peak, t / riseDur);
            yield return null;
        }

        float fallDur = 0.45f;
        t = 0f;
        while (t < fallDur)
        {
            t += Time.deltaTime;
            float p = t / fallDur;
            transform.position = Vector3.Lerp(peak, end, p * p);

            if (p > 0.55f)
            {
                float fade = 1f - ((p - 0.55f) / 0.45f);
                _sr.color = new Color(1f, 1f, 1f, fade);
            }

            yield return null;
        }

        Destroy(gameObject);
    }
}
