using UnityEngine;
using UnityEngine.UI;

public class CoinPopup : MonoBehaviour
{
    RectTransform _rt;
    CanvasGroup   _group;
    float         _timer;
    Vector2       _startPos;

    const float Duration = 1.35f;
    const float Rise     = 72f;
    const float FontSize = 46f;

    public static void Spawn(Vector3 worldPos, int amount, Canvas canvas)
    {
        if (canvas == null) return;

        var canvasRt = canvas.GetComponent<RectTransform>();
        Vector2 sp = Camera.main.WorldToScreenPoint(worldPos);
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            canvasRt, sp, canvas.worldCamera, out Vector2 cp);

        GameObject go = new GameObject("CoinPopup");
        go.transform.SetParent(canvas.transform, false);

        RectTransform row = go.AddComponent<RectTransform>();
        row.anchorMin = row.anchorMax = new Vector2(0.5f, 0.5f);
        row.pivot = new Vector2(0.5f, 0.5f);
        row.sizeDelta = new Vector2(160f, 64f);
        row.anchoredPosition = cp + new Vector2(0f, 58f);

        var group = go.AddComponent<CanvasGroup>();
        group.alpha = 1f;

        GameObject textGo = new GameObject("Amount");
        textGo.transform.SetParent(row, false);
        RectTransform textRt = textGo.AddComponent<RectTransform>();
        textRt.anchorMin = new Vector2(0f, 0.5f);
        textRt.anchorMax = new Vector2(0f, 0.5f);
        textRt.pivot = new Vector2(0f, 0.5f);
        textRt.anchoredPosition = new Vector2(0f, 0f);
        textRt.sizeDelta = new Vector2(120f, 64f);

        Text txt = textGo.AddComponent<Text>();
        txt.font = UIFonts.Main;
        txt.fontSize = (int)FontSize;
        txt.fontStyle = FontStyle.Bold;
        txt.color = new Color(0.45f, 1f, 0.38f);
        txt.alignment = TextAnchor.MiddleLeft;
        txt.horizontalOverflow = HorizontalWrapMode.Overflow;
        txt.text = $"+{amount}";

        var popup = go.AddComponent<CoinPopup>();
        popup._rt = row;
        popup._group = group;
        popup._startPos = row.anchoredPosition;
    }

    void Update()
    {
        _timer += Time.deltaTime;
        _rt.anchoredPosition = _startPos + new Vector2(0f, Rise * _timer);

        if (_timer < Duration * 0.55f)
            _group.alpha = 1f;
        else
            _group.alpha = 1f - Mathf.InverseLerp(Duration * 0.55f, Duration, _timer);

        if (_timer >= Duration)
            Destroy(gameObject);
    }
}
