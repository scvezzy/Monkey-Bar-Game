using UnityEngine;
using UnityEngine.UI;

public class PalListUI : MonoBehaviour
{
    public Text titleText;
    public PalSlotUI[] slots;

    public bool HasContent => slots != null && slots.Length >= MenuConfig.PalCount && slots[0] != null;

    public void WireManualSlots()
    {
        if (slots == null || slots.Length == 0 || slots[0] == null)
            slots = GetComponentsInChildren<PalSlotUI>(true);
    }

    public void Refresh(GameData d)
    {
        WireManualSlots();
        if (slots == null) return;
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i] == null) continue;
            slots[i].gameObject.SetActive(i < MenuConfig.PalCount);
        }
    }
}
