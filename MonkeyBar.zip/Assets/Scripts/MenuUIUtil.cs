using UnityEngine;
using UnityEngine.UI;

public static class MenuUIUtil
{
    public static Text MakeText(string name, Transform parent,
        Vector2 anchorMin, Vector2 anchorMax, Vector2 pos, Vector2 size,
        string text, int fontSize, Color color, TextAnchor align, Font font)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return MakeTextComponent(go, text, fontSize, color, align, font);
    }

    public static Text MakeTextComponent(GameObject go, string text, int fontSize, Color color, TextAnchor align, Font font)
    {
        var t = go.GetComponent<Text>();
        if (t == null) t = go.AddComponent<Text>();
        t.text = text;
        t.font = font != null ? font : UIFonts.Main;
        t.fontSize = fontSize;
        t.color = color;
        t.alignment = align;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    public static Image MakeImage(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax,
        Vector2 pos, Vector2 size, Sprite sprite, Color color)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        var img = go.AddComponent<Image>();
        img.sprite = sprite;
        img.color = color;
        img.preserveAspect = true;
        img.raycastTarget = false;
        return img;
    }

    public static Button MakeSlicedButton(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax,
        Vector2 pos, Vector2 size, Sprite bg, string label, int fontSize, Color textColor, Font font)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;

        var img = go.AddComponent<Image>();
        img.sprite = bg;
        img.type = bg != null ? Image.Type.Sliced : Image.Type.Simple;
        img.color = Color.white;

        var btn = go.AddComponent<Button>();
        btn.targetGraphic = img;

        if (!string.IsNullOrEmpty(label))
        {
            var tgo = new GameObject("Text");
            tgo.transform.SetParent(go.transform, false);
            var trt = tgo.AddComponent<RectTransform>();
            trt.anchorMin = Vector2.zero;
            trt.anchorMax = Vector2.one;
            trt.offsetMin = new Vector2(8f, 4f);
            trt.offsetMax = new Vector2(-8f, -4f);
            MakeTextComponent(tgo, label, fontSize, textColor, TextAnchor.MiddleCenter, font);
        }
        return btn;
    }

    public static void DestroyChild(GameObject go)
    {
        if (go == null) return;
#if UNITY_EDITOR
        if (!Application.isPlaying)
        {
            Object.DestroyImmediate(go);
            return;
        }
#endif
        Object.Destroy(go);
    }
}
