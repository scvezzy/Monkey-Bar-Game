public enum CustomerState
{
    WalkingToTable,
    WaitingOrder,
    BeingServed,
    Eating,
    Leaving
}
