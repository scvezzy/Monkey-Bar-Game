using UnityEngine;

public partial class MonkeyCustomer
{
    public void ApplyAppearance()
    {
        if (_sr == null) _sr = GetComponent<SpriteRenderer>();
        _useNormieSprites = _monkeyType == WaiterType.Normie;

        if (!_useNormieSprites)
        {
            if (_normieAnimator == null) _normieAnimator = GetComponent<Animator>();
            if (_normieAnimator != null) _normieAnimator.enabled = false;
            return;
        }

        _normieAnimState = null;
        _normieAnimator = GetComponent<Animator>();

        _moveFrames = GameplaySprites.NormieWalkFrames();
        if (_moveFrames == null || _moveFrames.Length == 0)
            _moveFrames = GameplaySprites.MonkeyMoveFrames(WaiterType.Normie);

        var normieEat = GameplaySprites.NormieEatFrames();
        _eatFrames  = normieEat != null && normieEat.Length > 0
            ? normieEat
            : GameplaySprites.MonkeyEatFrames(WaiterType.Normie);

        _idleSprite = _moveFrames != null && _moveFrames.Length > 0 ? _moveFrames[0] : null;
        _activeWalkFrames = null;
        _activeEatFrames  = null;

        bool hasWalkSheet = _moveFrames != null && _moveFrames.Length >= 2;
        _useNormieAnimator = !hasWalkSheet
            && _normieAnimator != null
            && _normieAnimator.runtimeAnimatorController != null;

        if (_normieAnimator != null)
            _normieAnimator.enabled = _useNormieAnimator;

        if (hasWalkSheet || !_useNormieAnimator)
        {
            if (_anim == null) _anim = GetComponent<SpriteSheetAnimator>();
            if (_anim == null) _anim = gameObject.AddComponent<SpriteSheetAnimator>();
            _anim.enabled = true;
            _anim.fps = walkAnimFps;
        }
        else
        {
            var sheetAnim = GetComponent<SpriteSheetAnimator>();
            if (sheetAnim != null)
                sheetAnim.enabled = false;
            _anim = null;
        }

        transform.localScale = new Vector3(normieScale, normieScale, 1f);
        _baseScaleX = normieScale;
        _baseScaleY = normieScale;

        _angryOverlaySprite = GameplaySprites.MonkeyAngryOverlay();

        if (_sr != null)
        {
            _sr.color = Color.white;
            _myColor = Color.white;
            if (_moveFrames != null && _moveFrames.Length > 0)
                _sr.sprite = _moveFrames[0];
        }

        EnsureAngryOverlay();
        LpcShadow.Ensure(gameObject, LpcShadow.Preset.Character);
        RefreshNormieVisuals();
        RefreshAngryOverlayLayout();
        MarkVisualLayoutDirty();
    }

    void EnsureAngryOverlay()
    {
        if (!_useNormieSprites) return;

        foreach (var t in GetComponentsInChildren<Transform>(true))
        {
            if (t != null && t.name == "AngryFace")
                Destroy(t.gameObject);
        }
        _angryGo = null;
        _angrySr = null;

        _angryGo = new GameObject("AngryFace");
        _angrySr = _angryGo.AddComponent<SpriteRenderer>();
        _angryGo.transform.SetParent(transform, false);
        _angryGo.transform.localRotation = Quaternion.identity;

        if (_angryOverlaySprite == null)
            _angryOverlaySprite = GameplaySprites.MonkeyAngryOverlay();
        if (_angryOverlaySprite != null)
            _angrySr.sprite = _angryOverlaySprite;

        _angrySr.color = new Color(1f, 1f, 1f, 0f);
        RefreshChildDrawOrder();
        _angryGo.SetActive(false);
        RefreshAngryOverlayLayout();
    }

    void RefreshAngryOverlayLayout()
    {
        if (!_useNormieSprites || _angryGo == null || _angrySr == null)
            return;

        _angryGo.transform.SetParent(transform, false);
        _angryGo.transform.localRotation = Quaternion.identity;
        _angryGo.transform.localScale = Vector3.one * angryFaceScale;

        var bodyBounds = GetBodySpriteBounds();
        var angryBounds = _angryOverlaySprite != null
            ? _angryOverlaySprite.bounds
            : new Bounds(new Vector3(0.085f, 0.08f, 0f), new Vector3(0.17f, 0.16f, 0f));

        var autoPos = new Vector2(
            bodyBounds.min.x - angryBounds.min.x,
            bodyBounds.max.y - angryBounds.max.y);

        _angryGo.transform.localPosition = new Vector3(
            autoPos.x + angryFaceOffset.x,
            autoPos.y + angryFaceOffset.y,
            0f);
        RefreshChildDrawOrder();
    }

    void ApplySeatedDrawOrder()
    {
        if (_sr != null && _myTable != null)
            _myTable.RaiseSortingForCustomer(_sr);
        RefreshChildDrawOrder();
    }

    void RefreshChildDrawOrder()
    {
        if (_sr == null) return;
        int order = _sr.sortingOrder;
        if (_angrySr != null)
            _angrySr.sortingOrder = order + 2;
    }

    Bounds GetBodySpriteBounds()
    {
        if (_sr != null && _sr.sprite != null)
            return _sr.sprite.bounds;
        return GetLayoutBounds();
    }

    void LateUpdate()
    {
        if (!_visualLayoutDirty || !_useNormieSprites) return;
        RefreshAngryOverlayLayout();
        if (_state == CustomerState.WaitingOrder && _orderBubble != null)
        {
            var order = _orderBubble.orderType;
            RefreshOrderBubbleLayout();
            _orderBubble.Show(order);
        }
        _visualLayoutDirty = false;
    }

    Bounds GetLayoutBounds()
    {
        if (_moveFrames != null && _moveFrames.Length > 0 && _moveFrames[0] != null)
            return _moveFrames[0].bounds;

        if (_sr != null && _sr.sprite != null)
        {
            var b = _sr.sprite.bounds;
            if (b.size.x <= 0.35f && b.size.y <= 0.35f)
                return b;
        }

        return new Bounds(new Vector3(0.085f, 0.12f, 0f), new Vector3(0.17f, 0.24f, 0f));
    }

    void MarkVisualLayoutDirty() => _visualLayoutDirty = true;

#if UNITY_EDITOR
    void OnValidate()
    {
        if (!Application.isPlaying || !_useNormieSprites || _angryGo == null) return;
        RefreshAngryOverlayLayout();
    }
#endif

    void UpdateAngryOverlay() => ApplyAngryOverlay();

    void ApplyAngryOverlay()
    {
        if (!_useNormieSprites || _angrySr == null) return;

        bool waiting = _state == CustomerState.WaitingOrder;
        bool leavingAngry = _state == CustomerState.Leaving && _leaveAngry;

        if (!waiting && !leavingAngry)
        {
            HideAngryOverlay();
            return;
        }

        float alpha = leavingAngry ? 1f : Mathf.InverseLerp(angerTime * 0.45f, angerTime, _waitTimer);
        _angryGo.SetActive(alpha > 0.03f);
        _angrySr.color = new Color(1f, 1f, 1f, alpha);
    }

    void HideAngryOverlay()
    {
        if (_angryGo == null || _angrySr == null) return;
        _angryGo.SetActive(false);
        _angrySr.color = new Color(1f, 1f, 1f, 0f);
    }

    bool ShouldShowAngryOverlay() =>
        _state == CustomerState.WaitingOrder
        || (_state == CustomerState.Leaving && _leaveAngry);

    void RefreshNormieVisuals()
    {
        if (!_useNormieSprites) return;

        if (_state == CustomerState.Eating)
        {
            PlayNormieEatAnimation();
            return;
        }

        if (_useNormieAnimator)
        {
            RestoreNormieAnimatorIfNeeded();
            string target = NormieAnimIdle;

            switch (_state)
            {
                case CustomerState.WalkingToTable:
                case CustomerState.Leaving:
                    target = IsWalkingMovePhase() ? NormieAnimWalk : NormieAnimIdle;
                    break;
            }

            PlayNormieAnimatorState(target);
            return;
        }

        EnsureSpriteAnimator();
        if (_anim == null) return;

        bool walking = (_state == CustomerState.WalkingToTable || _state == CustomerState.Leaving)
            && IsWalkingMovePhase();

        if (!walking)
        {
            if (_activeWalkFrames != null)
            {
                _activeWalkFrames = null;
                HoldMoveIdle();
            }
            return;
        }

        if (_moveFrames == null || _moveFrames.Length == 0) return;
        if (_activeWalkFrames == _moveFrames) return;

        _activeEatFrames  = null;
        _activeWalkFrames = _moveFrames;
        _anim.fps = walkAnimFps;
        _anim.Play(_moveFrames);
    }

    void EnsureSpriteAnimator()
    {
        if (_anim != null) return;
        _anim = GetComponent<SpriteSheetAnimator>();
        if (_anim == null) _anim = gameObject.AddComponent<SpriteSheetAnimator>();
        _anim.enabled = true;
    }

    void PlayNormieEatAnimation()
    {
        HideAngryOverlay();

        if (_eatFrames == null || _eatFrames.Length == 0)
        {
            _activeEatFrames = null;
            RestoreNormieAnimatorIfNeeded();
            HoldMoveIdle();
            return;
        }

        if (_useNormieAnimator && _normieAnimator != null)
            _normieAnimator.enabled = false;

        EnsureSpriteAnimator();
        if (_activeEatFrames == _eatFrames) return;

        _activeWalkFrames = null;
        _activeEatFrames  = _eatFrames;
        _anim.fps = eatAnimFps;
        _anim.Play(_eatFrames);
    }

    void RestoreNormieAnimatorIfNeeded()
    {
        if (!_useNormieAnimator || _normieAnimator == null) return;
        if (_normieAnimator.enabled) return;

        _normieAnimator.enabled = true;
        _normieAnimState = null;

        if (_anim != null)
            _anim.enabled = false;
    }

    void PlayNormieAnimatorState(string stateName)
    {
        if (_normieAnimator == null) return;

        if (stateName != _normieAnimState)
        {
            _normieAnimator.Play(stateName, 0, 0f);
            _normieAnimState = stateName;
        }

        _normieAnimator.speed = stateName == NormieAnimWalk ? walkAnimFps / 10f : 1f;
    }

    bool IsWalkingMovePhase()
    {
        if (_state == CustomerState.Leaving) return true;
        return _movePhase == MovePhase.ToAisle
            || _movePhase == MovePhase.Aisle
            || _movePhase == MovePhase.ToSeat;
    }

    void HoldMoveIdle()
    {
        if (_idleSprite != null)
            _anim?.Stop(_idleSprite);
        else if (_moveFrames != null && _moveFrames.Length > 0)
            _anim?.Stop(_moveFrames[0]);
    }

    void RefreshOrderBubbleLayout()
    {
        if (_orderBubble == null) return;

        var bounds = GetLayoutBounds();

        if (_useNormieSprites)
        {
            _orderBubble.bubbleWidthRatio = 1.45f;
            _orderBubble.bubbleBottomY = 0.97f;
            _orderBubble.leadingEdgeInset = 0.22f;
            _orderBubble.positionOffset = new Vector2(0f, -0.02f);
            _orderBubble.bananaHeightRatio = 0.72f;
            _orderBubble.bananaCenterRatio = new Vector2(0.54f, 0.54f);
        }
        else
        {
            _orderBubble.bubbleWidthRatio = 1.1f;
            _orderBubble.bubbleBottomY = 0.85f;
            _orderBubble.leadingEdgeInset = 0.12f;
            _orderBubble.bananaHeightRatio = 0.5f;
        }

        float facing = transform.localScale.x >= 0f ? 1f : -1f;
        int order = _sr != null ? _sr.sortingOrder : _baseSortingOrder;
        _orderBubble.Setup(order, bounds, facing);
    }

    private OrderBubble CreateOrderBubble()
    {
        var go = new GameObject("OrderBubble");
        go.transform.SetParent(transform, false);
        go.transform.localScale = Vector3.one;

        var rootSr = go.GetComponent<SpriteRenderer>();
        if (rootSr != null)
            rootSr.enabled = false;

        var bubble = go.AddComponent<OrderBubble>();
        float facing = transform.localScale.x >= 0f ? 1f : -1f;
        int order = _sr != null ? _sr.sortingOrder : _baseSortingOrder;
        bubble.Setup(order, GetLayoutBounds(), facing);
        return bubble;
    }
}
