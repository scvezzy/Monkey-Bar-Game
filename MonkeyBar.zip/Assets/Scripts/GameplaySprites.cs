using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// Спрайты геймплея: мартышки (ходьба/еда/злость), официанты, облако заказа, банан.
/// </summary>
public static class GameplaySprites
{
    static readonly Dictionary<string, Sprite[]> _sheetCache = new();

    const float MinFrameW = 10f;
    const float MinFrameH = 14f;

    public static string TypeSuffix(WaiterType type) => type switch
    {
        WaiterType.Normie  => "base",
        WaiterType.Weeb    => "weeb",
        WaiterType.Gamer   => "gamer",
        WaiterType.Tourist => "gaijin",
        _                  => "base"
    };

    public static Sprite WaiterIdle(int index)
    {
        index = Mathf.Clamp(index, 0, 3);
        return MenuCharacters.WaiterPortrait(index);
    }

    public static int WaiterIndex(WaiterType type) => Mathf.Clamp((int)type, 0, 3);

    /// <summary>Номер в имени файла: WAITER1 … WAITER4.</summary>
    public static int WaiterFileNumber(WaiterType type) => WaiterIndex(type) + 1;

    /// <summary>Обычная ходьба: basedWAITER1_walk1/2 …</summary>
    public static Sprite[] WaiterWalkFrames(WaiterType type)
    {
        int n = WaiterFileNumber(type);
        return LoadWaiterWalkFolderFrames(name => IsWaiterWalkSprite(name, n));
    }

    /// <summary>С бананом/тарелкой: bananWAITER1_move1/2 …</summary>
    public static Sprite[] WaiterCarryFrames(WaiterType type)
    {
        int n = WaiterFileNumber(type);
        return LoadWaiterWalkFolderFrames(name => IsWaiterCarrySprite(name, n));
    }

    static bool IsWaiterWalkSprite(string spriteName, int waiterNum)
    {
        if (string.IsNullOrEmpty(spriteName)) return false;
        string n = waiterNum.ToString();
        string lower = spriteName.ToLowerInvariant();
        return lower.Contains("_walk")
            && (lower.Contains($"waiter{n}_walk") || lower.Contains($"witer{n}_walk"));
    }

    static bool IsWaiterCarrySprite(string spriteName, int waiterNum)
    {
        if (string.IsNullOrEmpty(spriteName)) return false;
        string n = waiterNum.ToString();
        string lower = spriteName.ToLowerInvariant();
        return lower.StartsWith("banan")
            && lower.Contains("_move")
            && (lower.Contains($"waiter{n}_move") || lower.Contains($"witer{n}_move"));
    }

    static Sprite[] LoadWaiterWalkFolderFrames(System.Func<string, bool> match)
    {
        const string resFolder    = "Menu/waiters/walk";
        const string editorFolder = "Assets/Resources/Menu/waiters/walk";

#if UNITY_EDITOR
        var fromEditor = FilterSpritesByPredicate(LoadSpritesFromEditorFolder(editorFolder), match);
        if (fromEditor != null && fromEditor.Length > 0) return fromEditor;
#endif
        var fromRes = FilterSpritesByPredicate(Resources.LoadAll<Sprite>(resFolder), match);
        return fromRes ?? System.Array.Empty<Sprite>();
    }

    static Sprite[] FilterSpritesByPredicate(Sprite[] sprites, System.Func<string, bool> match)
    {
        if (sprites == null || sprites.Length == 0) return null;
        var list = new List<Sprite>();
        foreach (var s in sprites)
        {
            if (s != null && match(s.name))
                list.Add(s);
        }
        if (list.Count == 0) return null;
        list.Sort((a, b) => string.CompareOrdinal(a.name, b.name));
        return list.ToArray();
    }

    public static Sprite[] NormieWalkFrames()
    {
        const string editorFolder = "Assets/UI/Menu/monkey/walk_normie";
        const string resFolder    = "Menu/monkey/walk_normie";

#if UNITY_EDITOR
        var fromEditor = FilterSpritesByPredicate(
            LoadSpritesFromEditorFolder(editorFolder),
            IsMonkeyWalkSprite);
        if (fromEditor != null && fromEditor.Length > 0)
            return fromEditor;
#endif
        var fromRes = FilterSpritesByPredicate(Resources.LoadAll<Sprite>(resFolder), IsMonkeyWalkSprite);
        if (fromRes != null && fromRes.Length > 0)
            return fromRes;

        return System.Array.Empty<Sprite>();
    }

    static bool IsMonkeyWalkSprite(string spriteName)
    {
        if (string.IsNullOrEmpty(spriteName)) return false;
        return spriteName.ToLowerInvariant().Contains("monkey_basemove");
    }

    public static Sprite LpcShadowSprite()
    {
        const string editorPath = "Assets/UI/Menu/monkey/lpc_shadow.png";
        const string resPath    = "Menu/monkey/lpc_shadow";
        const string sliceName  = "lpc_shadow_0";

#if UNITY_EDITOR
        var fromEditor = LoadNamedSpriteExact(editorPath, sliceName);
        if (fromEditor != null) return fromEditor;
#endif
        return PickExactName(Resources.LoadAll<Sprite>(resPath), sliceName);
    }

    /// <summary>0dust … 3dust — от большого к маленькому.</summary>
    public static Sprite[] WalkDustFrames()
    {
        const string editorFolder = "Assets/UI/Menu/monkey";
        const string resFolder    = "Menu/monkey";

#if UNITY_EDITOR
        var fromEditor = FilterSpritesByPredicate(
            LoadSpritesFromEditorFolder(editorFolder),
            IsWalkDustSprite);
        if (fromEditor != null && fromEditor.Length > 0)
            return fromEditor;
#endif
        var fromRes = FilterSpritesByPredicate(Resources.LoadAll<Sprite>(resFolder), IsWalkDustSprite);
        return fromRes ?? System.Array.Empty<Sprite>();
    }

    static bool IsWalkDustSprite(string spriteName)
    {
        if (string.IsNullOrEmpty(spriteName)) return false;
        string lower = spriteName.ToLowerInvariant();
        return lower.StartsWith("0dust")
            || lower.StartsWith("1dust")
            || lower.StartsWith("2dust")
            || lower.StartsWith("3dust");
    }

    public static Sprite[] MonkeyMoveFrames(WaiterType type)
    {
        if (type == WaiterType.Normie)
        {
            var normieWalk = NormieWalkFrames();
            if (normieWalk != null && normieWalk.Length > 0)
                return normieWalk;
        }

        string suffix = TypeSuffix(type);
        return LoadSheet(
            $"Assets/UI/Menu/monkey/spr_monkey_move_{suffix}.gif",
            $"Menu/pals/spr_monkey_move_{suffix}");
    }

    public static Sprite[] MonkeyEatFrames(WaiterType type)
    {
        string suffix = TypeSuffix(type);
        return LoadSheet(
            $"Assets/UI/Menu/monkey/spr_monkey_eat_{suffix}.gif",
            $"Menu/monkey/spr_monkey_eat_{suffix}");
    }

    /// <summary>Кадры еды normie: eatmonkey + eatmonkey2.</summary>
    public static Sprite[] NormieEatFrames()
    {
        const string editorFolder = "Assets/Resources/Menu/monkey";
        const string resFolder    = "Menu/monkey";

#if UNITY_EDITOR
        var eat1 = LoadNamedSpriteExact($"{editorFolder}/eatmonkey.png", "eatmonkey_0");
        var eat2 = LoadNamedSpriteExact($"{editorFolder}/eatmonkey2.png", "eatmonkey2_0");
        if (eat1 != null && eat2 != null) return new[] { eat1, eat2 };
        if (eat1 != null) return new[] { eat1 };
#endif
        var all1 = Resources.LoadAll<Sprite>($"{resFolder}/eatmonkey");
        var all2 = Resources.LoadAll<Sprite>($"{resFolder}/eatmonkey2");
        var eat1r = PickExactName(all1, "eatmonkey_0") ?? (all1 != null && all1.Length > 0 ? all1[0] : null);
        var eat2r = PickExactName(all2, "eatmonkey2_0") ?? (all2 != null && all2.Length > 0 ? all2[0] : null);
        if (eat1r != null && eat2r != null) return new[] { eat1r, eat2r };
        if (eat1r != null) return new[] { eat1r };
        return System.Array.Empty<Sprite>();
    }

    /// <summary>Накладка «недовольное лицо» — только слайс spr_monkey_angry_0 (17×16), не вся текстура 64×64.</summary>
    public static Sprite MonkeyAngryOverlay()
    {
        const string baseName = "spr_monkey_angry_0";
        const string editorPath = "Assets/UI/Menu/monkey/spr_monkey_angry.gif";
        const string resourcesPath = "Menu/monkey/spr_monkey_angry";

#if UNITY_EDITOR
        var fromAssets = LoadNamedSprite(editorPath, baseName);
        if (fromAssets != null) return fromAssets;
#endif
        var fromResources = Resources.LoadAll<Sprite>(resourcesPath);
        return PickNamedOrTightestSprite(fromResources, baseName);
    }

    static Sprite _orderBubbleSprite;

    public static Sprite OrderBubble()
    {
        const string baseName = "spr_bubble_0";
        if (_orderBubbleSprite != null && _orderBubbleSprite.name == baseName)
            return _orderBubbleSprite;

        const string editorPath = "Assets/UI/Menu/monkey/spr_bubble.png";
        const string resourcesPath = "Menu/monkey/spr_bubble";

#if UNITY_EDITOR
        var fromAssets = LoadNamedSpriteExact(editorPath, baseName);
        if (fromAssets != null)
        {
            _orderBubbleSprite = fromAssets;
            return fromAssets;
        }
#endif
        var fromResources = Resources.LoadAll<Sprite>(resourcesPath);
        var fromRes = PickExactName(fromResources, baseName);
        if (fromRes != null)
            _orderBubbleSprite = fromRes;
        return fromRes;
    }

    public static Sprite[] OrderBananaFrames()
    {
        var icon = OrderBananaIcon();
        return icon != null ? new[] { icon } : System.Array.Empty<Sprite>();
    }

    public static Sprite OrderBananaIcon()
    {
        const string baseName = "spr_banana_0";
        const string editorPath = "Assets/UI/Menu/game/spr_banana.gif";
        const string resourcesPath = "Menu/game/spr_banana";

#if UNITY_EDITOR
        var fromAssets = LoadNamedSpriteExact(editorPath, baseName);
        if (fromAssets != null) return fromAssets;
#endif
        var fromResources = Resources.LoadAll<Sprite>(resourcesPath);
        return PickExactName(fromResources, baseName);
    }

    /// <summary>Банан на столе после подачи — spr_icon_banana.</summary>
    public static Sprite TableBananaIcon() => LoadEscSprite("spr_icon_banana", "spr_icon_banana_0");

    /// <summary>Пустая тарелка на столе — spr_plate.</summary>
    public static Sprite TablePlateIcon() => LoadEscSprite("spr_plate", "spr_plate_0");

    static Sprite LoadEscSprite(string fileName, string sliceName)
    {
        string[] editorPaths =
        {
            $"Assets/UI/Menu/esc/{fileName}.png",
            $"Assets/Resources/Menu/esc/{fileName}.png",
        };
        const string resPath = "Menu/esc/";

#if UNITY_EDITOR
        foreach (string path in editorPaths)
        {
            var sprite = LoadNamedSprite(path, sliceName);
            if (sprite != null) return sprite;
        }
#endif
        var fromRes = Resources.LoadAll<Sprite>(resPath + fileName);
        var exact = PickExactName(fromRes, sliceName);
        if (exact != null) return exact;
        return fromRes != null && fromRes.Length > 0 ? fromRes[0] : null;
    }

    /// <summary>Кадры песочных часов (frame_0 … frame_7) для шкалы времени.</summary>
    public static Sprite[] ClockFrames()
    {
        const string resFolder    = "Menu/clock";
        const string editorFolder = "Assets/Resources/Menu/clock";

#if UNITY_EDITOR
        var fromFolder = LoadSpritesFromEditorFolder(editorFolder);
        if (fromFolder != null && fromFolder.Length > 0)
            return fromFolder;
#endif
        var fromRes = Resources.LoadAll<Sprite>(resFolder);
        if (fromRes != null && fromRes.Length > 0)
            return SortSpritesByName(fromRes);

        (string editor, string res)[] paths =
        {
            ("Assets/Sprites/clock/clock.gif",        "Sprites/clock/clock"),
            ("Assets/Sprites/clock/clock.png",        "Sprites/clock/clock"),
            ("Assets/UI/Menu/sprite/clock/clock.gif", "Menu/sprite/clock/clock"),
            ("Assets/UI/Menu/sprite/clock/clock.png", "Menu/sprite/clock/clock"),
            ("Assets/UI/Menu/game/clock.gif",         "Menu/game/clock"),
            ("Assets/UI/Menu/game/clock.png",         "Menu/game/clock"),
        };

        foreach (var p in paths)
        {
            var frames = LoadSheet(p.editor, p.res, 4f, 4f);
            if (frames != null && frames.Length > 0)
                return frames;
        }

        return System.Array.Empty<Sprite>();
    }

    static Sprite[] SortSpritesByName(Sprite[] sprites)
    {
        if (sprites == null || sprites.Length <= 1) return sprites;
        var list = new List<Sprite>(sprites);
        list.Sort((a, b) => string.CompareOrdinal(a.name, b.name));
        return list.ToArray();
    }

#if UNITY_EDITOR
    static Sprite[] LoadSpritesFromEditorFolder(string folder)
    {
        if (!System.IO.Directory.Exists(folder)) return null;

        var list = new List<Sprite>();
        foreach (var guid in AssetDatabase.FindAssets("", new[] { folder }))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (!path.EndsWith(".png") && !path.EndsWith(".gif")) continue;
            foreach (var o in AssetDatabase.LoadAllAssetsAtPath(path))
            {
                if (o is Sprite s)
                    list.Add(s);
            }
        }

        if (list.Count == 0) return null;
        return SortSpritesByName(list.ToArray());
    }
#endif

    static Sprite[] LoadSheet(string editorPath, string resourcesPath, float minFrameW = MinFrameW, float minFrameH = MinFrameH)
    {
        string key = editorPath + "|" + resourcesPath;
        if (_sheetCache.TryGetValue(key, out var cached))
            return cached;

        Sprite[] result = null;

#if UNITY_EDITOR
        var all = AssetDatabase.LoadAllAssetsAtPath(editorPath);
        if (all != null && all.Length > 0)
            result = CollectSprites(all);
#endif
        if (result == null || result.Length == 0)
            result = Resources.LoadAll<Sprite>(resourcesPath);

        result = FilterAnimationFrames(result, minFrameW, minFrameH);
        _sheetCache[key] = result ?? System.Array.Empty<Sprite>();
        return _sheetCache[key];
    }

    static Sprite[] CollectSprites(Object[] all)
    {
        var list = new List<Sprite>();
        foreach (var o in all)
        {
            if (o is Sprite s)
                list.Add(s);
        }
        return list.ToArray();
    }

    /// <summary>Отбрасывает мусорные слайсы GIF (7×9 и т.п.), оставляет кадры с персонажем.</summary>
    static Sprite[] FilterAnimationFrames(Sprite[] sprites, float minFrameW = MinFrameW, float minFrameH = MinFrameH)
    {
        if (sprites == null || sprites.Length == 0)
            return sprites;

        var good = new List<Sprite>();
        foreach (var s in sprites)
        {
            if (s == null) continue;
            if (s.rect.width >= minFrameW && s.rect.height >= minFrameH)
                good.Add(s);
        }

        if (good.Count == 0)
        {
            var best = PickBestFrame(sprites);
            return best != null ? new[] { best } : sprites;
        }

        good.Sort((a, b) => string.CompareOrdinal(a.name, b.name));
        return good.ToArray();
    }

    static Sprite PickBestFrame(Sprite[] sprites)
    {
        if (sprites == null || sprites.Length == 0) return null;
        Sprite best = sprites[0];
        float bestArea = 0f;
        foreach (var s in sprites)
        {
            if (s == null) continue;
            float area = s.rect.width * s.rect.height;
            if (area > bestArea)
            {
                bestArea = area;
                best = s;
            }
        }
        return best;
    }

    static Sprite PickNamedOrTightestSprite(Sprite[] all, string baseName)
    {
        if (all == null || all.Length == 0) return null;

        foreach (var s in all)
        {
            if (s != null && s.name == baseName)
                return s;
        }

        Sprite tightest = null;
        float minArea = float.MaxValue;
        foreach (var s in all)
        {
            if (s == null) continue;
            float area = s.rect.width * s.rect.height;
            if (area < minArea)
            {
                minArea = area;
                tightest = s;
            }
        }
        return tightest ?? all[0];
    }

    static Sprite PickExactName(Sprite[] all, string baseName)
    {
        if (all == null) return null;
        foreach (var s in all)
        {
            if (s != null && s.name == baseName)
                return s;
        }
        return null;
    }

#if UNITY_EDITOR
    static Sprite LoadNamedSpriteExact(string assetPath, string baseName)
    {
        var all = AssetDatabase.LoadAllAssetsAtPath(assetPath);
        if (all == null) return null;

        foreach (var o in all)
        {
            if (o is Sprite s && s.name == baseName)
                return s;
        }
        return null;
    }

    static Sprite LoadNamedSprite(string assetPath, string baseName)
    {
        var all = AssetDatabase.LoadAllAssetsAtPath(assetPath);
        if (all == null) return null;

        Sprite named = null;
        Sprite tightest = null;
        float minArea = float.MaxValue;

        foreach (var o in all)
        {
            if (o is not Sprite s) continue;
            if (s.name == baseName) named = s;
            float area = s.rect.width * s.rect.height;
            if (area < minArea)
            {
                minArea = area;
                tightest = s;
            }
        }

        return named ?? tightest;
    }
#endif
}
