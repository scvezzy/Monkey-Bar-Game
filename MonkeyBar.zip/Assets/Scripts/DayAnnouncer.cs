using UnityEngine;
using UnityEngine.UI;

public class DayAnnouncer : MonoBehaviour
{
    public static DayAnnouncer Instance { get; private set; }

    private Text          _label;
    private RectTransform _labelRT;
    private CanvasGroup   _cg;

    private bool  _animating;
    private float _timer;
    private float _duration = 2.5f;

    private Vector2 _startPos;
    private Vector2 _endPos;

    void Awake()
    {
        Instance = this;
        BuildLabel();
        _label.gameObject.SetActive(false);
    }

    void BuildLabel()
    {
        GameObject go = new GameObject("AnnounceLabel");
        go.transform.SetParent(transform, false);

        _labelRT = go.AddComponent<RectTransform>();
        _labelRT.anchorMin = _labelRT.anchorMax = new Vector2(0.5f, 0.5f);
        _labelRT.sizeDelta = new Vector2(800, 120);

        _cg = go.AddComponent<CanvasGroup>();

        _label = go.AddComponent<Text>();
        _label.font      = UIFonts.Main;
        _label.fontSize  = 64;
        _label.fontStyle = FontStyle.Bold;
        _label.color     = new Color(1f, 0.95f, 0.4f);
        _label.alignment = TextAnchor.MiddleCenter;

        Outline outline = go.AddComponent<Outline>();
        outline.effectColor    = new Color(0.3f, 0.15f, 0f);
        outline.effectDistance = new Vector2(3, -3);
    }

    void Update()
    {
        if (!_animating) return;

        _timer += Time.unscaledDeltaTime;
        float t = Mathf.Clamp01(_timer / _duration);

        float alpha;
        if      (t < 0.25f) alpha = t / 0.25f;
        else if (t < 0.7f)  alpha = 1f;
        else                alpha = 1f - (t - 0.7f) / 0.3f;
        _cg.alpha = alpha;

        float posT = Mathf.Clamp01((t - 0.3f) / 0.7f);
        _labelRT.anchoredPosition = Vector2.Lerp(_startPos, _endPos, posT * posT);

        if (t >= 1f)
        {
            _animating = false;
            _label.gameObject.SetActive(false);
        }
    }

    public void ShowDayStart(int dayNumber)
    {
        Show($"ДЕНЬ {dayNumber} — СТАРТ");
    }

    public void ShowDayEnd()
    {
        Show("КОНЕЦ ДНЯ");
    }

    private void Show(string text)
    {
        _label.text = text;
        _label.gameObject.SetActive(true);

        _startPos = new Vector2(0f, -60f);
        _endPos   = new Vector2(0f,  80f);

        _labelRT.anchoredPosition = _startPos;
        _cg.alpha = 0f;
        _timer    = 0f;
        _animating = true;
    }
}
