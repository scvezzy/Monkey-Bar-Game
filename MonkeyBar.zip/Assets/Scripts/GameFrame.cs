using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Canvas))]
public class GameFrame : MonoBehaviour
{
    [Header("Timer Bar")]
    public Image  timerFill;
    public GameObject timerPanel;

    public static GameFrame Instance { get; private set; }

    void Awake()
    {
        Instance = this;
        if (timerPanel != null) timerPanel.SetActive(true);
    }

    public void ShowTimer() { if (timerPanel != null) timerPanel.SetActive(true); }
    public void HideTimer() { if (timerPanel != null) timerPanel.SetActive(false); }
}
