using UnityEngine;
using UnityEngine.UI;

public class UpgradeRowUI : MonoBehaviour
{
    public UpgradeType upgradeType;
    public Image       iconImage;
    public Image[]     slots = new Image[5];
    public Text        costLabel;
    public Button      buyButton;

    [TextArea(2, 4)]
    public string tooltipText;

    Image _btnImage;
    Image _coinImage;

    void Awake()
    {
        if (buyButton != null)
        {
            _btnImage = buyButton.GetComponent<Image>();
            ApplyButtonSprite();
            var cb = buyButton.colors;
            cb.normalColor      = Color.white;
            cb.highlightedColor = new Color(0.92f, 0.92f, 0.92f, 1f);
            cb.pressedColor     = new Color(0.78f, 0.78f, 0.78f, 1f);
            cb.disabledColor    = new Color(0.55f, 0.55f, 0.55f, 0.75f);
            buyButton.colors    = cb;
        }

        if (buyButton != null)
        {
            Transform coinT = buyButton.transform.Find("CoinIcon");
            if (coinT != null) _coinImage = coinT.GetComponent<Image>();
        }

        if (costLabel != null)
        {
            costLabel.raycastTarget = false;
            costLabel.alignByGeometry = true;
        }
    }

    void Start()
    {
        if (buyButton != null)
            buyButton.onClick.AddListener(() => GameData.Instance?.BuyUpgrade(upgradeType));

        if (!string.IsNullOrEmpty(tooltipText) && iconImage != null)
        {
            var tip = iconImage.GetComponent<UpgradeTooltip>();
            if (tip == null) tip = iconImage.gameObject.AddComponent<UpgradeTooltip>();
            tip.description = tooltipText;
        }

        ApplyButtonSprite();
        if (GameData.Instance != null) Refresh(GameData.Instance);
    }

    void ApplyButtonSprite()
    {
        if (_btnImage == null) return;
        Sprite spr = MenuUIAssets.Instance != null ? MenuUIAssets.Instance.buttonSprite : _btnImage.sprite;
        if (spr == null) return;
        _btnImage.sprite          = spr;
        _btnImage.type            = Image.Type.Sliced;
        _btnImage.fillCenter      = true;
        _btnImage.preserveAspect  = false;
        _btnImage.pixelsPerUnitMultiplier = 1f;
    }

    void FitFontToButton()
    {
        if (costLabel == null || buyButton == null) return;
        var rt = buyButton.GetComponent<RectTransform>();
        if (rt == null) return;
        float h = rt.rect.height;
        if (h < 8f) h = MenuConfig.UpgBtnH;
        costLabel.fontSize = Mathf.Clamp(
            Mathf.RoundToInt(h * 0.46f),
            MenuConfig.UpgBtnFontMin,
            MenuConfig.UpgBtnFontMax);
    }

    public void Refresh(GameData d)
    {
        if (d == null) return;
        int lvl  = d.GetLevel(upgradeType);
        int cost = d.GetCost(upgradeType);
        bool maxed  = lvl >= GameData.MaxLevel;
        bool afford = !maxed && d.Coins >= cost;

        if (slots != null)
            for (int s = 0; s < slots.Length; s++)
                if (slots[s] != null)
                    slots[s].color = s < lvl ? MenuConfig.SlotFilled : MenuConfig.SlotEmpty;

        if (costLabel != null)
        {
            costLabel.text = maxed ? MenuConfig.UpgMaxLabel : string.Format(MenuConfig.UpgCostFormat, cost);
            costLabel.color = maxed || !afford
                ? MenuConfig.UpgTextInactive
                : MenuConfig.UpgTextActive;
            FitFontToButton();
        }

        if (_btnImage != null)
            _btnImage.color = maxed || !afford
                ? MenuConfig.UpgBtnInactive
                : MenuConfig.UpgBtnActive;

        if (_coinImage != null)
            _coinImage.color = maxed || !afford
                ? MenuConfig.UpgCoinInactive
                : MenuConfig.UpgCoinActive;

        if (buyButton != null)
            buyButton.interactable = !maxed;
    }
}
