using UnityEngine;
using UnityEngine.UI;

public class WaiterCursor : MonoBehaviour
{
    public static WaiterCursor Instance { get; private set; }

    const float IconSize = 50f;
    const float CursorOffsetX = 10f;
    const float CursorOffsetY = -10f;

    GameObject    _icon;
    Image         _headImage;
    Canvas        _canvas;
    RectTransform _canvasRT;
    bool          _visible;
    bool          _built;

    void Awake() { Instance = this; }

    void LateUpdate()
    {
        if (!_built) TryBuild();
        if (!_visible || _icon == null || _canvasRT == null) return;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            _canvasRT, Input.mousePosition, null, out Vector2 localPos);

        Vector2 canvasSize = _canvasRT.sizeDelta;
        Vector2 pos = localPos + canvasSize * 0.5f + new Vector2(CursorOffsetX, CursorOffsetY);
        _icon.GetComponent<RectTransform>().anchoredPosition = pos;
    }

    void TryBuild()
    {
        Canvas[] all = Object.FindObjectsByType<Canvas>();
        foreach (var c in all)
            if (c.renderMode == RenderMode.ScreenSpaceOverlay) { _canvas = c; break; }

        if (_canvas == null) return;
        _canvasRT = _canvas.GetComponent<RectTransform>();
        _built = true;

        _icon = new GameObject("WaiterCursorIcon");
        _icon.transform.SetParent(_canvas.transform, false);
        _icon.SetActive(false);

        RectTransform rt = _icon.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0f, 0f);
        rt.anchorMax = new Vector2(0f, 0f);
        rt.pivot     = new Vector2(0f, 1f);
        rt.sizeDelta = new Vector2(IconSize, IconSize);

        _headImage = _icon.AddComponent<Image>();
        _headImage.preserveAspect = true;
        _headImage.color = Color.white;
        _headImage.raycastTarget = false;
    }

    public void Show(int index)
    {
        if (!_built) TryBuild();
        if (_icon == null || _headImage == null) return;

        index = Mathf.Clamp(index, 0, MenuConfig.BudCount - 1);
        _headImage.sprite = MenuCharacters.WaiterHeadIcon(index);

        _visible = true;
        _icon.SetActive(_headImage.sprite != null);
    }

    public void Hide()
    {
        _visible = false;
        if (_icon != null) _icon.SetActive(false);
    }
}
