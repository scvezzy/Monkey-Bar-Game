using UnityEngine;

[System.Obsolete("Use WaiterController instead.")]
public class WaiterData : MonoBehaviour
{
    public WaiterType waiterType;
    public bool busy = false;
}
