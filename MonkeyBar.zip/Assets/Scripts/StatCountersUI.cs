using UnityEngine;
using UnityEngine.UI;

public class StatCountersUI : MonoBehaviour
{
    Text _coinsText;
    Text _servedText;

    public void Wire(Transform root)
    {
        if (root == null) root = transform;
        _coinsText  = root.Find("Coins/Num")?.GetComponent<Text>();
        _servedText = root.Find("Served/Num")?.GetComponent<Text>();
        ConfigureCounterText(_coinsText);
        ConfigureCounterText(_servedText);
        Refresh();
    }

    static void ConfigureCounterText(Text t)
    {
        if (t == null) return;

        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow   = VerticalWrapMode.Overflow;
        t.alignByGeometry    = true;

        var rt = t.rectTransform;
        if (rt != null && rt.sizeDelta.x < 96f)
            rt.sizeDelta = new Vector2(96f, rt.sizeDelta.y);
    }

    void OnEnable()
    {
        if (_coinsText == null || _servedText == null)
            Wire(transform);

        if (GameData.Instance != null)
        {
            GameData.Instance.OnDataChanged -= Refresh;
            GameData.Instance.OnDataChanged += Refresh;
        }
        Refresh();
    }

    void OnDisable()
    {
        if (GameData.Instance != null)
            GameData.Instance.OnDataChanged -= Refresh;
    }

    void Refresh()
    {
        var d = GameData.Instance;
        if (d == null) return;
        if (_coinsText  != null) _coinsText.text  = d.Coins.ToString();
        if (_servedText != null) _servedText.text  = d.TotalServed.ToString();
    }
}
