using UnityEngine;

/// <summary>
/// Пиксельный шрифт для UI.
/// Положи .ttf в Assets/Resources/Fonts/PixelFont.ttf (Press Start 2P, m6x11 и т.п.)
/// </summary>
public static class UIFonts
{
    static Font _main;

    public static Font Main
    {
        get
        {
            if (_main != null) return _main;

            if (_main == null)
                _main = Resources.Load<Font>("Fonts/Pixellari");
            if (_main == null)
                _main = Resources.Load<Font>("Fonts/PlainPixel-Regular");
            if (_main == null)
                _main = Resources.Load<Font>("Fonts/PixelFont");
            if (_main == null)
            {
                string[] candidates = { "Press Start 2P", "Courier New", "Lucida Console", "Consolas" };
                foreach (string name in candidates)
                {
                    Font f = Font.CreateDynamicFontFromOSFont(name, 16);
                    if (f != null) { _main = f; break; }
                }
            }
            if (_main == null)
                _main = Font.CreateDynamicFontFromOSFont("Arial", 16);

            return _main;
        }
    }
}
