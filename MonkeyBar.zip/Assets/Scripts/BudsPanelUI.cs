using UnityEngine;
using UnityEngine.UI;

public class BudsPanelUI : MonoBehaviour
{
    public Text titleText;
    public Image portrait;
    public Text nameText;
    public Image descBg;
    public Text descText;
    public Button unlockButton;
    public Text unlockButtonText;
    public MenuBudButton[] budButtons;

    DayMenuUI _menu;
    int _selected;

    static readonly string[] WaiterNames = { "норми", "аниме", "геймер", "качок" };
    static readonly int[] UnlockReq = { 0, 5, 10, 25 };
    static readonly string[] BudDesc = {
        "Обычный любитель\nмартышек",
        "Не железная, но\nмышь точно",
        "Широкий человек\nс широкими\nамбitions",
        "Настоящий\nкачок"
    };
    static readonly Color[] BudColors = {
        new Color(1f, 0.7f, 0.1f), new Color(0.85f, 0.2f, 0.55f),
        new Color(0.15f, 0.8f, 0.2f), new Color(0.1f, 0.7f, 0.9f)
    };

    public bool HasContent => portrait != null;

    public void WireManualReferences()
    {
        if (portrait == null)
        {
            var t = transform.Find("Portrait");
            if (t != null) portrait = t.GetComponent<Image>();
        }
        if (nameText == null)
        {
            var nameBg = transform.Find("NameBg");
            if (nameBg != null && nameBg.childCount > 0)
                nameText = nameBg.GetChild(0).GetComponent<Text>();
            if (nameText == null)
            {
                var t = transform.Find("Name");
                if (t != null) nameText = t.GetComponent<Text>();
            }
        }
        if (descText == null)
        {
            var descBgT = transform.Find("DescBg");
            if (descBgT != null && descBgT.childCount > 0)
                descText = descBgT.GetChild(0).GetComponent<Text>();
        }
        if (unlockButton == null)
        {
            var t = transform.Find("BtnUnlock");
            if (t != null)
            {
                unlockButton = t.GetComponent<Button>();
                unlockButtonText = t.GetComponentInChildren<Text>();
            }
        }
        if (budButtons == null || budButtons.Length == 0)
            budButtons = GetComponentsInChildren<MenuBudButton>(true);
    }

    void ApplyPortrait(Sprite sprite, bool unlocked)
    {
        if (portrait == null) return;
        if (sprite != null)
        {
            portrait.sprite = sprite;
            portrait.preserveAspect = true;
            portrait.pixelsPerUnitMultiplier = 1f;

            var rt = portrait.rectTransform;
            float h = MenuConfig.BudPortraitH;
            float w = h * (sprite.rect.width / sprite.rect.height);
            rt.sizeDelta = new Vector2(w, h);
        }
        portrait.color = unlocked ? Color.white : Color.black;
    }

    public void Init(DayMenuUI menu)
    {
        _menu = menu;
        WireManualReferences();
        WireUnlockButton();
        WireBudButtons();
    }

    void Start()
    {
        if (_menu == null) _menu = GetComponentInParent<DayMenuUI>();
        WireManualReferences();
        WireUnlockButton();
        WireBudButtons();
        Refresh(GameData.Instance, _selected);
    }

    void WireUnlockButton()
    {
        if (unlockButton == null) return;
        unlockButton.onClick.RemoveAllListeners();
        unlockButton.onClick.AddListener(OnUnlockClicked);
    }

    void WireBudButtons()
    {
        if (budButtons == null || budButtons.Length == 0)
            budButtons = GetComponentsInChildren<MenuBudButton>(true);
        if (budButtons == null) return;

        if (_menu == null) _menu = GetComponentInParent<DayMenuUI>();

        foreach (var bb in budButtons)
        {
            if (bb == null) continue;
            bb.menu = _menu;
            bb.WireClick();
        }
    }

    void OnUnlockClicked()
    {
        WaiterType[] types = { WaiterType.Normie, WaiterType.Weeb, WaiterType.Gamer, WaiterType.Tourist };
        if (_selected > 0 && GameData.Instance != null)
            GameData.Instance.UnlockWaiter(types[_selected]);
        Refresh(GameData.Instance, _selected);
        if (_menu != null) _menu.NotifyBudsChanged();
    }

    public void SelectBud(int index)
    {
        _selected = Mathf.Clamp(index, 0, MenuConfig.BudCount - 1);
        Refresh(GameData.Instance, _selected);
    }

    public void BuildIfEmpty()
    {
        if (portrait != null && budButtons != null && budButtons.Length >= MenuConfig.BudCount) return;
        ClearContent();
        Debug.LogWarning("[BudsPanelUI] BuildIfEmpty — используй ручной layout в Hierarchy.");
    }

    public void ClearContent()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
            MenuUIUtil.DestroyChild(transform.GetChild(i).gameObject);
    }

    public void Refresh(GameData d, int selectedBud)
    {
        if (d == null) return;
        _selected = Mathf.Clamp(selectedBud, 0, MenuConfig.BudCount - 1);

        bool unlocked = d.IsWaiterUnlocked(_selected);
        int req = UnlockReq[_selected];

        if (portrait != null)
            ApplyPortrait(MenuCharacters.WaiterPortrait(_selected), unlocked);

        if (nameText != null)
            nameText.text = WaiterNames[_selected];

        if (descText != null)
        {
            if (unlocked)
                descText.text = BudDesc[_selected];
            else
                descText.text = $"Условие:\nобслужить {req} мартышек\n({d.TotalServed}/{req})";
        }

        if (unlockButton != null)
        {
            bool showUnlock = !unlocked && _selected > 0;
            unlockButton.gameObject.SetActive(showUnlock);
            if (showUnlock)
            {
                bool can = d.CanUnlockWaiter(_selected);
                unlockButton.interactable = can;
                if (unlockButtonText != null)
                    unlockButtonText.text = can ? "ОТКРЫТЬ" : "ЗАБЛОК.";
                var cb = unlockButton.colors;
                cb.normalColor = can ? Color.white : new Color(0.75f, 0.75f, 0.75f);
                unlockButton.colors = cb;
            }
        }

        if (budButtons != null)
        {
            for (int i = 0; i < budButtons.Length; i++)
            {
                if (budButtons[i] == null) continue;
                budButtons[i].gameObject.SetActive(i < MenuConfig.BudCount);
                if (i >= MenuConfig.BudCount) continue;
                var img = budButtons[i].GetComponent<Image>();
                if (img != null)
                    img.color = i == _selected
                        ? new Color(0.45f, 0.32f, 0.22f)
                        : new Color(0.25f, 0.18f, 0.12f);
            }
        }
    }
}
