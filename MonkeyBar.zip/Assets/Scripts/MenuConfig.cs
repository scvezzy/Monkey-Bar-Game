using UnityEngine;

public static class MenuConfig
{
    public static Vector2 PanelSize  = new Vector2(1200f, 900f);
    public static Color   PanelColor = new Color(0.96f, 0.78f, 0.64f, 1f);

    public static float Pad = 20f;
    public static float Gap = 14f;

    public static float LeftColW  => PanelSize.x * 0.52f - Pad * 1.5f;
    public static float UpgH      => (PanelSize.y - Pad*2 - Gap*2 - StartDayH) * 0.56f;
    public static float PalH      => (PanelSize.y - Pad*2 - Gap*2 - StartDayH) * 0.36f;

    public static float RightColW => PanelSize.x * 0.44f - Pad * 1.5f;
    public static float BudsH     => PanelSize.y - Pad*2 - Gap - StartDayH;

    public static float StartDayH = 72f;
    public static float StartDayW = 420f;

    public static Color BlockBg    = new Color(0.90f, 0.70f, 0.52f, 1f);
    public static Color BlockBorder= new Color(0.30f, 0.18f, 0.10f, 1f);
    public static Color TitleRed   = new Color(0.66f, 0.13f, 0.10f, 1f);
    public static Color SlotEmpty  = new Color(0.30f, 0.18f, 0.12f, 1f);
    public static Color SlotFilled = new Color(0.90f, 0.22f, 0.18f, 1f);
    public static Color BtnDark    = new Color(0.18f, 0.12f, 0.08f, 1f);
    public static Color BtnUnlock  = new Color(0.70f, 0.10f, 0.10f, 1f);

    public static Color UpgTextActive   = new Color(0.93f, 0.91f, 0.86f, 1f);
    public static Color UpgTextInactive = new Color(0.52f, 0.50f, 0.47f, 1f);
    public static Color UpgBtnActive    = new Color(0.58f, 0.54f, 0.48f, 1f);
    public static Color UpgBtnInactive  = new Color(0.40f, 0.38f, 0.35f, 1f);
    public static Color UpgCoinActive   = Color.white;
    public static Color UpgCoinInactive = new Color(0.55f, 0.55f, 0.55f, 1f);
    public static int   UpgBtnFontMin   = 16;
    public static int   UpgBtnFontMax   = 30;

    public static string UpgCostFormat = "УЛУЧШИТЬ: {0}";
    public static string UpgMaxLabel   = "МАКС";

    public static int FntTitle    = 28;
    public static int FntUpgRow   = 16;
    public static int FntBudsName = 22;
    public static int FntBudsDesc = 15;
    public static int FntPal      = 17;
    public static int FntCounter  = 20;
    public static int FntStartDay = 32;
    public static int FntDay      = 30;
    public static int FntWin      = 16;
    public static int FntTooltip  = 24;

    public static Color TooltipTextColor = Color.white;
    public static float TooltipBgAlpha   = 1f;

    public static float BudPortraitW = 180f;
    public static float BudPortraitH = 265f;

    public static int   UpgRows     = 4;
    public static float UpgIconW    = 40f;
    public static float UpgSlotW    = 22f;
    public static int   UpgSlotCnt  = 5;
    public static float UpgSlotGap  = 5f;
    public static float UpgBtnW     = 180f;
    public static float UpgBtnH     = 40f;

    public static int   PalCount    = 3;
    public static int   BudCount    = 4;
    public static float PalIconH    = 100f;
}
