using UnityEngine;
using UnityEngine.UI;

public partial class DayMenuUI : MonoBehaviour
{
    [Header("References")]
    public CustomerSpawner customerSpawner;

    [Header("UI Mode")]
    [Tooltip("false — ручная настройка интерфейса; true — автоматическая сборка UI при запуске")]
    public bool buildUIAtRuntime = false;

    [Header("Manual UI — перетащи объекты сюда")]
    public Text dayText;
    public Text coinsText;
    public Text servedText;
    public Text budsName;
    public Text budsDesc;
    public Text unlockButtonText;
    public Button startDayButton;
    public Button unlockButton;
    public UpgradeRowUI[] upgradeRows;
    public MenuBudButton[] budButtons;
    public PalListUI palList;
    public BudsPanelUI budsPanel;

    [Header("Animation")]
    public float slideDuration = 0.55f;

    private RectTransform _rt;
    private bool    _sliding, _slidingIn;
    private float   _slideTimer, _slideInTimer;
    private Vector2 _startPos, _endPos, _siStart, _siEnd;

    private Text      _coinsText, _servedText, _dayText;
    private Image[][] _slots           = new Image[4][];
    private Text[]    _upgradeCostText = new Text[4];
    private Text      _budsName, _budsDesc;
    private Button    _unlockBtn;
    private Text      _unlockBtnText;
    private int       _selectedBud;

    static readonly string[]      WaiterNames = { "норми", "аниме", "геймер", "качок" };
    static readonly int[]         UnlockReq   = { 0, 5, 10, 25 };
    static readonly UpgradeType[] UpgTypes    = { UpgradeType.Table, UpgradeType.Speed, UpgradeType.ServingTime, UpgradeType.DayTime };
    static readonly int[]         UpgCosts    = { 80, 30, 40, 15 };
    static readonly string[]      PalNames    = { "норми\nгость", "аниме\nгость", "геймер\nгость" };
    static readonly Color[]       PalColors   = {
        new Color(1f,0.55f,0.1f), new Color(0.7f,0.1f,0.7f),
        new Color(0.1f,0.5f,0.9f)
    };
    static readonly Color[] UpgIconColors = {
        new Color(0.40f,0.22f,0.08f), new Color(0.50f,0.30f,0.08f),
        new Color(0.60f,0.18f,0.08f), new Color(0.70f,0.12f,0.08f)
    };
    static readonly Color[] BudColors = {
        new Color(1f,0.7f,0.1f), new Color(0.85f,0.2f,0.55f),
        new Color(0.15f,0.8f,0.2f), new Color(0.1f,0.7f,0.9f)
    };
    static readonly string[] UpgTips = {
        "Добавляет дополнительный\nстолик для мартышек",
        "Увеличивает скорость\nофицианта",
        "Взаимодействие с мартышками\n(посетителями) происходит быстрее",
        "Продолжительность дня"
    };

    Font _font;
    float _uiScale = 1f;

    int FS(int baseSize) => Mathf.Max(11, Mathf.RoundToInt(baseSize * _uiScale));
    float S(float v) => v * _uiScale;

    void Awake()
    {
        _rt   = GetComponent<RectTransform>();
        _font = UIFonts.Main;
        Time.timeScale = 0f;
        if (customerSpawner != null) customerSpawner.enabled = false;
    }

    void Start()
    {
        if (buildUIAtRuntime)
            BuildUI();
        else
            WireManualUI();

        RefreshUI();
        if (GameData.Instance != null) GameData.Instance.OnDataChanged += RefreshUI;
        if (DayTimer.Instance  != null) DayTimer.Instance.OnDayEnd     += OnDayEnded;
    }

    public void StartDayClicked() => OnStartDay();

    public void SelectBud(int index)
    {
        _selectedBud = Mathf.Clamp(index, 0, MenuConfig.BudCount - 1);
        if (budsPanel != null)
            budsPanel.Refresh(GameData.Instance, _selectedBud);
        else
            RefreshBuds();
    }

    public void NotifyBudsChanged()
    {
        var d = GameData.Instance;
        if (palList != null) palList.Refresh(d);
        if (budsPanel != null) budsPanel.Refresh(d, _selectedBud);
        else RefreshBuds();
    }

    void WireManualUI()
    {
        _budsName        = budsName;
        _budsDesc        = budsDesc;
        _unlockBtnText   = unlockButtonText;
        _unlockBtn       = unlockButton;

        if (startDayButton != null)
        {
            startDayButton.onClick.RemoveListener(StartDayClicked);
            startDayButton.onClick.AddListener(StartDayClicked);
        }
        else
        {
            var sd = transform.Find("BtnStartDay");
            if (sd != null)
            {
                startDayButton = sd.GetComponent<Button>();
                if (sd.GetComponent<MenuStartDayButton>() == null)
                    sd.gameObject.AddComponent<MenuStartDayButton>();
                startDayButton.onClick.AddListener(StartDayClicked);
            }
        }

        if (coinsText == null || servedText == null)
        {
            var stats = transform.Find("StatCounters");
            if (stats != null)
            {
                var served = stats.Find("Served/Num");
                var coins = stats.Find("Coins/Num");
                if (servedText == null && served != null) servedText = served.GetComponent<Text>();
                if (coinsText == null && coins != null) coinsText = coins.GetComponent<Text>();
            }
        }

        var statRoot = transform.Find("StatCounters");
        if (statRoot != null)
        {
            var coinsNum = statRoot.Find("Coins/Num")?.GetComponent<Text>();
            var servedNum = statRoot.Find("Served/Num")?.GetComponent<Text>();
            if (coinsNum != null) coinsText = coinsNum;
            if (servedNum != null) servedText = servedNum;

            var live = statRoot.GetComponent<StatCountersUI>();
            if (live == null) live = statRoot.gameObject.AddComponent<StatCountersUI>();
            live.Wire(statRoot);
        }

        _dayText    = dayText;
        _coinsText  = coinsText;
        _servedText = servedText;

        if (unlockButton != null)
        {
            unlockButton.onClick.RemoveAllListeners();
            unlockButton.onClick.AddListener(() =>
            {
                WaiterType[] types = { WaiterType.Normie, WaiterType.Weeb, WaiterType.Gamer, WaiterType.Tourist };
                if (_selectedBud > 0 && GameData.Instance != null)
                    GameData.Instance.UnlockWaiter(types[_selectedBud]);
                NotifyBudsChanged();
            });
        }

        if (upgradeRows == null || upgradeRows.Length == 0)
            upgradeRows = GetComponentsInChildren<UpgradeRowUI>(true);

        if (palList == null)
        {
            var palGo = transform.Find("pal list");
            if (palGo != null)
            {
                palList = palGo.GetComponent<PalListUI>();
                if (palList == null) palList = palGo.gameObject.AddComponent<PalListUI>();
            }
        }
        if (budsPanel == null)
        {
            var budsGo = transform.Find("buds");
            if (budsGo != null)
            {
                budsPanel = budsGo.GetComponent<BudsPanelUI>();
                if (budsPanel == null) budsPanel = budsGo.gameObject.AddComponent<BudsPanelUI>();
            }
        }
        if (budsPanel != null)
        {
            budsPanel.WireManualReferences();
            if (!budsPanel.HasContent)
                budsPanel.BuildIfEmpty();
            budsPanel.Init(this);
            budButtons = budsPanel.budButtons;
        }

        if (palList != null)
            palList.WireManualSlots();

        Canvas cv = GetComponentInParent<Canvas>();
        if (cv != null)
        {
            var assets = cv.GetComponent<MenuUIAssets>();
            Font tipFont = assets != null ? assets.MenuFont : UIFonts.Main;
            Sprite tipBg = assets != null ? assets.TooltipBg : null;
            UpgradeTooltip.Init(cv.transform, tipFont, MenuConfig.FntTooltip, 1f, tipBg);
        }
    }

    void OnDestroy()
    {
        if (GameData.Instance != null) GameData.Instance.OnDataChanged -= RefreshUI;
        if (DayTimer.Instance  != null) DayTimer.Instance.OnDayEnd     -= OnDayEnded;
    }

    void Update()
    {
        if (_sliding)
        {
            _slideTimer += Time.unscaledDeltaTime;
            float t = Mathf.Clamp01(_slideTimer / slideDuration);
            _rt.anchoredPosition = Vector2.Lerp(_startPos, _endPos, t * t);
            if (t >= 1f)
            {
                _sliding = false;
                gameObject.SetActive(false);
                if (customerSpawner != null)
                {
                    customerSpawner.enabled = true;
                    customerSpawner.BeginDay();
                }
                if (DayTimer.Instance != null) DayTimer.Instance.StartDay();
            }
            return;
        }
        if (_slidingIn)
        {
            _slideInTimer += Time.unscaledDeltaTime;
            float t    = Mathf.Clamp01(_slideInTimer / slideDuration);
            float ease = 1f - (1f - t) * (1f - t);
            _rt.anchoredPosition = Vector2.Lerp(_siStart, _siEnd, ease);
            if (t >= 1f)
            {
                _slidingIn = false;
                _rt.anchoredPosition = _siEnd;
                Time.timeScale = 0f;
                RefreshUI();
            }
        }
    }

    void OnDayEnded()
    {
        float h = GetPanelHeight() + 100f;
        _rt.anchoredPosition = new Vector2(0f, -h);
        gameObject.SetActive(true);
        _siStart = _rt.anchoredPosition;
        _siEnd   = Vector2.zero;
        _slideInTimer = 0f;
        _slidingIn    = true;
        if (customerSpawner != null)
        {
            customerSpawner.enabled = false;
            customerSpawner.EndDay();
        }
    }

    void OnStartDay()
    {
        if (_sliding) return;

        foreach (var m in Object.FindObjectsByType<MonkeyCustomer>())
        {
            if (m.AssignedTable != null) m.AssignedTable.Free();
            Destroy(m.gameObject);
        }
        foreach (var t in Object.FindObjectsByType<TableData>(FindObjectsInactive.Include))
            t.Free();

        if (GameData.Instance != null) GameData.Instance.ApplyWaiters();

        _startPos   = _rt.anchoredPosition;
        _endPos     = _startPos - new Vector2(0f, GetPanelHeight() + 100f);
        _slideTimer = 0f;
        _sliding    = true;
    }

    void RefreshUI()
    {
        var d = GameData.Instance; if (d == null) return;
        if (_coinsText  != null) _coinsText.text  = d.Coins.ToString();
        if (_servedText != null) _servedText.text  = d.TotalServed.ToString();
        if (_dayText    != null) _dayText.text     = $"День {d.DayNumber}";

        for (int i = 0; i < 4; i++)
        {
            int lvl = d.GetLevel(UpgTypes[i]);

            if (buildUIAtRuntime)
            {
                if (_slots[i] != null)
                    for (int s = 0; s < GameData.MaxLevel; s++)
                        if (_slots[i][s] != null)
                            _slots[i][s].color = s < lvl ? MenuConfig.SlotFilled : MenuConfig.SlotEmpty;
                if (_upgradeCostText[i] != null)
                    _upgradeCostText[i].text = lvl >= GameData.MaxLevel
                        ? "МАКС" : $"улучшить: {d.GetCost(UpgTypes[i])}";
            }
        }

        if (!buildUIAtRuntime && upgradeRows != null)
            foreach (var row in upgradeRows)
                if (row != null) row.Refresh(d);

        if (palList != null) palList.Refresh(d);
        if (budsPanel != null)
            budsPanel.Refresh(d, _selectedBud);
        else
            RefreshBuds();
    }

    void RefreshBuds()
    {
        var d = GameData.Instance; if (d == null) return;
        bool isUnlocked = d.IsWaiterUnlocked(_selectedBud);
        int  req = UnlockReq[_selectedBud];
        if (_budsName != null) _budsName.text = WaiterNames[_selectedBud];
        if (_budsDesc != null)
            _budsDesc.text = isUnlocked
                ? "Доступен!"
                : $"Условие:\nобслужить {req} мартышек\n({d.TotalServed}/{req})";
        if (_unlockBtn != null)
        {
            _unlockBtn.gameObject.SetActive(!isUnlocked && _selectedBud > 0);
            bool can = d.CanUnlockWaiter(_selectedBud);
            if (_unlockBtnText != null) _unlockBtnText.text = can ? "ОТКРЫТЬ" : $"Нужно: {req} шт.";
            var cb = _unlockBtn.colors;
            cb.normalColor = can ? MenuConfig.BtnUnlock : new Color(0.4f,0.4f,0.4f);
            _unlockBtn.interactable = can;
            _unlockBtn.colors = cb;
        }
    }

    float GetPanelWidth()  => _rt != null && _rt.rect.width  > 10f ? _rt.rect.width  : MenuConfig.PanelSize.x;
    float GetPanelHeight() => _rt != null && _rt.rect.height > 10f ? _rt.rect.height : MenuConfig.PanelSize.y;

}
