using UnityEngine;

/// <summary>Пыль за ногами мартышки: dust0 → dust3, затухает на полу.</summary>
public class WalkDustPuff : MonoBehaviour
{
    const float FrameTime = 0.09f;

    static Sprite[] s_frames;

    SpriteRenderer _sr;
    float          _timer;
    int            _index;

    public static void Spawn(Vector3 worldPos, float facingSign, int sortingOrder, int sortingLayerId = 0)
    {
        s_frames ??= GameplaySprites.WalkDustFrames();
        if (s_frames == null || s_frames.Length == 0) return;

        var go = new GameObject("WalkDust");
        go.transform.position = worldPos;

        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = s_frames[0];
        sr.color = new Color(1f, 1f, 1f, 0.38f);
        sr.sortingLayerID = sortingLayerId;
        sr.sortingOrder = sortingOrder;

        float behindX = -Mathf.Sign(facingSign) * 0.06f;
        go.transform.position += new Vector3(behindX, 0.02f, 0f);

        var puff = go.AddComponent<WalkDustPuff>();
        puff._sr = sr;
        puff.ApplyFrame(0);
    }

    void ApplyFrame(int index)
    {
        if (s_frames == null || _sr == null) return;
        index = Mathf.Clamp(index, 0, s_frames.Length - 1);
        _sr.sprite = s_frames[index];

        float t = index / Mathf.Max(1f, s_frames.Length - 1);
        float scale = Mathf.Lerp(1f, 0.55f, t);
        transform.localScale = Vector3.one * scale;
        _sr.color = new Color(1f, 1f, 1f, Mathf.Lerp(0.38f, 0.08f, t));
    }

    void Update()
    {
        _timer += Time.deltaTime;
        if (_timer < FrameTime) return;

        _timer -= FrameTime;
        _index++;

        if (_index >= (s_frames?.Length ?? 0))
        {
            Destroy(gameObject);
            return;
        }

        ApplyFrame(_index);
    }
}
