using UnityEngine;

public enum UpgradeType { Table, Speed, ServingTime, DayTime }

public class GameData : MonoBehaviour
{
    public static GameData Instance { get; private set; }

    public int Coins       = 0;
    public int TotalServed = 0;
    public int DayNumber   = 1;

    public int TableLevel       = 0;
    public int SpeedLevel       = 0;
    public int ServingTimeLevel = 0;
    public int DayTimeLevel     = 0;

    public const int MaxLevel = 5;

    public static readonly int[] TableCost       = { 80, 80, 80, 80, 80 };
    public static readonly int[] SpeedCost       = { 30, 30, 30, 30, 30 };
    public static readonly int[] ServingTimeCost = { 40, 40, 40, 40, 40 };
    public static readonly int[] DayTimeCost     = { 15, 15, 15, 15, 15 };

    public bool WeebUnlocked   = false;
    public bool GamerUnlocked  = false;
    public bool GaijinUnlocked = false;

    public const int WeebUnlockReq   = 5;
    public const int GamerUnlockReq  = 10;
    public const int GaijinUnlockReq = 25;
    public const int WinCoins = 1000;
    public const int CoinsPerMonkey = 10;

    public int   ActiveTables    => 3 + TableLevel;
    public float WaiterSpeed     => 3f + SpeedLevel * 0.5f;
    public float ServingDuration => Mathf.Max(1f, 5f - ServingTimeLevel * 0.8f);
    public float CustomerPatience => 6f + ServingTimeLevel * 2f;
    public float DayDuration
    {
        get
        {
            float[] durations = { 45f, 72f, 96f, 108f, 120f };
            return durations[Mathf.Clamp(DayTimeLevel, 0, 4)];
        }
    }

    public System.Action OnDataChanged;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start() => ApplyWaiters();

    public void AddCoins(int amount)
    {
        Coins += amount;
        CheckUnlocks();
        OnDataChanged?.Invoke();
    }

    public void AddServed(int amount = 1)
    {
        TotalServed += amount;
        CheckUnlocks();
        OnDataChanged?.Invoke();
    }

    public void NextDay()
    {
        DayNumber++;
        OnDataChanged?.Invoke();
    }

    public bool BuyUpgrade(UpgradeType type)
    {
        int level; int[] costs;
        switch (type)
        {
            case UpgradeType.Table:       level = TableLevel;       costs = TableCost;       break;
            case UpgradeType.Speed:       level = SpeedLevel;       costs = SpeedCost;       break;
            case UpgradeType.ServingTime: level = ServingTimeLevel; costs = ServingTimeCost; break;
            case UpgradeType.DayTime:     level = DayTimeLevel;     costs = DayTimeCost;     break;
            default: return false;
        }
        if (level >= MaxLevel || Coins < costs[level]) return false;
        Coins -= costs[level];
        switch (type)
        {
            case UpgradeType.Table:       TableLevel++;       break;
            case UpgradeType.Speed:       SpeedLevel++;       break;
            case UpgradeType.ServingTime: ServingTimeLevel++; break;
            case UpgradeType.DayTime:     DayTimeLevel++;     break;
        }
        OnDataChanged?.Invoke();

        if (type == UpgradeType.Table)
        {
            CustomerSpawner sp = Object.FindAnyObjectByType<CustomerSpawner>();
            if (sp != null) sp.ApplyTableUpgrade();
        }

        return true;
    }

    public bool UnlockWaiter(WaiterType type)
    {
        bool alreadyUnlocked = false;
        int req = 0;
        switch (type)
        {
            case WaiterType.Weeb:    alreadyUnlocked = WeebUnlocked;   req = WeebUnlockReq;   break;
            case WaiterType.Gamer:   alreadyUnlocked = GamerUnlocked;  req = GamerUnlockReq;  break;
            case WaiterType.Tourist: alreadyUnlocked = GaijinUnlocked; req = GaijinUnlockReq; break;
            default: return false;
        }
        if (alreadyUnlocked) return false;
        if (TotalServed < req) return false;

        switch (type)
        {
            case WaiterType.Weeb:    WeebUnlocked   = true; break;
            case WaiterType.Gamer:   GamerUnlocked  = true; break;
            case WaiterType.Tourist: GaijinUnlocked = true; break;
        }

        ApplyWaiters();
        OnDataChanged?.Invoke();
        return true;
    }

    public void ApplyWaiters()
    {
        SetWaiterActive("Waiter",  true);
        SetWaiterActive("Waiter2", WeebUnlocked);
        SetWaiterActive("Waiter3", GamerUnlocked);
        SetWaiterActive("Waiter4", GaijinUnlocked);
        WaiterSelector.EnsureValidSelection();
    }

    static void SetWaiterActive(string name, bool active)
    {
        GameObject go = GameObject.Find(name);
        if (go == null)
        {
            foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsInactive.Include))
                if (t.name == name) { go = t.gameObject; break; }
        }
        if (go != null) go.SetActive(active);
    }

    public int GetLevel(UpgradeType type)
    {
        switch (type)
        {
            case UpgradeType.Table:       return TableLevel;
            case UpgradeType.Speed:       return SpeedLevel;
            case UpgradeType.ServingTime: return ServingTimeLevel;
            case UpgradeType.DayTime:     return DayTimeLevel;
        }
        return 0;
    }

    public int GetCost(UpgradeType type)
    {
        int level = GetLevel(type);
        if (level >= MaxLevel) return 0;
        switch (type)
        {
            case UpgradeType.Table:       return TableCost[level];
            case UpgradeType.Speed:       return SpeedCost[level];
            case UpgradeType.ServingTime: return ServingTimeCost[level];
            case UpgradeType.DayTime:     return DayTimeCost[level];
        }
        return 0;
    }

    void CheckUnlocks()
    {
    }

    public bool IsWaiterUnlocked(int index)
    {
        switch (index)
        {
            case 0: return true;
            case 1: return WeebUnlocked;
            case 2: return GamerUnlocked;
            case 3: return GaijinUnlocked;
            default: return false;
        }
    }

    public bool CanUnlockWaiter(int index)
    {
        if (IsWaiterUnlocked(index)) return false;
        switch (index)
        {
            case 1: return TotalServed >= WeebUnlockReq;
            case 2: return TotalServed >= GamerUnlockReq;
            case 3: return TotalServed >= GaijinUnlockReq;
            default: return false;
        }
    }
}
