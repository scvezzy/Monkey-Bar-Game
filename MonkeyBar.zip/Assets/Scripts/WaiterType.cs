public enum WaiterType
{
    Normie,
    Weeb,
    Gamer,
    Tourist
}
