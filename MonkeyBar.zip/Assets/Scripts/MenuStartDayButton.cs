using UnityEngine;
using UnityEngine.UI;

public class MenuStartDayButton : MonoBehaviour
{
    public DayMenuUI menu;

    void Start()
    {
        if (menu == null) menu = GetComponentInParent<DayMenuUI>();
        var btn = GetComponent<Button>();
        if (btn != null && menu != null)
            btn.onClick.AddListener(menu.StartDayClicked);
    }
}
