using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class UIImageFrameAnimator : MonoBehaviour
{
    public float fps = 8f;

    Image    _image;
    Sprite[] _frames;
    int      _index;
    float    _timer;
    bool     _playing;

    void Awake() => _image = GetComponent<Image>();

    public void Play(Sprite[] frames)
    {
        if (frames == null || frames.Length == 0) return;

        _frames  = frames;
        _playing = frames.Length > 1;
        _index   = 0;
        _timer   = 0f;

        if (_image != null)
        {
            _image.sprite = frames[0];
            _image.preserveAspect = true;
            _image.color = Color.white;
        }
    }

    void Update()
    {
        if (!_playing || _frames == null || _frames.Length <= 1 || _image == null)
            return;

        _timer += Time.deltaTime;
        float frameTime = 1f / Mathf.Max(1f, fps);
        while (_timer >= frameTime)
        {
            _timer -= frameTime;
            _index = (_index + 1) % _frames.Length;
            _image.sprite = _frames[_index];
        }
    }
}
