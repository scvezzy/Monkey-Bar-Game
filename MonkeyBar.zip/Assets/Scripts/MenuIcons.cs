using UnityEngine;

public static class MenuIcons
{
    static Sprite Load(string path) => Resources.Load<Sprite>(path);

    public static Sprite Coin => Load("Menu/pint/spr_coin");

    public static Sprite ServedMonkey => Load("Menu/pint/spr_icon_monkey");
}
