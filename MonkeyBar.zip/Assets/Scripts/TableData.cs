using UnityEngine;

public class TableData : MonoBehaviour
{
    public bool occupied = false;

    public Transform seatPoint;

    [Tooltip("Смещение позиции посадки по оси Y относительно верхнего края стола")]
    public float seatAboveOffset = 0.32f;

    [Tooltip("Допустимый зазор при подходе посетителя к столу снизу")]
    public float approachGap = 0.06f;

    [Tooltip("Расстояние от края стола до точки обслуживания официанта")]
    public float serveSideGap = 0.06f;

    [Tooltip("Пользовательская точка обслуживания официанта")]
    public Transform servePoint;

    int _savedSortingOrder;
    bool _sortingRaised;

    void Awake() => EnsureTableShadow();

    void OnEnable() => EnsureTableShadow();

    void EnsureTableShadow()
    {
        if (!gameObject.activeInHierarchy) return;
        LpcShadow.Ensure(gameObject, LpcShadow.Preset.Table);
    }

    public Bounds GetBounds()
    {
        var sr = GetComponent<SpriteRenderer>();
        return sr != null ? sr.bounds : new Bounds(transform.position, Vector3.one);
    }

    public Vector3 GetSeatPosition(Vector3 approachFrom)
    {
        if (seatPoint != null) return seatPoint.position;

        Bounds b = GetBounds();
        return new Vector3(b.center.x, b.max.y + seatAboveOffset, approachFrom.z);
    }

    public Vector3 GetAislePoint(float aisleY, Vector3 approachFrom)
    {
        if (seatPoint != null) return new Vector3(seatPoint.position.x, aisleY, approachFrom.z);

        Bounds b = GetBounds();
        return new Vector3(b.center.x, aisleY, approachFrom.z);
    }

    public Vector3 GetServePosition(Vector3 approachFrom)
    {
        if (servePoint != null)
            return servePoint.position;

        Bounds b = GetBounds();
        float y = b.center.y;

        float rightX = b.max.x + serveSideGap;
        float leftX  = b.min.x - serveSideGap;
        float x = Mathf.Abs(approachFrom.x - rightX) <= Mathf.Abs(approachFrom.x - leftX)
            ? rightX
            : leftX;

        return new Vector3(x, y, approachFrom.z);
    }

    public void Occupy()
    {
        TableFood.Clear(this);
        occupied = true;
    }

    public void Free()
    {
        occupied = false;
        RestoreSorting();
    }

    public void RaiseSortingForCustomer(SpriteRenderer customerSr)
    {
        var sr = GetComponent<SpriteRenderer>();
        if (sr == null || customerSr == null) return;

        if (!_sortingRaised)
        {
            _savedSortingOrder = sr.sortingOrder;
            sr.sortingOrder = _savedSortingOrder + 1;
            _sortingRaised = true;
        }

        customerSr.sortingOrder = _savedSortingOrder;
    }

    public void RestoreSorting()
    {
        if (!_sortingRaised) return;
        var sr = GetComponent<SpriteRenderer>();
        if (sr != null)
            sr.sortingOrder = _savedSortingOrder;
        _sortingRaised = false;
    }
}
