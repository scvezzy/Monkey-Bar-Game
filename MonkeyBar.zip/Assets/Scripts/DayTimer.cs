using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Таймер игрового дня. Управляет шкалой через GameFrame.
/// </summary>
public class DayTimer : MonoBehaviour
{
    // Оставляем для обратной совместимости с Setup Tool
    [HideInInspector] public Image timerBar;
    [HideInInspector] public GameObject timerBarContainer;

    public static DayTimer Instance { get; private set; }

    private float _timeLeft;
    private float _dayDuration;
    private bool  _running = false;
    private bool  _waitingForExit;
    private bool  _endingDay;

    public System.Action OnDayEnd;
    public bool IsRunning => _running;
    public bool IsWaitingForCustomers => _waitingForExit;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(this); return; }
        Instance = this;
    }

    void Start()
    {
        if (GameHUD.Instance != null)
            GameHUD.Instance.StopTimer();
    }

    void Update()
    {
        if (_waitingForExit)
        {
            if (!CafeHasMonkeys())
                EndDay();
            return;
        }

        if (!_running) return;

        _timeLeft -= Time.deltaTime;
        _timeLeft  = Mathf.Max(0f, _timeLeft);

        float fill = _timeLeft / Mathf.Max(_dayDuration, 1f);

        if (GameHUD.Instance != null)
            GameHUD.Instance.SetFill(fill);

        if (_timeLeft <= 0f)
            BeginWaitingForMonkeysToLeave();
    }

    static bool CafeHasMonkeys()
    {
        return Object.FindObjectsByType<MonkeyCustomer>().Length > 0;
    }

    void BeginWaitingForMonkeysToLeave()
    {
        _running = false;
        _waitingForExit = true;
        _timeLeft = 0f;

        if (GameHUD.Instance != null)
            GameHUD.Instance.SetFill(0f);

        var spawner = Object.FindAnyObjectByType<CustomerSpawner>();
        if (spawner != null)
            spawner.StopSpawningForDay();

        Debug.Log("[DayTimer] Время вышло — ждём, пока мартышки уйдут");

        if (!CafeHasMonkeys())
            EndDay();
    }

    public void StartDay()
    {
        _dayDuration = GameData.Instance != null ? GameData.Instance.DayDuration : 90f;
        _timeLeft    = _dayDuration;
        _waitingForExit = false;
        _endingDay = false;
        Time.timeScale = 1f;
        _running     = true;

        if (GameHUD.Instance != null)
            GameHUD.Instance.StartTimer(_dayDuration);

        int day = GameData.Instance != null ? GameData.Instance.DayNumber : 1;
        if (DayAnnouncer.Instance != null)
            DayAnnouncer.Instance.ShowDayStart(day);

        Debug.Log($"[DayTimer] День начался. Длительность: {_dayDuration} сек");
    }

    public void PauseForMenu()
    {
        _running = false;
        Time.timeScale = 0f;
        if (GameHUD.Instance != null)
            GameHUD.Instance.StopTimer();
    }

    private void EndDay()
    {
        if (_endingDay) return;
        _endingDay = true;
        _running = false;
        _waitingForExit = false;

        if (GameHUD.Instance != null)
            GameHUD.Instance.StopTimer();

        if (DayAnnouncer.Instance != null)
        {
            DayAnnouncer.Instance.ShowDayEnd();
            Invoke(nameof(TriggerDayEnd), 2.8f);
        }
        else
        {
            TriggerDayEnd();
        }
    }

    private void TriggerDayEnd()
    {
        Time.timeScale = 0f;
        if (GameData.Instance != null) GameData.Instance.NextDay();
        Debug.Log("[DayTimer] День завершён!");
        OnDayEnd?.Invoke();
    }
}
