using UnityEngine;

/// <summary>Овальная тень lpc_shadow под спрайтом.</summary>
[DisallowMultipleComponent]
public class LpcShadow : MonoBehaviour
{
    public enum Preset { Character, Table }

    public float widthRatio  = 0.9f;
    public float heightRatio = 0.34f;
    public Vector2 localOffset = Vector2.zero;
    [Range(0f, 1f)] public float alpha = 0.82f;
    public int sortingOrderOffset = -1;

    const int FloorSortingOrder = 0;

    SpriteRenderer _ownerSr;
    SpriteRenderer _shadowSr;
    Transform      _shadowTf;
    Preset         _preset = Preset.Character;
    bool           _drawOrderFixed;

    public static void Ensure(GameObject host, Preset preset)
    {
        if (host == null || !host.activeInHierarchy) return;
        var shadow = host.GetComponent<LpcShadow>();
        if (shadow == null) shadow = host.AddComponent<LpcShadow>();
        shadow._preset = preset;
        shadow.ApplyPreset(preset);
        shadow.Build();
        shadow.EnsureDrawOrder();
    }

    void Start()
    {
        if (_shadowSr == null) Build();
        EnsureDrawOrder();
    }

    void LateUpdate()
    {
        RefreshLayout();
        SyncSorting();
    }

    void ApplyPreset(Preset preset)
    {
        if (preset == Preset.Table)
        {
            widthRatio  = 1.1f;
            heightRatio = 0.38f;
            alpha       = 0.8f;
            localOffset = new Vector2(0f, -0.006f);
            sortingOrderOffset = -1;
        }
        else
        {
            widthRatio  = 1.2f;
            heightRatio = 0.28f;
            alpha       = 0.82f;
            localOffset = new Vector2(0f, -0.01f);
            sortingOrderOffset = -1;
        }
    }

    void Build()
    {
        _ownerSr = GetComponent<SpriteRenderer>();
        if (_ownerSr == null && _preset == Preset.Table)
            _ownerSr = GetComponentInChildren<SpriteRenderer>();
        if (_ownerSr == null) return;

        var sprite = GameplaySprites.LpcShadowSprite();
        if (sprite == null) return;

        if (_shadowTf == null)
        {
            var existing = _ownerSr.transform.Find("LpcShadow");
            if (existing != null)
            {
                _shadowTf = existing;
                _shadowSr = existing.GetComponent<SpriteRenderer>();
            }
        }

        if (_shadowTf == null)
        {
            var go = new GameObject("LpcShadow");
            _shadowTf = go.transform;
            _shadowSr = go.AddComponent<SpriteRenderer>();
        }

        _shadowTf.SetParent(_ownerSr.transform, false);
        _shadowSr.sprite = sprite;
        _shadowSr.color = new Color(0.1f, 0.1f, 0.12f, alpha);
        RefreshLayout();
        SyncSorting();
    }

    void EnsureDrawOrder()
    {
        if (_drawOrderFixed || _ownerSr == null) return;

        if (_preset == Preset.Table)
        {
            if (_ownerSr.sortingOrder < 2)
                _ownerSr.sortingOrder = 2;
            _drawOrderFixed = true;
            SyncSorting();
            return;
        }

        if (_ownerSr.sortingOrder >= FloorSortingOrder + 1) return;
        _ownerSr.sortingOrder = FloorSortingOrder + 1;
        _drawOrderFixed = true;
        SyncSorting();
    }

    void RefreshLayout()
    {
        if (_ownerSr == null || _shadowSr == null || _shadowSr.sprite == null) return;

        Bounds body = _ownerSr.sprite != null
            ? _ownerSr.sprite.bounds
            : new Bounds(Vector3.zero, Vector3.one * 0.2f);

        Bounds sh = _shadowSr.sprite.bounds;
        float cx = (body.min.x + body.max.x) * 0.5f;
        float targetW = body.size.x * widthRatio;
        float scaleX = targetW / Mathf.Max(0.001f, sh.size.x);
        float scaleY = scaleX * heightRatio / Mathf.Max(0.001f, widthRatio);
        float halfH = sh.size.y * scaleY * 0.5f;
        float feetY = body.min.y;

        _shadowTf.localPosition = new Vector3(
            cx + localOffset.x,
            feetY + halfH + localOffset.y,
            0.02f);
        _shadowTf.localScale = new Vector3(scaleX, scaleY, 1f);
    }

    void SyncSorting()
    {
        if (_ownerSr == null || _shadowSr == null) return;

        int bodyOrder = _ownerSr.sortingOrder;
        int shadowOrder = bodyOrder + sortingOrderOffset;

        if (_preset == Preset.Table)
            shadowOrder = Mathf.Max(FloorSortingOrder + 1, bodyOrder - 1);
        else
            shadowOrder = Mathf.Clamp(shadowOrder, FloorSortingOrder, Mathf.Max(FloorSortingOrder, bodyOrder - 1));

        _shadowSr.sortingLayerID = _ownerSr.sortingLayerID;
        _shadowSr.sortingOrder = shadowOrder;
    }
}
